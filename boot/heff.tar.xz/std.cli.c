// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ambiguous 41766
#define TAG_BadShape 33347
#define TAG_DirsOnly 64835
#define TAG_Enter_24std_2ecli_2elongF_24s1119688962x564470218 36790
#define TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139 11561
#define TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997 9522
#define TAG_Extra 49222
#define TAG_FilesBy 64286
#define TAG_Help 25956
#define TAG_Many 40086
#define TAG_Missing 63220
#define TAG_MissingFlag 20234
#define TAG_NoValue 57584
#define TAG_NotIn 31836
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Rest 61983
#define TAG_Some 35658
#define TAG_SwitchValue 32207
#define TAG_Unknown 64328
#define TAG_Words 20643
#define LBL_ap 9878
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_count 296209705
#define LBL_doc 309170
#define LBL_flag 9641011
#define LBL_flags 298871457
#define LBL_fs 10036
#define LBL_give 9668568
#define LBL_given 299725719
#define LBL_long 9823043
#define LBL_meta 9843404
#define LBL_name 9869138
#define LBL_on 10310
#define LBL_pos 320718
#define LBL_ps 10346
#define LBL_ra 10390
#define LBL_required 351999471
#define LBL_sh 10428
#define LBL_shape 310758331
#define LBL_short 310771862
#define LBL_take 10047822
#define LBL_values 1123329101
#define LBL_waiting 1348170899
static uint32_t shape_flags__pos[] = {LBL_flags, LBL_pos};
static uint32_t shape_give__ap__flag__pos[] = {LBL_give, LBL_ap, LBL_flag, LBL_pos};
static uint32_t shape_on__waiting__count__given[] = {LBL_on, LBL_waiting, LBL_count, LBL_given};
static uint32_t shape_pos__flags[] = {LBL_pos, LBL_flags};
static uint32_t shape_sh__ra__on__ps__fs[] = {LBL_sh, LBL_ra, LBL_on, LBL_ps, LBL_fs};
static uint32_t shape_shape__take[] = {LBL_shape, LBL_take};
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1073512242x148531643(V, V);
V g_list_2eany_24s1073512242x148531643_entry(V self, V *a);
extern Clo g_list_2eany_24s1073512242x148531643_clo;
V g_list_2eany_24s1968468648x2095421717(V, V, V, V, V, V, V);
V g_list_2eany_24s1968468648x2095421717_entry(V self, V *a);
extern Clo g_list_2eany_24s1968468648x2095421717_clo;
V g_list_2eany_24s2046291842x47540086(V, V, V, V);
V g_list_2eany_24s2046291842x47540086_entry(V self, V *a);
extern Clo g_list_2eany_24s2046291842x47540086_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1618362284x812128366_24cpr(V, V);
HeffT2 g_list_2efind_24s1867824208x1412174996_24cpr(V, V);
HeffT2 g_list_2efind_24s670012890x84869279_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24f1368804635x922296653(V, V);
V g_list_2ekeepIf_24f1368804635x922296653_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1368804635x922296653_clo;
V g_list_2ekeepIf_24s1111636858x612918583(V, V, V);
V g_list_2ekeepIf_24s1111636858x612918583_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1111636858x612918583_clo;
V g_list_2ekeepIf_24s1220809684x843195562(V, V);
V g_list_2ekeepIf_24s1220809684x843195562_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1220809684x843195562_clo;
V g_list_2ekeepIf_24s44384897x1267641110(V);
V g_list_2ekeepIf_24s44384897x1267641110_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s44384897x1267641110_clo;
V g_list_2ekeepIf_24s920421308x594300259(V, V, V);
V g_list_2ekeepIf_24s920421308x594300259_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s920421308x594300259_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1340051005x157438530(V, V, V, V);
V g_list_2emap_24f1340051005x157438530_entry(V self, V *a);
extern Clo g_list_2emap_24f1340051005x157438530_clo;
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123(V, V, V, V);
V g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_entry(V self, V *a);
extern Clo g_list_2emap_24f1340051005x157438530_24f1161082868x102492123_clo;
V g_list_2emap_24f755592795x444686035(V, V, V, V, V, V);
V g_list_2emap_24f755592795x444686035_entry(V self, V *a);
extern Clo g_list_2emap_24f755592795x444686035_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1281445768x1036802655(V);
V g_list_2emap_24s1281445768x1036802655_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_clo;
V g_list_2emap_24s1753874608x910016727(V);
V g_list_2emap_24s1753874608x910016727_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_clo;
V g_list_2emap_24s1854779998x1713580578(V);
V g_list_2emap_24s1854779998x1713580578_entry(V self, V *a);
extern Clo g_list_2emap_24s1854779998x1713580578_clo;
V g_list_2emap_24s2029999044x514618413(V);
V g_list_2emap_24s2029999044x514618413_entry(V self, V *a);
extern Clo g_list_2emap_24s2029999044x514618413_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s296585291x885335139(V);
V g_list_2emap_24s296585291x885335139_entry(V self, V *a);
extern Clo g_list_2emap_24s296585291x885335139_clo;
V g_list_2emap_24s501902900x1631592417(V, V, V, V);
V g_list_2emap_24s501902900x1631592417_entry(V self, V *a);
extern Clo g_list_2emap_24s501902900x1631592417_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236(V, V, V, V);
V g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236_entry(V self, V *a);
extern Clo g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236_clo;
V g_std_2ecli_2ebashScript(V);
V g_std_2ecli_2ebashScript_entry(V self, V *a);
extern Clo g_std_2ecli_2ebashScript_clo;
V g_std_2ecli_2ecandidatesText(V, V);
V g_std_2ecli_2ecandidatesText_entry(V self, V *a);
extern Clo g_std_2ecli_2ecandidatesText_clo;
V g_std_2ecli_2ecellOf(V, V, V, V, V, V);
V g_std_2ecli_2ecellOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ecellOf_clo;
V g_std_2ecli_2ecomplete_2ecompleteAt_241(V, V, V);
V g_std_2ecli_2ecomplete_2ecompleteAt_241_entry(V self, V *a);
extern Clo g_std_2ecli_2ecomplete_2ecompleteAt_241_clo;
V g_std_2ecli_2ecomplete_2ewhereGo_242(V, V, V, V);
V g_std_2ecli_2ecomplete_2ewhereGo_242_entry(V self, V *a);
extern Clo g_std_2ecli_2ecomplete_2ewhereGo_242_clo;
V g_std_2ecli_2ecompleteWords(V, V, V);
V g_std_2ecli_2ecompleteWords_entry(V self, V *a);
extern Clo g_std_2ecli_2ecompleteWords_clo;
V g_std_2ecli_2edistance(V, V);
V g_std_2ecli_2edistance_entry(V self, V *a);
extern Clo g_std_2ecli_2edistance_clo;
HeffT2 g_std_2ecli_2edupOf_24cpr(V);
HeffT2 g_std_2ecli_2efirstJust_24s180945488x1856732267_24cpr(V, V);
V g_std_2ecli_2efishScript(V);
V g_std_2ecli_2efishScript_entry(V self, V *a);
extern Clo g_std_2ecli_2efishScript_clo;
HeffT2 g_std_2ecli_2eflagProblem_24cpr(V, V);
HeffT2 g_std_2ecli_2egroupsGo_24cpr(V, V);
V g_std_2ecli_2eheadOf(V);
V g_std_2ecli_2eheadOf_entry(V self, V *a);
extern Clo g_std_2ecli_2eheadOf_clo;
V g_std_2ecli_2ehelpOf(V, V);
V g_std_2ecli_2ehelpOf_entry(V self, V *a);
extern Clo g_std_2ecli_2ehelpOf_clo;
V g_std_2ecli_2einitOf(V);
V g_std_2ecli_2einitOf_entry(V self, V *a);
extern Clo g_std_2ecli_2einitOf_clo;
V g_std_2ecli_2einitOf_24dps(V, V);
V g_std_2ecli_2einitOf_24dps_entry(V self, V *a);
extern Clo g_std_2ecli_2einitOf_24dps_clo;
V g_std_2ecli_2elastOf(V);
V g_std_2ecli_2elastOf_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOf_clo;
HeffT2 g_std_2ecli_2elastOnly_24cpr(V);
V g_std_2ecli_2elastOr(V, V);
V g_std_2ecli_2elastOr_entry(V self, V *a);
extern Clo g_std_2ecli_2elastOr_clo;
V g_std_2ecli_2elastS(V);
V g_std_2ecli_2elastS_entry(V self, V *a);
extern Clo g_std_2ecli_2elastS_clo;
HeffT2 g_std_2ecli_2elastS_24cpr(V);
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
HeffT2 g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr(V, V, V, V, V, V, V, V, V);
HeffT2 g_std_2ecli_2elongNamed_24cpr(V, V);
V g_std_2ecli_2elookupL(V, V);
V g_std_2ecli_2elookupL_entry(V self, V *a);
extern Clo g_std_2ecli_2elookupL_clo;
V g_std_2ecli_2enearest(V, V);
V g_std_2ecli_2enearest_entry(V self, V *a);
extern Clo g_std_2ecli_2enearest_clo;
V g_std_2ecli_2eorList(V);
V g_std_2ecli_2eorList_entry(V self, V *a);
extern Clo g_std_2ecli_2eorList_clo;
V g_std_2ecli_2eorList_24acc(V, V);
V g_std_2ecli_2eorList_24acc_entry(V self, V *a);
extern Clo g_std_2ecli_2eorList_24acc_clo;
HeffT2 g_std_2ecli_2eoutcomeOf_24cpr(V, V, V);
HeffT2 g_std_2ecli_2eparse_24cpr(V, V);
HeffT2 g_std_2ecli_2eproblemOf_24cpr(V, V);
V g_std_2ecli_2eproblemSaid(V);
V g_std_2ecli_2eproblemSaid_entry(V self, V *a);
extern Clo g_std_2ecli_2eproblemSaid_clo;
HeffT2 g_std_2ecli_2ereadLine_24cpr(V, V, V);
V g_std_2ecli_2ereading_get(void);
V g_std_2ecli_2erestIndex(V, V);
V g_std_2ecli_2erestIndex_entry(V self, V *a);
extern Clo g_std_2ecli_2erestIndex_clo;
V g_std_2ecli_2erowFor_2enextGo_240(V, V, V, V, V, V);
V g_std_2ecli_2erowFor_2enextGo_240_entry(V self, V *a);
extern Clo g_std_2ecli_2erowFor_2enextGo_240_clo;
HeffT2 g_std_2ecli_2eshapeProblem_24cpr(V);
V g_std_2ecli_2eshells_get(void);
V g_std_2ecli_2eshortWhere(V, V, V);
V g_std_2ecli_2eshortWhere_entry(V self, V *a);
extern Clo g_std_2ecli_2eshortWhere_clo;
V g_std_2ecli_2eshortWhere_24scalars(V, V, V, V, V, V);
V g_std_2ecli_2eshortWhere_24scalars_entry(V self, V *a);
extern Clo g_std_2ecli_2eshortWhere_24scalars_clo;
V g_std_2ecli_2eusage(V, V);
V g_std_2ecli_2eusage_entry(V self, V *a);
extern Clo g_std_2ecli_2eusage_clo;
HeffT2 g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr(V, V);
V g_std_2ecli_2ezshScript(V);
V g_std_2ecli_2ezshScript_entry(V self, V *a);
extern Clo g_std_2ecli_2ezshScript_clo;

HeffT2 g_std_2ecli_2elastS_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_241)}});
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_std_2ecli_2elastS_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastS_entry, 1, 0};

V g_std_2ecli_2elastS(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_std_2ecli_2elastS_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_std_2ecli_2elastS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2elastS(a0); heff_drop(a0); return r;
}
Clo g_std_2ecli_2elookupL_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elookupL_entry, 2, 0};

V g_std_2ecli_2elookupL(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c_lent(v_k_240, v_x_244, 0)) {
        return heff_dup(v_vs_245);
      } else {
        V t_0 = v_k_240;
        V t_1 = v_rest_243;
        v_k_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2elookupL_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ecli_2elookupL(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_std_2ecli_2ereading_lam1(V self, V *args);
V g_std_2ecli_2ereading_lam0(V self, V *args); static Clo g_std_2ecli_2ereading_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam0, 1, 0};
V g_std_2ecli_2ereading_lam3(V self, V *args);
V g_std_2ecli_2ereading_lam2(V self, V *args); static Clo g_std_2ecli_2ereading_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam2, 2, 0};
V g_std_2ecli_2ereading_lam5(V self, V *args);
V g_std_2ecli_2ereading_lam4(V self, V *args); static Clo g_std_2ecli_2ereading_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam4, 1, 0};
V g_std_2ecli_2ereading_lam7(V self, V *args); static Clo g_std_2ecli_2ereading_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam7, 2, 0};
V g_std_2ecli_2ereading_lam6(V self, V *args); static Clo g_std_2ecli_2ereading_lam6_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ereading_lam6, 1, 0};

static V g_std_2ecli_2ereading_val;
static HEFF_ONCE g_std_2ecli_2ereading_st;
static V g_std_2ecli_2ereading_init(void) {
  return heff_rec_n(4, shape_give__ap__flag__pos, (V[]){((V)&g_std_2ecli_2ereading_lam0_clo), ((V)&g_std_2ecli_2ereading_lam2_clo), ((V)&g_std_2ecli_2ereading_lam4_clo), ((V)&g_std_2ecli_2ereading_lam6_clo)});
}
V g_std_2ecli_2ereading_get(void) {
  if (HEFF_DONE(g_std_2ecli_2ereading_st)) return g_std_2ecli_2ereading_val;
  return heff_global(&g_std_2ecli_2ereading_val, &g_std_2ecli_2ereading_st, g_std_2ecli_2ereading_init);
}
V g_std_2ecli_2ereading_lam1(V self, V *args) {
  V v_x_242 = args[0];
  V v_x_243 = args[1];
  V v_x_240 = heff_env(self)[0];
  heff_drop(v_x_242);
  heff_drop(v_x_243);
  heff_clo_take(self, 1);
  return v_x_240;
}
V g_std_2ecli_2ereading_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_t_241 = heff_rec_n(2, shape_flags__pos, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_rec_n(2, shape_shape__take, (V[]){v_t_241, heff_clo_n(g_std_2ecli_2ereading_lam1, 2, 1, (V[]){v_x_240})});
}
V g_std_2ecli_2ereading_lam3(V self, V *args) {
  V v_groups_2412 = args[0];
  V v_fl_2413 = args[1];
  V v_shape_248 = heff_env(self)[0];
  V v_take_247 = heff_env(self)[1];
  V v_take_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_shape_248, 1, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2415 = (g_list_2edrop(v_t_2414, v_groups_2412));
  V v_t_2416 = heff_tr(heff_call(v_take_247, 2, (V[]){v_t_2415, heff_dup(v_fl_2413)}));
  V f_ = v_take_249;
  heff_room[0] = v_groups_2412;
  heff_room[1] = v_fl_2413;
  heff_room[2] = v_t_2416;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_std_2ecli_2ereading_lam2(V self, V *args) {
  V v_f_244 = args[0];
  V v_x_245 = args[1];
  V v_shape_246 = heff_take_field(v_x_245, 0);
  V v_take_247 = heff_get_n(v_x_245, 1, 2);
  V v_shape_248 = heff_take_field(v_f_244, 0);
  V v_take_249 = heff_take_field(v_f_244, 1);
  V v_t_2410 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_shape_248, 0)), heff_take_field(v_shape_246, 0)));
  V v_t_2411 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_shape_248, 1)), heff_take_field(v_shape_246, 1)));
  return ({ V rv_0 = ({ V rv_0 = v_t_2410; V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_shape_246, 0ULL, 2, shape_flags__pos, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; }); V rv_1 = heff_clo_n(g_std_2ecli_2ereading_lam3, 2, 3, (V[]){v_shape_248, v_take_247, v_take_249}); V rr_ = heff_rec_reuse_nf(v_f_244, 0ULL, 2, shape_shape__take, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_std_2ecli_2ereading_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_given_2421 = args[1];
  V v_fl_2417 = heff_env(self)[0];
  heff_drop(v_x_2420);
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_fl_2417, 0, 8); V a_1 = v_given_2421; V r_ = (g_std_2ecli_2elookupL(b_0, a_1)); heff_drop(b_0); heff_drop(v_given_2421); r_; });
}
V g_std_2ecli_2ereading_lam4(V self, V *args) {
  V v_fl_2417 = args[0];
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_fl_2417), NTAG(TAG_Nil)});
  V v_t_2419 = heff_rec_n(2, shape_flags__pos, (V[]){v_t_2418, NTAG(TAG_Nil)});
  return heff_rec_n(2, shape_shape__take, (V[]){v_t_2419, heff_clo_n(g_std_2ecli_2ereading_lam5, 2, 1, (V[]){v_fl_2417})});
}
V g_std_2ecli_2ereading_lam7(V self, V *args) {
  V v_groups_2425 = args[0];
  V v_x_2426 = args[1];
  heff_drop(v_x_2426);
  switch (heff_tag_of(v_groups_2425)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2427 = heff_field(v_groups_2425, 0);
    heff_take_n(v_groups_2425, 1ULL, 2);
    return v_x_2427;
  }
  default: return heff_nomatch(v_groups_2425);
  }
}
V g_std_2ecli_2ereading_lam6(V self, V *args) {
  V v_p_2422 = args[0];
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_p_2422, NTAG(TAG_Nil)});
  V v_t_2424 = heff_rec_n(2, shape_flags__pos, (V[]){NTAG(TAG_Nil), v_t_2423});
  return heff_rec_n(2, shape_shape__take, (V[]){v_t_2424, ((V)&g_std_2ecli_2ereading_lam7_clo)});
}

HeffT2 g_std_2ecli_2edupOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_list_2eany_24s1006624359x760861690(v_x_241, v_rest_242));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_241)}});
    } else {
      heff_drop(v_t_243);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_std_2ecli_2elastOnly_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_arity_243 = heff_dup(heff_rfield(v_p_241, 1));
    V v_meta_244 = heff_dup(heff_rfield(v_p_241, 0));
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_arity_243);
      heff_drop(v_meta_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_t_247 = v_arity_243;
      switch (heff_tag_of(v_t_247)) {
      case TAG_One: {
        heff_drop(v_meta_244);
        V t_0 = v_x12_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_Optional: {
        V v_f_248 = v_meta_244;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
      }
      case TAG_Many: {
        V v_f_249 = v_meta_244;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
      }
      case TAG_Some: {
        V v_f_2410 = v_meta_244;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
      }
      case TAG_Rest: {
        V v_f_2411 = v_meta_244;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str0, 2, "--");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str1, 6, " twice");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str2, 0, "");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str3, 1, "-");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str4, 6, " twice");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str5, 1, "-");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str6, 1, "=");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str7, 26, "a short name is one letter");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str8, 4, "help");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str9, 1, "h");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str10, 0, "");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str11, 1, "=");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str12, 69, "--help and -h are the library's; a long name is not empty, has no `=`");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str13, 0, "");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str14, 23, "a switch takes no value");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str15, 54, " takes more or less than one word, and is not the last");
HEFF_LIT(g_std_2ecli_2eshapeProblem_24cpr_str16, 41, " is every word, so no flag could be given");

HeffT2 g_std_2ecli_2eshapeProblem_24cpr(V v_sh_240) {
top: ;
  V v_flags_241 = heff_take_field(v_sh_240, 0);
  V v_pos_242 = heff_get_n(v_sh_240, 1, 2);
  V v_t_243 = (g_list_2emap_24s1854779998x1713580578(heff_dup(v_flags_241)));
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; HeffT2 r_ = (g_std_2ecli_2edupOf_24cpr(a_0)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_flags_241);
      heff_drop(v_pos_242);
      V v_x_247 = v_field_246;
      V v_f_248 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2eshapeProblem_24cpr_str0), v_x_247), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str1));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
    } else {
      heff_drop(v_field_246);
      V v_t_249 = (g_list_2ekeepIf_24f1368804635x922296653(((V)&g_std_2ecli_2eshapeProblem_24cpr_str2), heff_dup(v_flags_241)));
      HeffT2 v_t_2410 = ({ V a_0 = v_t_249; HeffT2 r_ = (g_std_2ecli_2edupOf_24cpr(a_0)); heff_drop(v_t_249); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop(v_flags_241);
          heff_drop(v_pos_242);
          V v_x_2413 = v_field_2412;
          V v_f_2414 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2eshapeProblem_24cpr_str3), v_x_2413), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str4));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
        } else {
          heff_drop(v_field_2412);
          V v_t_2415 = (g_list_2eany_24s2046291842x47540086(MK_INT(1LL), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str5), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str6), v_flags_241));
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop(v_flags_241);
            heff_drop(v_pos_242);
            heff_drop(v_t_2415);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str7)}});
          } else {
            heff_drop(v_t_2415);
            V v_t_2416 = (g_list_2eany_24s1968468648x2095421717(((V)&g_std_2ecli_2eshapeProblem_24cpr_str8), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str9), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str10), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str11), MK_INT(0LL), MK_INT(0LL), v_flags_241));
            if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
              heff_drop(v_flags_241);
              heff_drop(v_pos_242);
              heff_drop(v_t_2416);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str12)}});
            } else {
              heff_drop(v_t_2416);
              V v_t_2417 = (g_list_2eany_24s1073512242x148531643(((V)&g_std_2ecli_2eshapeProblem_24cpr_str13), v_flags_241));
              if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
                heff_drop(v_flags_241);
                heff_drop(v_pos_242);
                heff_drop(v_t_2417);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_std_2ecli_2eshapeProblem_24cpr_str14)}});
              } else {
                heff_drop(v_t_2417);
                HeffT2 v_t_2418 = (g_std_2ecli_2elastOnly_24cpr(v_pos_242));
                {
                  V v_field_2420 = v_t_2418.f[1];
                  int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
                  if ((v_tag_2419 == ((int64_t)0ULL))) {
                    heff_drop(v_flags_241);
                    heff_drop(v_pos_242);
                    V v_m_2421 = v_field_2420;
                    V v_f_2422 = heff_strAppend(v_m_2421, ((V)&g_std_2ecli_2eshapeProblem_24cpr_str15));
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
                  } else {
                    heff_drop(v_field_2420);
                    V v_t_2423 = v_pos_242;
                    switch (heff_tag_of(v_t_2423)) {
                    case TAG_Nil: {
                      heff_drop(v_flags_241);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                    case TAG_Cons: {
                      V v_p_2424 = heff_field(v_t_2423, 0);
                      heff_take_n(v_t_2423, 1ULL, 2);
                      V v_arity_2426 = heff_take_field(v_p_2424, 1);
                      V v_meta_2427 = heff_get_n(v_p_2424, 0, 3);
                      V v_t_2428 = v_arity_2426;
                      switch (heff_tag_of(v_t_2428)) {
                      case TAG_One: {
                        heff_drop(v_flags_241);
                        heff_drop(v_meta_2427);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Optional: {
                        heff_drop(v_flags_241);
                        heff_drop(v_meta_2427);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Many: {
                        heff_drop(v_flags_241);
                        heff_drop(v_meta_2427);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Some: {
                        heff_drop(v_flags_241);
                        heff_drop(v_meta_2427);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                      case TAG_Rest: {
                        V v_t_2429 = v_flags_241;
                        switch (heff_tag_of(v_t_2429)) {
                        case TAG_Nil: {
                          heff_drop(v_meta_2427);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                        case TAG_Cons: {
                          heff_take_n(v_t_2429, 0ULL, 2);
                          V v_f_2432 = heff_strAppend(v_meta_2427, ((V)&g_std_2ecli_2eshapeProblem_24cpr_str16));
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_t_2429)}});
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_t_2428)}});
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_t_2423)}});
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

HeffT2 g_std_2ecli_2elongNamed_24cpr(V v_sh_240, V v_x_241) {
top: ;
  HeffT2 v_t_242 = (g_list_2efind_24s1618362284x812128366_24cpr(v_x_241, heff_rfield(v_sh_240, 0)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop_rec(v_sh_240, 2);
      V v_f_245 = v_field_244;
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_245}});
    } else {
      heff_drop(v_field_244);
      V v_fs_246 = (g_list_2ekeepIf_24s1111636858x612918583(MK_INT(0LL), v_x_241, heff_get_n(v_sh_240, 0, 2)));
      switch (heff_tag_of(v_fs_246)) {
      case TAG_Nil: {
        V v_t_247 = (g_list_2emap_24s1854779998x1713580578(v_fs_246));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_247}});
      }
      case TAG_Cons: {
        V v_fs2_249 = heff_dup(heff_field(v_fs_246, 1));
        switch (heff_tag_of(v_fs2_249)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_fs_246)) {
          case TAG_Cons: {
            V v_fs1_2410 = heff_field(v_fs_246, 0);
            heff_take_n(v_fs_246, 1ULL, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_fs1_2410}});
          }
          default: return ((HeffT2){{heff_nomatch(v_fs_246)}});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_fs2_249, 0ULL, 2);
          V v_t_2414 = (g_list_2emap_24s1854779998x1713580578(v_fs_246));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2414}});
        }
        default: return ((HeffT2){{heff_nomatch(v_fs2_249)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_fs_246)}});
      }
    }
  }
}
Clo g_std_2ecli_2ecellOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecellOf_entry, 6, 0};

V g_std_2ecli_2ecellOf(V v_a_240, V v_box_24c_241, V v_up_242, V v_diag_243, V v_left_244, V v_i_245) {
  int64_t v_c_241 = heff_unbox_word(v_box_24c_241);
top: ;
  V v_x_246 = heff_intAdd(v_up_242, MK_INT(1LL));
  V v_y_247 = heff_intAdd(v_left_244, MK_INT(1LL));
  V v_x_248;
  if (heff_intLe_c_lent(v_x_246, v_y_247, 0)) {
    heff_drop(v_y_247);
    v_x_248 = v_x_246;
  } else {
    heff_drop(v_x_246);
    v_x_248 = v_y_247;
  }
  V v_t_249 = heff_strByteAt(heff_dup(v_a_240), heff_intSub(v_i_245, MK_INT(1LL)));
  V v_t_2410;
  if ((heff_unbox_word(v_t_249) == v_c_241)) {
    v_t_2410 = MK_INT(0LL);
  } else {
    v_t_2410 = MK_INT(1LL);
  }
  V v_y_2411 = heff_intAdd(v_diag_243, v_t_2410);
  if (heff_intLe_c_lent(v_x_248, v_y_2411, 0)) {
    heff_drop(v_y_2411);
    return v_x_248;
  } else {
    heff_drop(v_x_248);
    return v_y_2411;
  }
}
V g_std_2ecli_2ecellOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2ecellOf(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
Clo g_std_2ecli_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastOr_entry, 2, 0};

V g_std_2ecli_2elastOr(V v_d_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_dup(v_d_240);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_d_240;
      V t_1 = v_x22_243;
      v_d_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2elastOr_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ecli_2elastOr(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_std_2ecli_2edistance_lam0(V self, V *args);
Clo g_std_2ecli_2edistance_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2edistance_entry, 2, 0};

V g_std_2ecli_2edistance(V v_a_240, V v_b_241) {
top: ;
  int64_t v_t_242 = (heff_unbox_word(heff_strLength_lent(v_a_240, 0)) + ((int64_t)1ULL));
  V v_t_243 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_242)));
  V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_strLength_lent(v_b_241, 0)));
  V v_t_2414 = ({ V b_0 = heff_clo_n(g_std_2ecli_2edistance_lam0, 2, 2, (V[]){heff_dup(v_a_240), heff_dup(v_b_241)}); V a_1 = v_t_243; V a_2 = v_t_244; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_244); r_; });
  return ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2414; V r_ = (g_std_2ecli_2elastOr(a_0, a_1)); heff_drop(v_t_2414); r_; });
}
V g_std_2ecli_2edistance_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_std_2ecli_2edistance(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_std_2ecli_2edistance_lam0(V self, V *args) {
  V v_row_245 = args[0];
  V v_j_246 = args[1];
  V v_a_240 = heff_env(self)[0];
  V v_b_241 = heff_env(self)[1];
  V v_t_249;
  switch (heff_tag_of(v_row_245)) {
  case TAG_Nil: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_xs_248 = heff_dup(heff_field(v_row_245, 1));
    v_t_249 = v_xs_248;
    break;
  }
  default: heff_nomatch(v_row_245);
  }
  V v_t_2412;
  switch (heff_tag_of(v_row_245)) {
  case TAG_Nil: {
    v_t_2412 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_row_245, 0);
    heff_take_n(v_row_245, 1ULL, 2);
    v_t_2412 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_row_245);
  }
  heff_clo_take(self, 2);
  V v_t_2413 = ({ V a_0 = v_a_240; V a_1 = heff_strByteAt_lent(v_b_241, v_j_246, 1); V a_2 = v_t_249; V a_3 = v_t_2412; V a_4 = heff_intAdd_lent(v_j_246, MK_INT(1LL), 2); V a_5 = MK_INT(1LL); V r_ = (g_std_2ecli_2erowFor_2enextGo_240(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_a_240); r_; });
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_intAdd(v_j_246, MK_INT(1LL)), v_t_2413});
}
V g_std_2ecli_2enearest_lam0(V self, V *args);
Clo g_std_2ecli_2enearest_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2enearest_entry, 2, 0};

V g_std_2ecli_2enearest(V v_sh_240, V v_x_241) {
top: ;
  return ({ V b_0 = heff_clo_n(g_std_2ecli_2enearest_lam0, 2, 1, (V[]){heff_dup(v_x_241)}); V a_1 = NTAG(TAG_Nothing); V b_2 = heff_get_n(v_sh_240, 0, 2); V r_ = (g_list_2efoldl(b_0, a_1, b_2)); heff_drop(b_0); heff_drop(b_2); r_; });
}
V g_std_2ecli_2enearest_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2enearest(a[0], a1); heff_drop(a1); return r;
}
V g_std_2ecli_2enearest_lam0(V self, V *args) {
  V v_best_242 = args[0];
  V v_f_243 = args[1];
  V v_x_241 = heff_env(self)[0];
  V v_t_244 = (g_std_2ecli_2edistance(heff_rfield(v_f_243, 0), v_x_241));
  if ((heff_intLe_c_lent(v_t_244, MK_INT(2LL), 2) && (heff_unbox_word(heff_strLength_lent(v_x_241, 0)) <= ((int64_t)16ULL)))) {
    heff_drop(v_t_244);
    switch (heff_tag_of(v_best_242)) {
    case TAG_Nothing: {
      heff_drop(self);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_f_243, 0, 8)});
    }
    case TAG_Just: {
      V v_b_245 = heff_dup(heff_field(v_best_242, 0));
      V v_t_246 = (g_std_2ecli_2edistance(heff_rfield(v_f_243, 0), v_x_241));
      heff_clo_take(self, 1);
      V v_t_247 = ({ V a_0 = v_b_245; V a_1 = v_x_241; V r_ = (g_std_2ecli_2edistance(a_0, a_1)); heff_drop(v_b_245); heff_drop(v_x_241); r_; });
      if (heff_intLt_c(v_t_246, v_t_247)) {
        heff_drop_tag(v_best_242, 1);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_f_243, 0, 8)});
      } else {
        heff_drop_rec(v_f_243, 8);
        return v_best_242;
      }
    }
    default: return heff_nomatch(v_best_242);
    }
  } else {
    heff_drop_rec(v_f_243, 8);
    heff_drop(self);
    heff_drop(v_t_244);
    return v_best_242;
  }
}
Clo g_std_2ecli_2erestIndex_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2erestIndex_entry, 2, 0};

V g_std_2ecli_2erestIndex(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_dup(heff_rfield(v_x11_242, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_One: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Optional: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Many: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Some: {
      V t_0 = v_ps_243;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_Rest: {
      return v_i_241;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2erestIndex_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2erestIndex(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str0, 1, "=");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str1, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str2, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str3, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str4, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str5, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str6, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str7, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str8, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str9, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str10, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str11, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str12, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str13, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str14, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str15, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str16, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str17, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str18, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str19, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str20, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str21, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str22, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str23, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str24, 1, "-");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str25, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str26, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str27, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str28, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str29, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str30, 1, "-");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str31, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str32, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str33, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str34, 1, "-");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str35, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str36, 6, "--help");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str37, 2, "-h");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str38, 2, "--");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str39, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str40, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str41, 0, "");
HEFF_LIT(g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str42, 0, "");

HeffT2 g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr(V v_tag_240, V v_at_241, V v_ws_242, V v_body_243, V v_at_244, V v_ws_245, V v_cl_246, V v_at_247, V v_x3_248) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24std_2ecli_2elongF_24s1119688962x564470218: {
    top_TAG_Enter_24std_2ecli_2elongF_24s1119688962x564470218: ;
    heff_drop_rec(v_at_247, 5);
    heff_drop(v_x3_248);
    V v_j_249 = heff_strFind_lent(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str0), v_body_243, MK_INT(0LL), 5);
    if (heff_intLt_c_lent(v_j_249, MK_INT(0LL), 2)) {
      heff_drop(v_j_249);
      HeffT2 v_t_2410 = (g_std_2ecli_2elongNamed_24cpr(heff_dup(heff_rfield(v_at_241, 0)), v_body_243));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop(v_ws_242);
          heff_drop_rec(v_at_244, 5);
          heff_drop(v_ws_245);
          heff_drop(v_cl_246);
          V v_cands_2413 = v_field_2412;
          V v_t_2417;
          switch (heff_tag_of(v_cands_2413)) {
          case TAG_Nil: {
            V v_t_2414 = (g_std_2ecli_2enearest(heff_get_n(v_at_241, 0, 5), v_body_243));
            v_t_2417 = heff_tag_n(TAG_Unknown, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str1), v_body_243), v_t_2414});
            break;
          }
          case TAG_Cons: {
            heff_drop_rec(v_at_241, 5);
            v_t_2417 = heff_tag_n(TAG_Ambiguous, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str2), v_body_243), v_cands_2413});
            break;
          }
          default: heff_nomatch(v_cands_2413);
          }
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2417}});
        } else {
          heff_drop(v_body_243);
          V v_f_2418 = v_field_2412;
          V v_meta_2419 = heff_take_field(v_f_2418, 2);
          V v_long_2420 = heff_get_n(v_f_2418, 0, 8);
          if (heff_strEq_c(v_meta_2419, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str3))) {
            V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_long_2420, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str4)}), heff_take_field(v_at_241, 4)});
            V v_t_2422 = ({ V rv_4 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_at_241, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
            V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
            V t_1 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str5);
            V t_2 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str6);
            V t_3 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str7);
            V t_4 = v_at_244;
            V t_5 = v_ws_245;
            V t_6 = v_cl_246;
            V t_7 = v_t_2422;
            V t_8 = v_ws_242;
            v_tag_240 = t_0;
            v_at_241 = t_1;
            v_ws_242 = t_2;
            v_body_243 = t_3;
            v_at_244 = t_4;
            v_ws_245 = t_5;
            v_cl_246 = t_6;
            v_at_247 = t_7;
            v_x3_248 = t_8;
            goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
          } else {
            switch (heff_tag_of(v_ws_242)) {
            case TAG_Nil: {
              heff_drop_rec(v_at_241, 5);
              heff_drop_rec(v_at_244, 5);
              heff_drop(v_ws_245);
              heff_drop(v_cl_246);
              V v_f_2423 = heff_tag_n(TAG_NoValue, 1, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str8), v_long_2420)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2423}});
            }
            case TAG_Cons: {
              V v_v_2424 = heff_field(v_ws_242, 0);
              V v_ws2_2425 = heff_field(v_ws_242, 1);
              V v_ru_24ws_242_24Cons = heff_take_reuse_n(v_ws_242, 3ULL, 2);
              V v_t_2426 = heff_tag_at_n(v_ru_24ws_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_long_2420, v_v_2424}), heff_dup(heff_rfield(v_at_241, 4))});
              V v_t_2427 = ({ V rv_4 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_at_241, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
              V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
              V t_1 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str9);
              V t_2 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str10);
              V t_3 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str11);
              V t_4 = v_at_244;
              V t_5 = v_ws_245;
              V t_6 = v_cl_246;
              V t_7 = v_t_2427;
              V t_8 = v_ws2_2425;
              v_tag_240 = t_0;
              v_at_241 = t_1;
              v_ws_242 = t_2;
              v_body_243 = t_3;
              v_at_244 = t_4;
              v_ws_245 = t_5;
              v_cl_246 = t_6;
              v_at_247 = t_7;
              v_x3_248 = t_8;
              goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
            }
            default: return ((HeffT2){{heff_nomatch(v_ws_242)}});
            }
          }
        }
      }
    } else {
      HeffT2 v_t_2428 = ({ V a_0 = heff_dup(heff_rfield(v_at_241, 0)); V b_1 = heff_strSlice_lent(v_body_243, MK_INT(0LL), v_j_249, 2); HeffT2 r_ = (g_std_2ecli_2elongNamed_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_2430 = v_t_2428.f[1];
        int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
        if ((v_tag_2429 == ((int64_t)0ULL))) {
          heff_drop(v_ws_242);
          heff_drop_rec(v_at_244, 5);
          heff_drop(v_ws_245);
          heff_drop(v_cl_246);
          V v_cands_2431 = v_field_2430;
          V v_x_2432 = heff_strSlice(v_body_243, MK_INT(0LL), v_j_249);
          V v_t_2436;
          switch (heff_tag_of(v_cands_2431)) {
          case TAG_Nil: {
            V v_t_2433 = (g_std_2ecli_2enearest(heff_get_n(v_at_241, 0, 5), v_x_2432));
            v_t_2436 = heff_tag_n(TAG_Unknown, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str12), v_x_2432), v_t_2433});
            break;
          }
          case TAG_Cons: {
            heff_drop_rec(v_at_241, 5);
            v_t_2436 = heff_tag_n(TAG_Ambiguous, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str13), v_x_2432), v_cands_2431});
            break;
          }
          default: heff_nomatch(v_cands_2431);
          }
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2436}});
        } else {
          V v_f_2437 = v_field_2430;
          V v_meta_2438 = heff_take_field(v_f_2437, 2);
          V v_long_2439 = heff_get_n(v_f_2437, 0, 8);
          if (heff_strEq_c(v_meta_2438, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str14))) {
            heff_drop_rec(v_at_241, 5);
            heff_drop(v_ws_242);
            heff_drop(v_body_243);
            heff_drop_rec(v_at_244, 5);
            heff_drop(v_ws_245);
            heff_drop(v_cl_246);
            heff_drop(v_j_249);
            V v_f_2440 = heff_tag_n(TAG_SwitchValue, 1, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str15), v_long_2439)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2440}});
          } else {
            V v_t_2441 = heff_strSlice(heff_dup(v_body_243), heff_intAdd(v_j_249, MK_INT(1LL)), heff_strLength(v_body_243));
            V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_long_2439, v_t_2441}), heff_take_field(v_at_241, 4)});
            V v_t_2443 = ({ V rv_4 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_at_241, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
            V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
            V t_1 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str16);
            V t_2 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str17);
            V t_3 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str18);
            V t_4 = v_at_244;
            V t_5 = v_ws_245;
            V t_6 = v_cl_246;
            V t_7 = v_t_2443;
            V t_8 = v_ws_242;
            v_tag_240 = t_0;
            v_at_241 = t_1;
            v_ws_242 = t_2;
            v_body_243 = t_3;
            v_at_244 = t_4;
            v_ws_245 = t_5;
            v_cl_246 = t_6;
            v_at_247 = t_7;
            v_x3_248 = t_8;
            goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
          }
        }
      }
    }
  }
  case TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139: {
    top_TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139: ;
    if (heff_strEq_c_lent(v_cl_246, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str19), 2)) {
      heff_drop(v_cl_246);
      heff_drop_rec(v_at_247, 5);
      heff_drop(v_x3_248);
      V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
      V t_1 = v_at_241;
      V t_2 = v_ws_242;
      V t_3 = v_body_243;
      V t_4 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str20);
      V t_5 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str21);
      V t_6 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str22);
      V t_7 = v_at_244;
      V t_8 = v_ws_245;
      v_tag_240 = t_0;
      v_at_241 = t_1;
      v_ws_242 = t_2;
      v_body_243 = t_3;
      v_at_244 = t_4;
      v_ws_245 = t_5;
      v_cl_246 = t_6;
      v_at_247 = t_7;
      v_x3_248 = t_8;
      goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
    } else {
      V v_x_2444 = heff_strSlice_lent(v_cl_246, MK_INT(0LL), MK_INT(1LL), 6);
      if (heff_strEq_c_lent(v_x_2444, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str23), 2)) {
        heff_drop_rec(v_at_241, 5);
        heff_drop(v_ws_242);
        heff_drop(v_body_243);
        heff_drop_rec(v_at_244, 5);
        heff_drop(v_ws_245);
        heff_drop_rec(v_at_247, 5);
        heff_drop(v_x3_248);
        heff_drop(v_x_2444);
        V v_t_2445 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str24), heff_strSlice(v_cl_246, MK_INT(0LL), MK_INT(1LL)));
        V v_f_2446 = heff_tag_n(TAG_Unknown, 2, (V[]){v_t_2445, NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2446}});
      } else {
        V v_t_2447 = heff_get_n(heff_dup(heff_rfield(v_at_244, 0)), 0, 2);
        HeffT2 v_t_2448 = ({ V a_0 = v_x_2444; V a_1 = v_t_2447; HeffT2 r_ = (g_list_2efind_24s670012890x84869279_24cpr(a_0, a_1)); heff_drop(v_x_2444); heff_drop(v_t_2447); r_; });
        {
          V v_field_2450 = v_t_2448.f[1];
          int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
          if ((v_tag_2449 == ((int64_t)0ULL))) {
            V v_f_2451 = v_field_2450;
            V v_meta_2452 = heff_take_field(v_f_2451, 2);
            V v_long_2453 = heff_take_field(v_f_2451, 0);
            V v_short_2454 = heff_get_n(v_f_2451, 1, 8);
            if (heff_strEq_c(v_meta_2452, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str25))) {
              heff_drop(v_short_2454);
              V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_long_2453, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str26)}), heff_take_field(v_at_244, 4)});
              V v_t_2456 = ({ V rv_4 = v_t_2455; V rr_ = heff_rec_reuse_nf(v_at_244, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
              V v_t_2457 = heff_strSlice(heff_dup(v_cl_246), MK_INT(1LL), heff_strLength(v_cl_246));
              V t_0 = NTAG(TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139);
              V t_1 = v_at_241;
              V t_2 = v_ws_242;
              V t_3 = v_body_243;
              V t_4 = v_t_2456;
              V t_5 = v_ws_245;
              V t_6 = v_t_2457;
              V t_7 = v_at_247;
              V t_8 = v_x3_248;
              v_tag_240 = t_0;
              v_at_241 = t_1;
              v_ws_242 = t_2;
              v_body_243 = t_3;
              v_at_244 = t_4;
              v_ws_245 = t_5;
              v_cl_246 = t_6;
              v_at_247 = t_7;
              v_x3_248 = t_8;
              goto top_TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139;
            } else {
              heff_drop_rec(v_at_247, 5);
              heff_drop(v_x3_248);
              if ((((int64_t)1ULL) < heff_unbox_word(heff_strLength_lent(v_cl_246, 0)))) {
                heff_drop(v_short_2454);
                V v_t_2458 = heff_strSlice(heff_dup(v_cl_246), MK_INT(1LL), heff_strLength(v_cl_246));
                V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_long_2453, v_t_2458}), heff_take_field(v_at_244, 4)});
                V v_t_2460 = ({ V rv_4 = v_t_2459; V rr_ = heff_rec_reuse_nf(v_at_244, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
                V t_1 = v_at_241;
                V t_2 = v_ws_242;
                V t_3 = v_body_243;
                V t_4 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str27);
                V t_5 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str28);
                V t_6 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str29);
                V t_7 = v_t_2460;
                V t_8 = v_ws_245;
                v_tag_240 = t_0;
                v_at_241 = t_1;
                v_ws_242 = t_2;
                v_body_243 = t_3;
                v_at_244 = t_4;
                v_ws_245 = t_5;
                v_cl_246 = t_6;
                v_at_247 = t_7;
                v_x3_248 = t_8;
                goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
              } else {
                heff_drop(v_cl_246);
                switch (heff_tag_of(v_ws_245)) {
                case TAG_Nil: {
                  heff_drop_rec(v_at_241, 5);
                  heff_drop(v_ws_242);
                  heff_drop(v_body_243);
                  heff_drop_rec(v_at_244, 5);
                  heff_drop(v_long_2453);
                  V v_f_2461 = heff_tag_n(TAG_NoValue, 1, (V[]){heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str30), v_short_2454)});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2461}});
                }
                case TAG_Cons: {
                  V v_v_2462 = heff_field(v_ws_245, 0);
                  V v_ws2_2463 = heff_field(v_ws_245, 1);
                  V v_ru_24ws_245_24Cons = heff_take_reuse_n(v_ws_245, 3ULL, 2);
                  heff_drop(v_short_2454);
                  V v_t_2464 = heff_tag_at_n(v_ru_24ws_245_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_long_2453, v_v_2462}), heff_dup(heff_rfield(v_at_244, 4))});
                  V v_t_2465 = ({ V rv_4 = v_t_2464; V rr_ = heff_rec_reuse_nf(v_at_244, 15ULL, 5, shape_sh__ra__on__ps__fs, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                  V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
                  V t_1 = v_at_241;
                  V t_2 = v_ws_242;
                  V t_3 = v_body_243;
                  V t_4 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str31);
                  V t_5 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str32);
                  V t_6 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str33);
                  V t_7 = v_t_2465;
                  V t_8 = v_ws2_2463;
                  v_tag_240 = t_0;
                  v_at_241 = t_1;
                  v_ws_242 = t_2;
                  v_body_243 = t_3;
                  v_at_244 = t_4;
                  v_ws_245 = t_5;
                  v_cl_246 = t_6;
                  v_at_247 = t_7;
                  v_x3_248 = t_8;
                  goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
                }
                default: return ((HeffT2){{heff_nomatch(v_ws_245)}});
                }
              }
            }
          } else {
            heff_drop_rec(v_at_241, 5);
            heff_drop(v_ws_242);
            heff_drop(v_body_243);
            heff_drop_rec(v_at_244, 5);
            heff_drop(v_ws_245);
            heff_drop_rec(v_at_247, 5);
            heff_drop(v_x3_248);
            heff_drop(v_field_2450);
            V v_t_2466 = heff_strAppend(((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str34), heff_strSlice(v_cl_246, MK_INT(0LL), MK_INT(1LL)));
            V v_f_2467 = heff_tag_n(TAG_Unknown, 2, (V[]){v_t_2466, NTAG(TAG_Nothing)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2467}});
          }
        }
      }
    }
  }
  case TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997: {
    top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997: ;
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nil: {
      heff_drop_rec(v_at_241, 5);
      heff_drop(v_ws_242);
      heff_drop(v_body_243);
      heff_drop_rec(v_at_244, 5);
      heff_drop(v_ws_245);
      heff_drop(v_cl_246);
      V v_t_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_at_247, 3)));
      V v_t_2469 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_at_247, 4, 5)));
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(2, shape_pos__flags, (V[]){v_t_2468, v_t_2469})}});
    }
    case TAG_Cons: {
      V v_w_2470 = heff_field(v_x3_248, 0);
      V v_ws_2471 = heff_field(v_x3_248, 1);
      V v_ru_24x3_248_24Cons = heff_take_reuse_n(v_x3_248, 3ULL, 2);
      V v_t_2473;
      if (!(heff_dup(heff_rfield(v_at_247, 2)) == NTAG(TAG_True))) {
        v_t_2473 = NTAG(TAG_True);
      } else {
        if (heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_at_247, 1)))) {
          V v_x_2472 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_at_247, 3)));
          v_t_2473 = heff_bool(heff_intLe_c(heff_dup(heff_rfield(v_at_247, 1)), heff_dup(v_x_2472)));
          heff_drop(v_x_2472);
        } else {
          v_t_2473 = NTAG(TAG_False);
        }
      }
      if ((heff_dup(v_t_2473) == NTAG(TAG_True))) {
        heff_drop(v_t_2473);
        V v_t_2474 = heff_tag_re_n(v_ru_24x3_248_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_w_2470, heff_dup(heff_rfield(v_at_247, 3))});
        V v_t_2475 = ({ V rv_2 = NTAG(TAG_False); V rv_3 = v_t_2474; V rr_ = heff_rec_reuse_nf(v_at_247, 19ULL, 5, shape_sh__ra__on__ps__fs, 783u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
        V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
        V t_1 = v_at_241;
        V t_2 = v_ws_242;
        V t_3 = v_body_243;
        V t_4 = v_at_244;
        V t_5 = v_ws_245;
        V t_6 = v_cl_246;
        V t_7 = v_t_2475;
        V t_8 = v_ws_2471;
        v_tag_240 = t_0;
        v_at_241 = t_1;
        v_ws_242 = t_2;
        v_body_243 = t_3;
        v_at_244 = t_4;
        v_ws_245 = t_5;
        v_cl_246 = t_6;
        v_at_247 = t_7;
        v_x3_248 = t_8;
        goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
      } else {
        heff_drop(v_t_2473);
        if (heff_strEq_c_lent(v_w_2470, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str35), 2)) {
          heff_drop(v_w_2470);
          heff_drop_cell(v_ru_24x3_248_24Cons, 2);
          V v_t_2476 = ({ V rv_2 = NTAG(TAG_False); V rr_ = heff_rec_reuse_nf(v_at_247, 27ULL, 5, shape_sh__ra__on__ps__fs, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
          V t_1 = v_at_241;
          V t_2 = v_ws_242;
          V t_3 = v_body_243;
          V t_4 = v_at_244;
          V t_5 = v_ws_245;
          V t_6 = v_cl_246;
          V t_7 = v_t_2476;
          V t_8 = v_ws_2471;
          v_tag_240 = t_0;
          v_at_241 = t_1;
          v_ws_242 = t_2;
          v_body_243 = t_3;
          v_at_244 = t_4;
          v_ws_245 = t_5;
          v_cl_246 = t_6;
          v_at_247 = t_7;
          v_x3_248 = t_8;
          goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
        } else {
          if ((heff_strEq_c_lent(v_w_2470, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str36), 2) || heff_strEq_c_lent(v_w_2470, ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str37), 2))) {
            heff_drop_rec(v_at_241, 5);
            heff_drop(v_ws_242);
            heff_drop(v_body_243);
            heff_drop_rec(v_at_244, 5);
            heff_drop(v_ws_245);
            heff_drop(v_cl_246);
            heff_drop_rec(v_at_247, 5);
            heff_drop(v_w_2470);
            heff_drop(v_ws_2471);
            heff_drop_cell(v_ru_24x3_248_24Cons, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Help)}});
          } else {
            if (heff_strEq_c(heff_strSlice_lent(v_w_2470, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str38))) {
              heff_drop_rec(v_at_241, 5);
              heff_drop(v_ws_242);
              heff_drop(v_body_243);
              heff_drop_cell(v_ru_24x3_248_24Cons, 2);
              V v_t_2477 = heff_strSlice(heff_dup(v_w_2470), MK_INT(2LL), heff_strLength(v_w_2470));
              V t_0 = NTAG(TAG_Enter_24std_2ecli_2elongF_24s1119688962x564470218);
              V t_1 = v_at_247;
              V t_2 = v_ws_2471;
              V t_3 = v_t_2477;
              V t_4 = v_at_244;
              V t_5 = v_ws_245;
              V t_6 = v_cl_246;
              V t_7 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str39);
              V t_8 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str40);
              v_tag_240 = t_0;
              v_at_241 = t_1;
              v_ws_242 = t_2;
              v_body_243 = t_3;
              v_at_244 = t_4;
              v_ws_245 = t_5;
              v_cl_246 = t_6;
              v_at_247 = t_7;
              v_x3_248 = t_8;
              goto top_TAG_Enter_24std_2ecli_2elongF_24s1119688962x564470218;
            } else {
              if (((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_w_2470, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_w_2470, MK_INT(0LL), 2)) == ((int64_t)45ULL)))) {
                heff_drop_rec(v_at_244, 5);
                heff_drop(v_ws_245);
                heff_drop(v_cl_246);
                heff_drop_cell(v_ru_24x3_248_24Cons, 2);
                V v_t_2478 = heff_strSlice(heff_dup(v_w_2470), MK_INT(1LL), heff_strLength(v_w_2470));
                V t_0 = NTAG(TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139);
                V t_1 = v_at_241;
                V t_2 = v_ws_242;
                V t_3 = v_body_243;
                V t_4 = v_at_247;
                V t_5 = v_ws_2471;
                V t_6 = v_t_2478;
                V t_7 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str41);
                V t_8 = ((V)&g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr_str42);
                v_tag_240 = t_0;
                v_at_241 = t_1;
                v_ws_242 = t_2;
                v_body_243 = t_3;
                v_at_244 = t_4;
                v_ws_245 = t_5;
                v_cl_246 = t_6;
                v_at_247 = t_7;
                v_x3_248 = t_8;
                goto top_TAG_Enter_24std_2ecli_2eshortF_24s1014269042x1715098139;
              } else {
                V v_t_2479 = heff_tag_re_n(v_ru_24x3_248_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_w_2470, heff_dup(heff_rfield(v_at_247, 3))});
                V v_t_2480 = ({ V rv_3 = v_t_2479; V rr_ = heff_rec_reuse_nf(v_at_247, 23ULL, 5, shape_sh__ra__on__ps__fs, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                V t_0 = NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997);
                V t_1 = v_at_241;
                V t_2 = v_ws_242;
                V t_3 = v_body_243;
                V t_4 = v_at_244;
                V t_5 = v_ws_245;
                V t_6 = v_cl_246;
                V t_7 = v_t_2480;
                V t_8 = v_ws_2471;
                v_tag_240 = t_0;
                v_at_241 = t_1;
                v_ws_242 = t_2;
                v_body_243 = t_3;
                v_at_244 = t_4;
                v_ws_245 = t_5;
                v_cl_246 = t_6;
                v_at_247 = t_7;
                v_x3_248 = t_8;
                goto top_TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997;
              }
            }
          }
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_tag_240)}});
  }
}
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str0, 0, "");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str1, 0, "");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str2, 0, "");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str4, 0, "");
HEFF_LIT(g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str5, 0, "");

HeffT2 g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr(V v_at_240, V v_x3_241) {
top: ;
  return (g_std_2ecli_2elongF_24s1119688962x564470218_24cycle_24cpr(NTAG(TAG_Enter_24std_2ecli_2ewordsF_24s1352288509x2021617997), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str0), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str1), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str2), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str3), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str4), ((V)&g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr_str5), v_at_240, v_x3_241));
}
HEFF_LIT(g_std_2ecli_2eflagProblem_24cpr_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eflagProblem_24cpr_str1, 0, "");
HEFF_LIT(g_std_2ecli_2eflagProblem_24cpr_str2, 1, "=");
HEFF_LIT(g_std_2ecli_2eflagProblem_24cpr_str3, 2, "--");
HEFF_LIT(g_std_2ecli_2eflagProblem_24cpr_str4, 2, "--");
HEFF_LIT(g_std_2ecli_2eflagProblem_24cpr_str5, 2, "--");
V g_std_2ecli_2eflagProblem_24cpr_lam0(V self, V *args);
V g_std_2ecli_2eflagProblem_24cpr_lam1(V self, V *args);

HeffT2 g_std_2ecli_2eflagProblem_24cpr(V v_fs_240, V v_f_241) {
top: ;
  V v_long_242 = heff_take_field(v_f_241, 0);
  V v_required_243 = heff_take_field(v_f_241, 6);
  V v_meta_244 = heff_take_field(v_f_241, 2);
  V v_values_245 = heff_get_n(v_f_241, 4, 8);
  V v_t_246 = (g_list_2ekeepIf_24s1220809684x843195562(v_long_242, heff_dup(v_fs_240)));
  V v_x1_247 = (g_list_2emap_24s1173914895x100384474(v_t_246));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    V v_t_248 = v_required_243;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_fs_240);
      heff_drop(v_values_245);
      heff_drop(v_t_248);
      V v_t_249;
      if (heff_strEq_c_lent(v_meta_244, ((V)&g_std_2ecli_2eflagProblem_24cpr_str0), 2)) {
        heff_drop(v_meta_244);
        v_t_249 = ((V)&g_std_2ecli_2eflagProblem_24cpr_str1);
      } else {
        v_t_249 = heff_strAppend(((V)&g_std_2ecli_2eflagProblem_24cpr_str2), v_meta_244);
      }
      V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2eflagProblem_24cpr_str3), v_long_242), v_t_249);
      V v_f_2411 = heff_tag_n(TAG_MissingFlag, 1, (V[]){v_t_2410});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
    } else {
      heff_drop(v_meta_244);
      heff_drop(v_t_248);
      V v_t_2412 = (g_list_2ekeepIf_24s1220809684x843195562(v_long_242, v_fs_240));
      V v_t_2413 = (g_list_2emap_24s1173914895x100384474(v_t_2412));
      HeffT2 v_t_2419 = ({ V b_0 = heff_clo_n(g_std_2ecli_2eflagProblem_24cpr_lam0, 1, 1, (V[]){heff_dup(v_values_245)}); V a_1 = v_t_2413; HeffT2 r_ = (g_list_2efind_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2413); r_; });
      {
        V v_field_2421 = v_t_2419.f[1];
        int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
        if ((v_tag_2420 == ((int64_t)0ULL))) {
          V v_v_2422 = v_field_2421;
          V v_f_2423 = heff_tag_n(TAG_NotIn, 3, (V[]){heff_strAppend(((V)&g_std_2ecli_2eflagProblem_24cpr_str4), v_long_242), v_v_2422, v_values_245});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2423}});
        } else {
          heff_drop(v_long_242);
          heff_drop(v_values_245);
          heff_drop(v_field_2421);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
  }
  case TAG_Cons: {
    V v_ru_24x1_247_24Cons = heff_take_reuse_n(v_x1_247, 0ULL, 2);
    heff_drop(v_required_243);
    heff_drop(v_meta_244);
    V v_t_2426 = (g_list_2ekeepIf_24s1220809684x843195562(v_long_242, v_fs_240));
    V v_t_2427 = (g_list_2emap_24s1173914895x100384474_24tok2(v_ru_24x1_247_24Cons, v_t_2426));
    HeffT2 v_t_2433 = ({ V b_0 = heff_clo_n(g_std_2ecli_2eflagProblem_24cpr_lam1, 1, 1, (V[]){heff_dup(v_values_245)}); V a_1 = v_t_2427; HeffT2 r_ = (g_list_2efind_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_t_2427); r_; });
    {
      V v_field_2435 = v_t_2433.f[1];
      int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
      if ((v_tag_2434 == ((int64_t)0ULL))) {
        V v_v_2436 = v_field_2435;
        V v_f_2437 = heff_tag_n(TAG_NotIn, 3, (V[]){heff_strAppend(((V)&g_std_2ecli_2eflagProblem_24cpr_str5), v_long_242), v_v_2436, v_values_245});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
      } else {
        heff_drop(v_long_242);
        heff_drop(v_values_245);
        heff_drop(v_field_2435);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_247)}});
  }
}
V g_std_2ecli_2eflagProblem_24cpr_lam0(V self, V *args) {
  V v_v_2414 = args[0];
  V v_values_245 = heff_env(self)[0];
  V v_t_2415 = heff_dup(v_values_245);
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nil: {
    heff_drop(v_v_2414);
    heff_drop(self);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_t_2415, 0ULL, 2);
    heff_clo_take(self, 1);
    V v_x1_2418 = ({ V a_0 = v_v_2414; V a_1 = v_values_245; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_v_2414); heff_drop(v_values_245); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2418) == NTAG(TAG_True)));
    heff_drop(v_x1_2418);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_std_2ecli_2eflagProblem_24cpr_lam1(V self, V *args) {
  V v_v_2428 = args[0];
  V v_values_245 = heff_env(self)[0];
  V v_t_2429 = heff_dup(v_values_245);
  switch (heff_tag_of(v_t_2429)) {
  case TAG_Nil: {
    heff_drop(v_v_2428);
    heff_drop(self);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    heff_take_n(v_t_2429, 0ULL, 2);
    heff_clo_take(self, 1);
    V v_x1_2432 = ({ V a_0 = v_v_2428; V a_1 = v_values_245; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_v_2428); heff_drop(v_values_245); r_; });
    V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2432) == NTAG(TAG_True)));
    heff_drop(v_x1_2432);
    return v_ret_24bool;
  }
  default: return heff_nomatch(v_t_2429);
  }
}
HEFF_LIT(g_std_2ecli_2egroupsGo_24cpr_str0, 3, "...");

HeffT2 g_std_2ecli_2egroupsGo_24cpr(V v_x1_240, V v_ws_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_ws_241)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
    }
    case TAG_Cons: {
      V v_w_242 = heff_field(v_ws_241, 0);
      heff_take_n(v_ws_241, 1ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Extra, 1, (V[]){v_w_242})}});
    }
    default: return ((HeffT2){{heff_nomatch(v_ws_241)}});
    }
  }
  case TAG_Cons: {
    V v_x11_244 = heff_field(v_x1_240, 0);
    V v_ps_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_arity_246 = heff_take_field(v_x11_244, 1);
    V v_meta_247 = heff_get_n(v_x11_244, 0, 3);
    V v_arity_248 = v_arity_246;
    V v_m_249 = v_meta_247;
    switch (heff_tag_of(v_arity_248)) {
    case TAG_One: {
      switch (heff_tag_of(v_ws_241)) {
      case TAG_Nil: {
        heff_drop(v_ps_245);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Missing, 1, (V[]){v_m_249})}});
      }
      case TAG_Cons: {
        V v_w_2410 = heff_field(v_ws_241, 0);
        V v_ws2_2411 = heff_field(v_ws_241, 1);
        V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
        heff_drop(v_m_249);
        HeffT2 v_t_2412 = (g_std_2ecli_2egroupsGo_24cpr(v_ps_245, v_ws2_2411));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_w_2410);
            heff_drop_cell(v_ru_24ws_241_24Cons, 2);
            V v_p_2415 = v_field_2414;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2415}});
          } else {
            V v_gs_2416 = v_field_2414;
            V v_t_2417 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_w_2410, NTAG(TAG_Nil)});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24ws_241_24Cons, TAG_Cons, 2, (V[]){v_t_2417, v_gs_2416})}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_ws_241)}});
      }
    }
    case TAG_Optional: {
      heff_drop(v_m_249);
      switch (heff_tag_of(v_ws_241)) {
      case TAG_Nil: {
        HeffT2 v_t_2418 = (g_std_2ecli_2egroupsGo_24cpr(v_ps_245, NTAG(TAG_Nil)));
        {
          V v_field_2420 = v_t_2418.f[1];
          int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
          if ((v_tag_2419 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            V v_p_2421 = v_field_2420;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2421}});
          } else {
            V v_gs_2422 = v_field_2420;
            V v_t_2423 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Nil), v_gs_2422});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2423}});
          }
        }
      }
      case TAG_Cons: {
        V v_w_2424 = heff_field(v_ws_241, 0);
        V v_ws2_2425 = heff_field(v_ws_241, 1);
        V v_ru_24ws_241_24Cons = heff_take_reuse_n(v_ws_241, 3ULL, 2);
        HeffT2 v_t_2426 = (g_std_2ecli_2egroupsGo_24cpr(v_ps_245, v_ws2_2425));
        {
          V v_field_2428 = v_t_2426.f[1];
          int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
          if ((v_tag_2427 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            heff_drop(v_w_2424);
            heff_drop_cell(v_ru_24ws_241_24Cons, 2);
            V v_p_2429 = v_field_2428;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2429}});
          } else {
            V v_gs_2430 = v_field_2428;
            V v_t_2431 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_w_2424, NTAG(TAG_Nil)});
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24ws_241_24Cons, TAG_Cons, 2, (V[]){v_t_2431, v_gs_2430})}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_ws_241)}});
      }
    }
    case TAG_Many: {
      heff_drop(v_m_249);
      HeffT2 v_t_2432 = (g_std_2ecli_2egroupsGo_24cpr(v_ps_245, NTAG(TAG_Nil)));
      {
        V v_field_2434 = v_t_2432.f[1];
        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
        if ((v_tag_2433 == ((int64_t)0ULL))) {
          heff_drop(v_ws_241);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          V v_p_2435 = v_field_2434;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2435}});
        } else {
          V v_gs_2436 = v_field_2434;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, v_gs_2436})}});
        }
      }
    }
    case TAG_Some: {
      switch (heff_tag_of(v_ws_241)) {
      case TAG_Nil: {
        heff_drop(v_ps_245);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V v_f_2437 = heff_tag_n(TAG_Missing, 1, (V[]){heff_strAppend(v_m_249, ((V)&g_std_2ecli_2egroupsGo_24cpr_str0))});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
      }
      case TAG_Cons: {
        heff_drop(v_m_249);
        HeffT2 v_t_2440 = (g_std_2ecli_2egroupsGo_24cpr(v_ps_245, NTAG(TAG_Nil)));
        {
          V v_field_2442 = v_t_2440.f[1];
          int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
          if ((v_tag_2441 == ((int64_t)0ULL))) {
            heff_drop_tag(v_ws_241, 2);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            V v_p_2443 = v_field_2442;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2443}});
          } else {
            V v_gs_2444 = v_field_2442;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, v_gs_2444})}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_ws_241)}});
      }
    }
    case TAG_Rest: {
      heff_drop(v_m_249);
      HeffT2 v_t_2445 = (g_std_2ecli_2egroupsGo_24cpr(v_ps_245, NTAG(TAG_Nil)));
      {
        V v_field_2447 = v_t_2445.f[1];
        int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
        if ((v_tag_2446 == ((int64_t)0ULL))) {
          heff_drop(v_ws_241);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          V v_p_2448 = v_field_2447;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2448}});
        } else {
          V v_gs_2449 = v_field_2447;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_ws_241, v_gs_2449})}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_arity_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}

HeffT2 g_std_2ecli_2efirstJust_24s180945488x1856732267_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    HeffT2 v_t_244 = (g_std_2ecli_2eflagProblem_24cpr(heff_dup(v_lit_240), heff_dup(v_x_242)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_y_247 = v_field_246;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_y_247}});
      } else {
        heff_drop(v_field_246);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_std_2ecli_2eparse_24cpr_lam0(V self, V *args);

HeffT2 g_std_2ecli_2eparse_24cpr(V v_t_240, V v_ws_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  HeffT2 v_t_243 = (g_std_2ecli_2eshapeProblem_24cpr(heff_get_n(v_t_242, 0, 2)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_t_240);
      heff_drop(v_ws_241);
      V v_why_246 = v_field_245;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_BadShape, 1, (V[]){v_why_246})}});
    } else {
      heff_drop(v_field_245);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
      V v_sh_248 = heff_get_n(v_t_247, 0, 2);
      V v_t_249 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_248, 1), MK_INT(0LL)));
      V v_at_2410 = heff_rec_n(5, shape_sh__ra__on__ps__fs, (V[]){v_sh_248, v_t_249, NTAG(TAG_True), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      HeffT2 v_t_2411 = (g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr(v_at_2410, v_ws_241));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          heff_drop(v_t_240);
          V v_p_2414 = v_field_2413;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2414}});
        } else {
          V v_sp_2415 = v_field_2413;
          V v_flags_2416 = heff_take_field(v_sp_2415, 1);
          V v_pos_2417 = heff_get_n(v_sp_2415, 0, 2);
          V v_t_2418 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
          V v_t_2419 = heff_get_n(heff_get_n(v_t_2418, 0, 2), 0, 2);
          HeffT2 v_t_2420 = ({ V a_0 = v_flags_2416; V a_1 = v_t_2419; HeffT2 r_ = (g_std_2ecli_2efirstJust_24s180945488x1856732267_24cpr(a_0, a_1)); heff_drop(v_t_2419); r_; });
          {
            V v_field_2422 = v_t_2420.f[1];
            int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
            if ((v_tag_2421 == ((int64_t)0ULL))) {
              heff_drop(v_t_240);
              heff_drop(v_flags_2416);
              heff_drop(v_pos_2417);
              V v_p_2423 = v_field_2422;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2423}});
            } else {
              heff_drop(v_field_2422);
              V v_t_2424 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
              V v_t_2425 = heff_get_n(heff_get_n(v_t_2424, 0, 2), 1, 2);
              HeffT2 v_t_2426 = (g_std_2ecli_2egroupsGo_24cpr(v_t_2425, v_pos_2417));
              {
                V v_field_2428 = v_t_2426.f[1];
                int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                if ((v_tag_2427 == ((int64_t)0ULL))) {
                  heff_drop(v_t_240);
                  heff_drop(v_flags_2416);
                  V v_p_2429 = v_field_2428;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2429}});
                } else {
                  V v_gs_2430 = v_field_2428;
                  V v_t_2431 = heff_tr(heff_call(heff_dup(v_t_240), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
                  V v_t_2432 = heff_tr(heff_call(v_t_240, 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
                  V v_t_2433 = heff_get_n(heff_get_n(v_t_2432, 0, 2), 0, 2);
                  V v_t_2437 = (g_list_2emap(heff_clo_n(g_std_2ecli_2eparse_24cpr_lam0, 1, 1, (V[]){v_flags_2416}), v_t_2433));
                  V v_t_2438 = heff_tr(heff_call(heff_get_n(v_t_2431, 1, 2), 2, (V[]){v_gs_2430, v_t_2437}));
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2438}});
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_std_2ecli_2eparse_24cpr_lam0(V self, V *args) {
  V v_f_2434 = args[0];
  V v_flags_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = (g_list_2ekeepIf_24s1220809684x843195562(heff_rfield(v_f_2434, 0), v_flags_2416));
  V v_t_2436 = (g_list_2emap_24s1173914895x100384474(v_t_2435));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_f_2434, 0, 8), v_t_2436});
}

HeffT2 g_std_2ecli_2eproblemOf_24cpr(V v_sh_240, V v_ws_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2ecli_2eshapeProblem_24cpr(heff_dup(v_sh_240)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop_rec(v_sh_240, 2);
      heff_drop(v_ws_241);
      V v_why_245 = v_field_244;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_BadShape, 1, (V[]){v_why_245})}});
    } else {
      heff_drop(v_field_244);
      V v_t_246 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_240, 1), MK_INT(0LL)));
      V v_at_247 = heff_rec_n(5, shape_sh__ra__on__ps__fs, (V[]){heff_dup(v_sh_240), v_t_246, NTAG(TAG_True), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      HeffT2 v_t_248 = (g_std_2ecli_2ewordsF_24s1352288509x2021617997_24cpr(v_at_247, v_ws_241));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          heff_drop_rec(v_sh_240, 2);
          V v_p_2411 = v_field_2410;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2411}});
        } else {
          V v_sp_2412 = v_field_2410;
          V v_flags_2413 = heff_take_field(v_sp_2412, 1);
          V v_pos_2414 = heff_get_n(v_sp_2412, 0, 2);
          HeffT2 v_t_2415 = ({ V a_0 = v_flags_2413; V a_1 = heff_rfield(v_sh_240, 0); HeffT2 r_ = (g_std_2ecli_2efirstJust_24s180945488x1856732267_24cpr(a_0, a_1)); heff_drop(v_flags_2413); r_; });
          {
            V v_field_2417 = v_t_2415.f[1];
            int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
            if ((v_tag_2416 == ((int64_t)0ULL))) {
              heff_drop_rec(v_sh_240, 2);
              heff_drop(v_pos_2414);
              V v_p_2418 = v_field_2417;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2418}});
            } else {
              heff_drop(v_field_2417);
              HeffT2 v_t_2419 = (g_std_2ecli_2egroupsGo_24cpr(heff_get_n(v_sh_240, 1, 2), v_pos_2414));
              {
                V v_field_2421 = v_t_2419.f[1];
                int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                if ((v_tag_2420 == ((int64_t)0ULL))) {
                  V v_p_2422 = v_field_2421;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2422}});
                } else {
                  V v_gs_2423 = v_field_2421;
                  heff_drop(v_gs_2423);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
          }
        }
      }
    }
  }
}
HEFF_LIT(g_std_2ecli_2eshortWhere_24scalars_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eshortWhere_24scalars_str1, 0, "");
HEFF_LIT(g_std_2ecli_2eshortWhere_24scalars_str2, 0, "");
Clo g_std_2ecli_2eshortWhere_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eshortWhere_24scalars_entry, 6, 0};

V g_std_2ecli_2eshortWhere_24scalars(V v_sh_240, V v_on_241, V v_waiting_242, V v_count_243, V v_given_244, V v_cl_245) {
top: ;
  if (heff_strEq_c_lent(v_cl_245, ((V)&g_std_2ecli_2eshortWhere_24scalars_str0), 2)) {
    heff_drop(v_cl_245);
    return heff_rec_n(4, shape_on__waiting__count__given, (V[]){heff_dup(v_on_241), heff_dup(v_waiting_242), heff_dup(v_count_243), v_given_244});
  } else {
    V v_x_246 = heff_strSlice_lent(v_cl_245, MK_INT(0LL), MK_INT(1LL), 6);
    if (heff_strEq_c_lent(v_x_246, ((V)&g_std_2ecli_2eshortWhere_24scalars_str1), 2)) {
      heff_drop(v_cl_245);
      heff_drop(v_x_246);
      return heff_rec_n(4, shape_on__waiting__count__given, (V[]){heff_dup(v_on_241), heff_dup(v_waiting_242), heff_dup(v_count_243), v_given_244});
    } else {
      HeffT2 v_t_247 = ({ V a_0 = v_x_246; V a_1 = heff_rfield(v_sh_240, 0); HeffT2 r_ = (g_list_2efind_24s670012890x84869279_24cpr(a_0, a_1)); heff_drop(v_x_246); r_; });
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_f_2410 = v_field_249;
          if (heff_strEq_c(heff_dup(heff_rfield(v_f_2410, 2)), ((V)&g_std_2ecli_2eshortWhere_24scalars_str2))) {
            V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_f_2410, 0, 8), v_given_244});
            V v_t_2412 = heff_strSlice(heff_dup(v_cl_245), MK_INT(1LL), heff_strLength(v_cl_245));
            V t_0 = v_sh_240;
            V t_1 = v_on_241;
            V t_2 = NTAG(TAG_Nothing);
            V t_3 = v_count_243;
            V t_4 = v_t_2411;
            V t_5 = v_t_2412;
            v_sh_240 = t_0;
            v_on_241 = t_1;
            v_waiting_242 = t_2;
            v_count_243 = t_3;
            v_given_244 = t_4;
            v_cl_245 = t_5;
            goto top;
          } else {
            V v_t_2413;
            if ((((int64_t)1ULL) < heff_unbox_word(heff_strLength(v_cl_245)))) {
              v_t_2413 = NTAG(TAG_Nothing);
            } else {
              v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_2410)});
            }
            V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_f_2410, 0, 8), v_given_244});
            return heff_rec_n(4, shape_on__waiting__count__given, (V[]){heff_dup(v_on_241), v_t_2413, heff_dup(v_count_243), v_t_2414});
          }
        } else {
          heff_drop(v_cl_245);
          heff_drop(v_field_249);
          return heff_rec_n(4, shape_on__waiting__count__given, (V[]){heff_dup(v_on_241), heff_dup(v_waiting_242), heff_dup(v_count_243), v_given_244});
        }
      }
    }
  }
}
V g_std_2ecli_2eshortWhere_24scalars_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_std_2ecli_2eshortWhere_24scalars(a0, a1, a2, a3, a[4], a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_std_2ecli_2eshortWhere_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eshortWhere_entry, 3, 0};

V g_std_2ecli_2eshortWhere(V v_sh_240, V v_st_241, V v_cl_242) {
top: ;
  V v_on_243 = heff_take_field(v_st_241, 0);
  V v_waiting_244 = heff_take_field(v_st_241, 1);
  V v_count_245 = heff_take_field(v_st_241, 2);
  V v_given_246 = heff_get_n(v_st_241, 3, 4);
  return ({ V a_0 = v_sh_240; V a_1 = v_on_243; V a_2 = v_waiting_244; V a_3 = v_count_245; V a_4 = v_given_246; V a_5 = v_cl_242; V r_ = (g_std_2ecli_2eshortWhere_24scalars(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_on_243); heff_drop(v_waiting_244); heff_drop(v_count_245); r_; });
}
V g_std_2ecli_2eshortWhere_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eshortWhere(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2eheadOf_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eheadOf_str1, 1, " ");
HEFF_LIT(g_std_2ecli_2eheadOf_str2, 0, "");
HEFF_LIT(g_std_2ecli_2eheadOf_str3, 0, "");
HEFF_LIT(g_std_2ecli_2eheadOf_str4, 1, " ");
HEFF_LIT(g_std_2ecli_2eheadOf_str5, 1, " ");
Clo g_std_2ecli_2eheadOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eheadOf_entry, 1, 0};

V g_std_2ecli_2eheadOf(V v_k_240) {
top: ;
  V v_args_241 = heff_take_field(v_k_240, 3);
  V v_name_242 = heff_get_n(v_k_240, 0, 4);
  V v_t_243 = heff_tr(heff_call(heff_dup(v_args_241), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  V v_sh_244 = heff_get_n(v_t_243, 0, 2);
  V v_pos_245 = heff_take_field(v_sh_244, 1);
  V v_flags_246 = heff_get_n(v_sh_244, 0, 2);
  V v_t_247 = (g_list_2emap_24s2029999044x514618413(v_pos_245));
  V v_t_248 = (g_list_2emap_24s1281445768x1036802655(v_flags_246));
  V v_xs_249 = (g_prelude_2e_2b_2b(v_t_247, v_t_248));
  V v_t_2412;
  switch (heff_tag_of(v_xs_249)) {
  case TAG_Nil: {
    v_t_2412 = ((V)&g_std_2ecli_2eheadOf_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_xs_249, 0);
    V v_xs_2411 = heff_field(v_xs_249, 1);
    heff_take_n(v_xs_249, 3ULL, 2);
    v_t_2412 = ({ V a_0 = ((V)&g_std_2ecli_2eheadOf_str1); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_xs_249);
  }
  if (heff_strEq_c(v_t_2412, ((V)&g_std_2ecli_2eheadOf_str2))) {
    heff_drop(v_args_241);
    return v_name_242;
  } else {
    V v_t_2413 = heff_tr(heff_call(v_args_241, 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_sh_2414 = heff_get_n(v_t_2413, 0, 2);
    V v_pos_2415 = heff_take_field(v_sh_2414, 1);
    V v_flags_2416 = heff_get_n(v_sh_2414, 0, 2);
    V v_t_2417 = (g_list_2emap_24s2029999044x514618413(v_pos_2415));
    V v_t_2418 = (g_list_2emap_24s1281445768x1036802655(v_flags_2416));
    V v_xs_2419 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2418));
    V v_t_2422;
    switch (heff_tag_of(v_xs_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_std_2ecli_2eheadOf_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_xs_2419, 0);
      V v_xs_2421 = heff_field(v_xs_2419, 1);
      heff_take_n(v_xs_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_std_2ecli_2eheadOf_str4); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_xs_2419);
    }
    return heff_strAppend(heff_strAppend(v_name_242, ((V)&g_std_2ecli_2eheadOf_str5)), v_t_2422);
  }
}
V g_std_2ecli_2eheadOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eheadOf(a[0]);
}
HEFF_LIT(g_std_2ecli_2eline2_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2eline2_str1, 0, "");
HEFF_LIT(g_std_2ecli_2eline2_str2, 0, "");
HEFF_LIT(g_std_2ecli_2eline2_str3, 2, "  ");
HEFF_LIT(g_std_2ecli_2eline2_str4, 1, "\012");
HEFF_LIT(g_std_2ecli_2eline2_str5, 1, " ");
HEFF_LIT(g_std_2ecli_2eline2_str6, 0, "");
HEFF_LIT(g_std_2ecli_2eline2_str7, 0, "");
HEFF_LIT(g_std_2ecli_2eline2_str8, 2, "  ");
Clo g_std_2ecli_2eline2_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eline2_entry, 2, 0};

V g_std_2ecli_2eline2(V v_x_240, V v_doc_241) {
top: ;
  if ((((int64_t)26ULL) < heff_unbox_word(heff_strLength_lent(v_x_240, 0)))) {
    V v_x2_242 = (g_list_2ereplicate(MK_INT(30LL), ((V)&g_std_2ecli_2eline2_str0)));
    V v_t_245;
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_std_2ecli_2eline2_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = ((V)&g_std_2ecli_2eline2_str2); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2eline2_str3), v_x_240), ((V)&g_std_2ecli_2eline2_str4));
    return heff_strAppend(heff_strAppend(v_t_246, v_t_245), v_doc_241);
  } else {
    int64_t v_t_247 = (((int64_t)28ULL) - heff_unbox_word(heff_strLength_lent(v_x_240, 0)));
    V v_x2_248 = (g_list_2ereplicate(heff_box_word(v_t_247), ((V)&g_std_2ecli_2eline2_str5)));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_std_2ecli_2eline2_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_std_2ecli_2eline2_str7); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2eline2_str8), v_x_240), v_t_2411);
    return heff_strAppend(v_t_2412, v_doc_241);
  }
}
V g_std_2ecli_2eline2_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eline2(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2eusage_str0, 14, "help [COMMAND]");
HEFF_LIT(g_std_2ecli_2eusage_str1, 26, "this, or a command's flags");
HEFF_LIT(g_std_2ecli_2eusage_str2, 17, "completions SHELL");
HEFF_LIT(g_std_2ecli_2eusage_str3, 48, "a completion script for SHELL: fish, bash or zsh");
HEFF_LIT(g_std_2ecli_2eusage_str4, 7, "usage: ");
HEFF_LIT(g_std_2ecli_2eusage_str5, 12, " COMMAND ...");
HEFF_LIT(g_std_2ecli_2eusage_str6, 1, "\012");
HEFF_LIT(g_std_2ecli_2eusage_str7, 0, "");
HEFF_LIT(g_std_2ecli_2eusage_str8, 1, "\012");
Clo g_std_2ecli_2eusage_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eusage_entry, 2, 0};

V g_std_2ecli_2eusage(V v_prog_240, V v_cs_241) {
top: ;
  V v_t_242 = (g_list_2ekeepIf_24s44384897x1267641110(v_cs_241));
  V v_t_243 = (g_list_2emap_24s296585291x885335139(v_t_242));
  V v_t_244 = (g_std_2ecli_2eline2(((V)&g_std_2ecli_2eusage_str0), ((V)&g_std_2ecli_2eusage_str1)));
  V v_t_245 = (g_std_2ecli_2eline2(((V)&g_std_2ecli_2eusage_str2), ((V)&g_std_2ecli_2eusage_str3)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_ys_247 = (g_prelude_2e_2b_2b(v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_246})));
  V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2eusage_str4), v_prog_240), ((V)&g_std_2ecli_2eusage_str5));
  V v_t_249 = ({ V a_0 = ((V)&g_std_2ecli_2eusage_str6); V a_1 = v_t_248; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2eusage_str7), v_ys_247}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  return heff_strAppend(v_t_249, ((V)&g_std_2ecli_2eusage_str8));
}
V g_std_2ecli_2eusage_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2eusage(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2ehelpOf_str0, 7, "usage: ");
HEFF_LIT(g_std_2ecli_2ehelpOf_str1, 1, " ");
HEFF_LIT(g_std_2ecli_2ehelpOf_str2, 0, "");
HEFF_LIT(g_std_2ecli_2ehelpOf_str3, 6, "flags:");
HEFF_LIT(g_std_2ecli_2ehelpOf_str4, 0, "");
HEFF_LIT(g_std_2ecli_2ehelpOf_str5, 1, "\012");
HEFF_LIT(g_std_2ecli_2ehelpOf_str6, 1, "\012");
Clo g_std_2ecli_2ehelpOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ehelpOf_entry, 2, 0};

V g_std_2ecli_2ehelpOf(V v_prog_240, V v_k_241) {
top: ;
  V v_t_242 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ehelpOf_str0), v_prog_240), ((V)&g_std_2ecli_2ehelpOf_str1));
  V v_t_244 = heff_strAppend(v_t_243, v_t_242);
  V v_t_245 = heff_take_field(v_k_241, 1);
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
  V v_x1_247 = heff_get_n(heff_get_n(v_t_246, 0, 2), 0, 2);
  V v_ys_2413;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nil: {
    heff_drop_rec(v_k_241, 4);
    v_ys_2413 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_ru_24x1_247_24Cons = heff_take_reuse_n(v_x1_247, 0ULL, 2);
    V v_t_2410 = heff_tr(heff_call(heff_get_n(v_k_241, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_t_2411 = heff_get_n(heff_get_n(v_t_2410, 0, 2), 0, 2);
    V v_t_2412 = (g_list_2emap_24s1753874608x910016727(v_t_2411));
    v_ys_2413 = heff_tag_at_n(v_ru_24x1_247_24Cons, TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ehelpOf_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ehelpOf_str3), v_t_2412})});
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ehelpOf_str4), heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_ys_2413})});
  V v_t_2415 = ({ V a_0 = ((V)&g_std_2ecli_2ehelpOf_str5); V a_1 = v_t_244; V a_2 = v_t_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2414, 2); r_; });
  return heff_strAppend(v_t_2415, ((V)&g_std_2ecli_2ehelpOf_str6));
}
V g_std_2ecli_2ehelpOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ehelpOf(a[0], a[1]);
}
HEFF_LIT(g_std_2ecli_2eorList_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eorList_str1, 4, " or ");
HEFF_LIT(g_std_2ecli_2eorList_str2, 2, ", ");
Clo g_std_2ecli_2eorList_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eorList_entry, 1, 0};

V g_std_2ecli_2eorList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_std_2ecli_2eorList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_Cons: {
          V v_y_245 = heff_field(v_x12_242, 0);
          return heff_strAppend(heff_strAppend(heff_dup(v_x_241), ((V)&g_std_2ecli_2eorList_str1)), heff_dup(v_y_245));
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(heff_dup(v_x_241), ((V)&g_std_2ecli_2eorList_str2));
        return (g_std_2ecli_2eorList_24acc(v_x12_242, v_s_249));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eorList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eorList(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2eorList_24acc_str0, 0, "");
HEFF_LIT(g_std_2ecli_2eorList_24acc_str1, 4, " or ");
HEFF_LIT(g_std_2ecli_2eorList_24acc_str2, 2, ", ");
Clo g_std_2ecli_2eorList_24acc_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eorList_24acc_entry, 2, 0};

V g_std_2ecli_2eorList_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_std_2ecli_2eorList_24acc_str0));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return heff_strAppend(v_acc_241, heff_dup(v_x_242));
    }
    case TAG_Cons: {
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_243)) {
        case TAG_Cons: {
          V v_y_246 = heff_field(v_x12_243, 0);
          V v_t_248 = heff_strAppend(heff_strAppend(v_acc_241, heff_dup(v_x_242)), ((V)&g_std_2ecli_2eorList_24acc_str1));
          return heff_strAppend(v_t_248, heff_dup(v_y_246));
        }
        default: return heff_nomatch(v_x12_243);
        }
      }
      case TAG_Cons: {
        V v_s_2411 = heff_strAppend(heff_strAppend(v_acc_241, heff_dup(v_x_242)), ((V)&g_std_2ecli_2eorList_24acc_str2));
        V t_0 = v_x12_243;
        V t_1 = v_s_2411;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eorList_24acc_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eorList_24acc(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2eproblemSaid_str0, 8, "no flag ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str1, 8, "no flag ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str2, 4, "; --");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str3, 1, "\?");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str4, 14, " takes a value");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str5, 15, " takes no value");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str6, 2, "--");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str7, 17, " is the start of ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str8, 10, " is wanted");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str9, 4, " is ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str10, 6, ", not ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str11, 9, "expected ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str12, 16, "too many words: ");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str13, 4, "help");
HEFF_LIT(g_std_2ecli_2eproblemSaid_str14, 34, "the command is described wrongly: ");
Clo g_std_2ecli_2eproblemSaid_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2eproblemSaid_entry, 1, 0};

V g_std_2ecli_2eproblemSaid(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Unknown: {
    V v_w_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nothing: {
      return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str0), heff_dup(v_w_241));
    }
    case TAG_Just: {
      V v_s_243 = heff_field(v_x12_242, 0);
      V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str1), heff_dup(v_w_241)), ((V)&g_std_2ecli_2eproblemSaid_str2));
      return heff_strAppend(heff_strAppend(v_t_244, heff_dup(v_s_243)), ((V)&g_std_2ecli_2eproblemSaid_str3));
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  case TAG_NoValue: {
    V v_w_245 = heff_field(v_x1_240, 0);
    return heff_strAppend(heff_dup(v_w_245), ((V)&g_std_2ecli_2eproblemSaid_str4));
  }
  case TAG_SwitchValue: {
    V v_w_246 = heff_field(v_x1_240, 0);
    return heff_strAppend(heff_dup(v_w_246), ((V)&g_std_2ecli_2eproblemSaid_str5));
  }
  case TAG_Ambiguous: {
    V v_w_247 = heff_field(v_x1_240, 0);
    V v_cands_248 = heff_field(v_x1_240, 1);
    V v_t_249 = (g_list_2emap_24s231073986x752637537(((V)&g_std_2ecli_2eproblemSaid_str6), heff_dup(v_cands_248)));
    V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_std_2ecli_2eorList(a_0)); heff_drop(v_t_249); r_; });
    return heff_strAppend(heff_strAppend(heff_dup(v_w_247), ((V)&g_std_2ecli_2eproblemSaid_str7)), v_t_2410);
  }
  case TAG_MissingFlag: {
    V v_w_2411 = heff_field(v_x1_240, 0);
    return heff_strAppend(heff_dup(v_w_2411), ((V)&g_std_2ecli_2eproblemSaid_str8));
  }
  case TAG_NotIn: {
    V v_w_2412 = heff_field(v_x1_240, 0);
    V v_v_2413 = heff_field(v_x1_240, 1);
    V v_vs_2414 = heff_field(v_x1_240, 2);
    V v_t_2415 = (g_std_2ecli_2eorList(v_vs_2414));
    V v_t_2416 = heff_strAppend(heff_strAppend(heff_dup(v_w_2412), ((V)&g_std_2ecli_2eproblemSaid_str9)), v_t_2415);
    return heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_std_2ecli_2eproblemSaid_str10)), heff_dup(v_v_2413));
  }
  case TAG_Missing: {
    V v_m_2417 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str11), heff_dup(v_m_2417));
  }
  case TAG_Extra: {
    V v_w_2418 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str12), heff_dup(v_w_2418));
  }
  case TAG_Help: {
    return ((V)&g_std_2ecli_2eproblemSaid_str13);
  }
  case TAG_BadShape: {
    V v_why_2419 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_std_2ecli_2eproblemSaid_str14), heff_dup(v_why_2419));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2eproblemSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2eproblemSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2eshells_str0, 4, "fish");
HEFF_LIT(g_std_2ecli_2eshells_str1, 4, "bash");
HEFF_LIT(g_std_2ecli_2eshells_str2, 3, "zsh");
HEFF_TAG_LIT(g_std_2ecli_2eshells_lit3, TAG_Cons, 2, ((V)&g_std_2ecli_2eshells_str2), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_std_2ecli_2eshells_lit4, TAG_Cons, 2, ((V)&g_std_2ecli_2eshells_str1), ((V)&g_std_2ecli_2eshells_lit3));
HEFF_TAG_LIT(g_std_2ecli_2eshells_lit5, TAG_Cons, 2, ((V)&g_std_2ecli_2eshells_str0), ((V)&g_std_2ecli_2eshells_lit4));

static V g_std_2ecli_2eshells_val;
static HEFF_ONCE g_std_2ecli_2eshells_st;
static V g_std_2ecli_2eshells_init(void) {
  return ((V)&g_std_2ecli_2eshells_lit5);
}
V g_std_2ecli_2eshells_get(void) {
  if (HEFF_DONE(g_std_2ecli_2eshells_st)) return g_std_2ecli_2eshells_val;
  return heff_global(&g_std_2ecli_2eshells_val, &g_std_2ecli_2eshells_st, g_std_2ecli_2eshells_init);
}
HEFF_LIT(g_std_2ecli_2ecandidatesText_str0, 2, "--");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str1, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str2, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str4, 1, "\011");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str5, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str6, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str7, 0, "");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str8, 7, ":files ");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str9, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str10, 6, ":dirs\012");
HEFF_LIT(g_std_2ecli_2ecandidatesText_str11, 0, "");
V g_std_2ecli_2ecandidatesText_lam0(V self, V *args);
Clo g_std_2ecli_2ecandidatesText_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecandidatesText_entry, 2, 0};

V g_std_2ecli_2ecandidatesText(V v_sh_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Words: {
    V v_ws_242 = heff_field(v_x2_241, 0);
    V v_x2_2411 = (g_list_2emap(heff_clo_n(g_std_2ecli_2ecandidatesText_lam0, 1, 1, (V[]){v_sh_240}), heff_dup(v_ws_242)));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nil: {
      return ((V)&g_std_2ecli_2ecandidatesText_str6);
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_xs_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return ({ V a_0 = ((V)&g_std_2ecli_2ecandidatesText_str7); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  case TAG_FilesBy: {
    V v_sfx_2414 = heff_field(v_x2_241, 0);
    heff_drop_rec(v_sh_240, 2);
    return heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ecandidatesText_str8), heff_dup(v_sfx_2414)), ((V)&g_std_2ecli_2ecandidatesText_str9));
  }
  case TAG_DirsOnly: {
    heff_drop_rec(v_sh_240, 2);
    return ((V)&g_std_2ecli_2ecandidatesText_str10);
  }
  case TAG_Nothing: {
    heff_drop_rec(v_sh_240, 2);
    return ((V)&g_std_2ecli_2ecandidatesText_str11);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2ecandidatesText_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2ecandidatesText(a[0], a1); heff_drop(a1); return r;
}
V g_std_2ecli_2ecandidatesText_lam0(V self, V *args) {
  V v_w_243 = args[0];
  V v_sh_240 = heff_env(self)[0];
  V v_doc_249;
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_strSlice_lent(v_w_243, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_std_2ecli_2ecandidatesText_str0))) {
    V v_t_244 = heff_strSlice_lent(v_w_243, MK_INT(2LL), heff_strLength_lent(v_w_243, 0), 6);
    HeffT2 v_t_245 = ({ V a_0 = v_t_244; V b_1 = heff_get_n(v_sh_240, 0, 2); HeffT2 r_ = (g_list_2efind_24s1618362284x812128366_24cpr(a_0, b_1)); heff_drop(v_t_244); heff_drop(b_1); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_f_248 = v_field_247;
        v_doc_249 = heff_get_n(v_f_248, 3, 8);
      } else {
        heff_drop(v_field_247);
        v_doc_249 = ((V)&g_std_2ecli_2ecandidatesText_str1);
      }
    }
  } else {
    heff_drop_rec(v_sh_240, 2);
    v_doc_249 = ((V)&g_std_2ecli_2ecandidatesText_str2);
  }
  V v_t_2410;
  if (heff_strEq_c_lent(v_doc_249, ((V)&g_std_2ecli_2ecandidatesText_str3), 2)) {
    heff_drop(v_doc_249);
    v_t_2410 = v_w_243;
  } else {
    v_t_2410 = heff_strAppend(heff_strAppend(v_w_243, ((V)&g_std_2ecli_2ecandidatesText_str4)), v_doc_249);
  }
  return heff_strAppend(v_t_2410, ((V)&g_std_2ecli_2ecandidatesText_str5));
}
HEFF_LIT(g_std_2ecli_2ecompleteWords_str0, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str1, 1, "\011");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str2, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str3, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str4, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str5, 4, "help");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str6, 11, "completions");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str7, 29, "a completion script for SHELL");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str8, 4, "help");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str9, 26, "this, or a command's flags");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str10, 11, "completions");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str11, 29, "a completion script for SHELL");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str12, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str13, 1, "\011");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str14, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str15, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str16, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str17, 4, "help");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str18, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str19, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str20, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str21, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str22, 11, "completions");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str23, 1, "\012");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str24, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str25, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str26, 0, "");
HEFF_LIT(g_std_2ecli_2ecompleteWords_str27, 0, "");
Clo g_std_2ecli_2ecompleteWords_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ecompleteWords_entry, 3, 0};

V g_std_2ecli_2ecompleteWords(V v_cs_240, V v_x2_241, V v_cur_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_cs_243 = v_cs_240;
    V v_cur_244 = v_cur_242;
    V v_x2_245 = (g_list_2emap_24f755592795x444686035(((V)&g_std_2ecli_2ecompleteWords_str0), ((V)&g_std_2ecli_2ecompleteWords_str1), ((V)&g_std_2ecli_2ecompleteWords_str2), MK_INT(0LL), v_cur_244, v_cs_243));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_std_2ecli_2ecompleteWords_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str4); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strSlice(((V)&g_std_2ecli_2ecompleteWords_str5), MK_INT(0LL), heff_strLength_lent(v_cur_244, 0));
    V v_xs_2413;
    if (heff_strEq_c_lent(v_t_249, v_cur_244, 1)) {
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ecli_2ecompleteWords_str6), ((V)&g_std_2ecli_2ecompleteWords_str7)}), NTAG(TAG_Nil)});
      V v_t_2411 = ({ V a_0 = MK_INT(0LL); V a_1 = v_cur_244; V a_2 = v_t_2410; V r_ = (g_list_2ekeepIf_24s920421308x594300259(a_0, a_1, a_2)); heff_drop(v_cur_244); r_; });
      v_xs_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ecli_2ecompleteWords_str8), ((V)&g_std_2ecli_2ecompleteWords_str9)}), v_t_2411});
    } else {
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_std_2ecli_2ecompleteWords_str10), ((V)&g_std_2ecli_2ecompleteWords_str11)}), NTAG(TAG_Nil)});
      v_xs_2413 = ({ V a_0 = MK_INT(0LL); V a_1 = v_cur_244; V a_2 = v_t_2412; V r_ = (g_list_2ekeepIf_24s920421308x594300259(a_0, a_1, a_2)); heff_drop(v_cur_244); r_; });
    }
    V v_x2_2414 = (g_list_2emap_24s501902900x1631592417(((V)&g_std_2ecli_2ecompleteWords_str12), ((V)&g_std_2ecli_2ecompleteWords_str13), ((V)&g_std_2ecli_2ecompleteWords_str14), v_xs_2413));
    V v_t_2417;
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_std_2ecli_2ecompleteWords_str15);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str16); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    return heff_strAppend(v_t_248, v_t_2417);
  }
  case TAG_Cons: {
    V v_x21_2418 = heff_field(v_x2_241, 0);
    V v_x22_2419 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x21_2418, ((V)&g_std_2ecli_2ecompleteWords_str17), 2)) {
      switch (heff_tag_of(v_x22_2419)) {
      case TAG_Nil: {
        V v_x2_2420 = ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str18); V a_1 = MK_INT(0LL); V a_2 = v_cur_242; V a_3 = v_cs_240; V r_ = (g_list_2emap_24f1340051005x157438530_24f1161082868x102492123(a_0, a_1, a_2, a_3)); heff_drop(v_cur_242); r_; });
        switch (heff_tag_of(v_x2_2420)) {
        case TAG_Nil: {
          return ((V)&g_std_2ecli_2ecompleteWords_str19);
        }
        case TAG_Cons: {
          V v_x_2421 = heff_field(v_x2_2420, 0);
          V v_xs_2422 = heff_field(v_x2_2420, 1);
          heff_take_n(v_x2_2420, 3ULL, 2);
          return ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str20); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        }
        default: return heff_nomatch(v_x2_2420);
        }
      }
      case TAG_Cons: {
        HeffT2 v_t_2425 = ({ V a_0 = v_x21_2418; V a_1 = v_cs_240; HeffT2 r_ = (g_list_2efind_24s1867824208x1412174996_24cpr(a_0, a_1)); heff_drop(v_cs_240); r_; });
        {
          V v_field_2427 = v_t_2425.f[1];
          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
          if ((v_tag_2426 == ((int64_t)0ULL))) {
            V v_k_2428 = v_field_2427;
            V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2428, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_t_2430 = heff_tr(heff_call(heff_get_n(v_k_2428, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_sh_2431 = heff_get_n(v_t_2430, 0, 2);
            V v_t_2432 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_2431, 1), MK_INT(0LL)));
            V v_t_2433 = heff_rec_n(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
            V v_t_2434 = ({ V a_0 = v_sh_2431; V a_1 = v_t_2432; V a_2 = v_t_2433; V a_3 = heff_dup(v_x22_2419); V r_ = (g_std_2ecli_2ecomplete_2ewhereGo_242(a_0, a_1, a_2, a_3)); heff_drop(v_t_2432); r_; });
            V v_t_2435 = ({ V a_0 = v_sh_2431; V a_1 = v_cur_242; V a_2 = v_t_2434; V r_ = (g_std_2ecli_2ecomplete_2ecompleteAt_241(a_0, a_1, a_2)); heff_drop(v_cur_242); r_; });
            return ({ V a_0 = heff_get_n(v_t_2429, 0, 2); V a_1 = v_t_2435; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2435); r_; });
          } else {
            heff_drop(v_cur_242);
            heff_drop(v_field_2427);
            return ((V)&g_std_2ecli_2ecompleteWords_str21);
          }
        }
      }
      default: return heff_nomatch(v_x22_2419);
      }
    } else {
      if (heff_strEq_c_lent(v_x21_2418, ((V)&g_std_2ecli_2ecompleteWords_str22), 2)) {
        switch (heff_tag_of(v_x22_2419)) {
        case TAG_Nil: {
          heff_drop(v_cs_240);
          V v_x2_2436 = ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str23); V a_1 = MK_INT(0LL); V a_2 = v_cur_242; V a_3 = heff_dup(g_std_2ecli_2eshells_get()); V r_ = (g_list_2emap_24f1340051005x157438530(a_0, a_1, a_2, a_3)); heff_drop(v_cur_242); r_; });
          switch (heff_tag_of(v_x2_2436)) {
          case TAG_Nil: {
            return ((V)&g_std_2ecli_2ecompleteWords_str24);
          }
          case TAG_Cons: {
            V v_x_2437 = heff_field(v_x2_2436, 0);
            V v_xs_2438 = heff_field(v_x2_2436, 1);
            heff_take_n(v_x2_2436, 3ULL, 2);
            return ({ V a_0 = ((V)&g_std_2ecli_2ecompleteWords_str25); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
          }
          default: return heff_nomatch(v_x2_2436);
          }
        }
        case TAG_Cons: {
          HeffT2 v_t_2441 = ({ V a_0 = v_x21_2418; V a_1 = v_cs_240; HeffT2 r_ = (g_list_2efind_24s1867824208x1412174996_24cpr(a_0, a_1)); heff_drop(v_cs_240); r_; });
          {
            V v_field_2443 = v_t_2441.f[1];
            int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
            if ((v_tag_2442 == ((int64_t)0ULL))) {
              V v_k_2444 = v_field_2443;
              V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2444, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
              V v_t_2446 = heff_tr(heff_call(heff_get_n(v_k_2444, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
              V v_sh_2447 = heff_get_n(v_t_2446, 0, 2);
              V v_t_2448 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_2447, 1), MK_INT(0LL)));
              V v_t_2449 = heff_rec_n(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
              V v_t_2450 = ({ V a_0 = v_sh_2447; V a_1 = v_t_2448; V a_2 = v_t_2449; V a_3 = heff_dup(v_x22_2419); V r_ = (g_std_2ecli_2ecomplete_2ewhereGo_242(a_0, a_1, a_2, a_3)); heff_drop(v_t_2448); r_; });
              V v_t_2451 = ({ V a_0 = v_sh_2447; V a_1 = v_cur_242; V a_2 = v_t_2450; V r_ = (g_std_2ecli_2ecomplete_2ecompleteAt_241(a_0, a_1, a_2)); heff_drop(v_cur_242); r_; });
              return ({ V a_0 = heff_get_n(v_t_2445, 0, 2); V a_1 = v_t_2451; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2451); r_; });
            } else {
              heff_drop(v_cur_242);
              heff_drop(v_field_2443);
              return ((V)&g_std_2ecli_2ecompleteWords_str26);
            }
          }
        }
        default: return heff_nomatch(v_x22_2419);
        }
      } else {
        HeffT2 v_t_2452 = ({ V a_0 = v_x21_2418; V a_1 = v_cs_240; HeffT2 r_ = (g_list_2efind_24s1867824208x1412174996_24cpr(a_0, a_1)); heff_drop(v_cs_240); r_; });
        {
          V v_field_2454 = v_t_2452.f[1];
          int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
          if ((v_tag_2453 == ((int64_t)0ULL))) {
            V v_k_2455 = v_field_2454;
            V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2455, 3)), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_t_2457 = heff_tr(heff_call(heff_get_n(v_k_2455, 3, 4), 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
            V v_sh_2458 = heff_get_n(v_t_2457, 0, 2);
            V v_t_2459 = (g_std_2ecli_2erestIndex(heff_rfield(v_sh_2458, 1), MK_INT(0LL)));
            V v_t_2460 = heff_rec_n(4, shape_on__waiting__count__given, (V[]){NTAG(TAG_True), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil)});
            V v_t_2461 = ({ V a_0 = v_sh_2458; V a_1 = v_t_2459; V a_2 = v_t_2460; V a_3 = heff_dup(v_x22_2419); V r_ = (g_std_2ecli_2ecomplete_2ewhereGo_242(a_0, a_1, a_2, a_3)); heff_drop(v_t_2459); r_; });
            V v_t_2462 = ({ V a_0 = v_sh_2458; V a_1 = v_cur_242; V a_2 = v_t_2461; V r_ = (g_std_2ecli_2ecomplete_2ecompleteAt_241(a_0, a_1, a_2)); heff_drop(v_cur_242); r_; });
            return ({ V a_0 = heff_get_n(v_t_2456, 0, 2); V a_1 = v_t_2462; V r_ = (g_std_2ecli_2ecandidatesText(a_0, a_1)); heff_drop(v_t_2462); r_; });
          } else {
            heff_drop(v_cur_242);
            heff_drop(v_field_2454);
            return ((V)&g_std_2ecli_2ecompleteWords_str27);
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2ecli_2ecompleteWords_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2ecompleteWords(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_std_2ecli_2einitOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einitOf_entry, 1, 0};

V g_std_2ecli_2einitOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
      V v_u_246 = (g_std_2ecli_2einitOf_24dps(v_x12_242, v_cell_245));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einitOf_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2einitOf(a[0]);
}
Clo g_std_2ecli_2einitOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einitOf_24dps_entry, 2, 0};

V g_std_2ecli_2einitOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
      V v_u_247 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_246);
      V t_0 = v_x12_243;
      V t_1 = v_u_247;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2einitOf_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2einitOf_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2ecli_2elastOf_str0, 0, "");
Clo g_std_2ecli_2elastOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2elastOf_entry, 1, 0};

V g_std_2ecli_2elastOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_std_2ecli_2elastOf_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2ecli_2elastOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2ecli_2elastOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_std_2ecli_2efishScript_str0, 2, "# ");
HEFF_LIT(g_std_2ecli_2efishScript_str1, 14, ": written by `");
HEFF_LIT(g_std_2ecli_2efishScript_str2, 18, " completions fish`");
HEFF_LIT(g_std_2ecli_2efishScript_str3, 11, "function __");
HEFF_LIT(g_std_2ecli_2efishScript_str4, 9, "_complete");
HEFF_LIT(g_std_2ecli_2efishScript_str5, 16, "    set -l out (");
HEFF_LIT(g_std_2ecli_2efishScript_str6, 17, " complete $words)");
HEFF_LIT(g_std_2ecli_2efishScript_str7, 12, "complete -c ");
HEFF_LIT(g_std_2ecli_2efishScript_str8, 3, " -e");
HEFF_LIT(g_std_2ecli_2efishScript_str9, 12, "complete -c ");
HEFF_LIT(g_std_2ecli_2efishScript_str10, 11, " -f -a '(__");
HEFF_LIT(g_std_2ecli_2efishScript_str11, 11, "_complete)'");
HEFF_LIT(g_std_2ecli_2efishScript_str12, 9, "function ");
HEFF_LIT(g_std_2ecli_2efishScript_str13, 73, "        set -l f (mktemp (set -q TMPDIR; and echo $TMPDIR; or echo /tmp)/");
HEFF_LIT(g_std_2ecli_2efishScript_str14, 8, ".XXXXXX)");
HEFF_LIT(g_std_2ecli_2efishScript_str15, 0, "");
HEFF_LIT(g_std_2ecli_2efishScript_str16, 8, "        ");
HEFF_LIT(g_std_2ecli_2efishScript_str17, 7, "_CHOSEN");
HEFF_LIT(g_std_2ecli_2efishScript_str18, 12, "=$f command ");
HEFF_LIT(g_std_2ecli_2efishScript_str19, 6, " $argv");
HEFF_LIT(g_std_2ecli_2efishScript_str20, 12, "    command ");
HEFF_LIT(g_std_2ecli_2efishScript_str21, 6, " $argv");
HEFF_LIT(g_std_2ecli_2efishScript_str22, 3, "end");
HEFF_LIT(g_std_2ecli_2efishScript_str23, 7, "    end");
HEFF_LIT(g_std_2ecli_2efishScript_str24, 11, "        end");
HEFF_LIT(g_std_2ecli_2efishScript_str25, 17, "        return $s");
HEFF_LIT(g_std_2ecli_2efishScript_str26, 22, "            eval $line");
HEFF_LIT(g_std_2ecli_2efishScript_str27, 18, "            return");
HEFF_LIT(g_std_2ecli_2efishScript_str28, 35, "            history append -- $line");
HEFF_LIT(g_std_2ecli_2efishScript_str29, 87, "            and history delete --exact --case-sensitive -- (status current-commandline)");
HEFF_LIT(g_std_2ecli_2efishScript_str30, 16, "        rm -f $f");
HEFF_LIT(g_std_2ecli_2efishScript_str31, 26, "        if test -n \"$line\"");
HEFF_LIT(g_std_2ecli_2efishScript_str32, 24, "        set -l s $status");
HEFF_LIT(g_std_2ecli_2efishScript_str33, 41, "        set -l line (string collect < $f)");
HEFF_LIT(g_std_2ecli_2efishScript_str34, 38, "    if isatty stdin; and isatty stdout");
HEFF_LIT(g_std_2ecli_2efishScript_str35, 7, "    end");
HEFF_LIT(g_std_2ecli_2efishScript_str36, 3, "end");
HEFF_LIT(g_std_2ecli_2efishScript_str37, 16, "        case '*'");
HEFF_LIT(g_std_2ecli_2efishScript_str38, 30, "            printf '%s\\n' $out");
HEFF_LIT(g_std_2ecli_2efishScript_str39, 20, "        case ':dirs'");
HEFF_LIT(g_std_2ecli_2efishScript_str40, 57, "            __fish_complete_directories (commandline -ct)");
HEFF_LIT(g_std_2ecli_2efishScript_str41, 23, "        case ':files *'");
HEFF_LIT(g_std_2ecli_2efishScript_str42, 75, "            __fish_complete_suffix (string replace ':files ' '' -- $out[1])");
HEFF_LIT(g_std_2ecli_2efishScript_str43, 20, "    switch \"$out[1]\"");
HEFF_LIT(g_std_2ecli_2efishScript_str44, 53, "    set -l words (commandline -opc) (commandline -ct)");
HEFF_LIT(g_std_2ecli_2efishScript_str45, 19, "    set -e words[1]");
HEFF_LIT(g_std_2ecli_2efishScript_str46, 1, "\012");
Clo g_std_2ecli_2efishScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2efishScript_entry, 1, 0};

V g_std_2ecli_2efishScript(V v_prog_240) {
top: ;
  V v_t_241 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2efishScript_str0), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2efishScript_str1));
  V v_t_242 = heff_strAppend(heff_strAppend(v_t_241, heff_dup(v_prog_240)), ((V)&g_std_2ecli_2efishScript_str2));
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2efishScript_str3), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2efishScript_str4));
  V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2efishScript_str5), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2efishScript_str6));
  V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2efishScript_str7), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2efishScript_str8));
  V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2efishScript_str9), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2efishScript_str10));
  V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, heff_dup(v_prog_240)), ((V)&g_std_2ecli_2efishScript_str11));
  V v_t_248 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str12), heff_dup(v_prog_240));
  V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2efishScript_str13), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2efishScript_str14));
  V v_t_2410 = (g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236(MK_INT(32LL), v_prog_240, MK_INT(0LL), ((V)&g_std_2ecli_2efishScript_str15)));
  V v_t_2411 = heff_strAppend(((V)&g_std_2ecli_2efishScript_str16), heff_strAppend(v_t_2410, ((V)&g_std_2ecli_2efishScript_str17)));
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_std_2ecli_2efishScript_str18)), heff_dup(v_prog_240));
  V v_t_2413 = heff_strAppend(v_t_2412, ((V)&g_std_2ecli_2efishScript_str19));
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2efishScript_str20), v_prog_240), ((V)&g_std_2ecli_2efishScript_str21));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str22), NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str23), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str24), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str25), v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str26), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str27), v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str28), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str29), v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str30), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str31), v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str32), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str33), v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str34), v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str35), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str36), v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str37), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str38), v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str39), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str40), v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str41), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str42), v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str43), v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str44), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2efishScript_str45), v_t_2429})});
  return ({ V a_0 = ((V)&g_std_2ecli_2efishScript_str46); V a_1 = v_t_242; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2430}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_std_2ecli_2efishScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2efishScript(a[0]);
}
HEFF_LIT(g_std_2ecli_2ebashScript_str0, 2, "# ");
HEFF_LIT(g_std_2ecli_2ebashScript_str1, 14, ": written by `");
HEFF_LIT(g_std_2ecli_2ebashScript_str2, 18, " completions bash`");
HEFF_LIT(g_std_2ecli_2ebashScript_str3, 1, "_");
HEFF_LIT(g_std_2ecli_2ebashScript_str4, 4, "() {");
HEFF_LIT(g_std_2ecli_2ebashScript_str5, 49, "  while IFS= read -r w; do out+=(\"$w\"); done < <(");
HEFF_LIT(g_std_2ecli_2ebashScript_str6, 26, " complete \"${words[@]:1}\")");
HEFF_LIT(g_std_2ecli_2ebashScript_str7, 26, "complete -o filenames -F _");
HEFF_LIT(g_std_2ecli_2ebashScript_str8, 1, " ");
HEFF_LIT(g_std_2ecli_2ebashScript_str9, 4, "() {");
HEFF_LIT(g_std_2ecli_2ebashScript_str10, 32, "    f=$(mktemp \"${TMPDIR:-/tmp}/");
HEFF_LIT(g_std_2ecli_2ebashScript_str11, 23, ".XXXXXX\") || { command ");
HEFF_LIT(g_std_2ecli_2ebashScript_str12, 16, " \"$@\"; return; }");
HEFF_LIT(g_std_2ecli_2ebashScript_str13, 0, "");
HEFF_LIT(g_std_2ecli_2ebashScript_str14, 4, "    ");
HEFF_LIT(g_std_2ecli_2ebashScript_str15, 7, "_CHOSEN");
HEFF_LIT(g_std_2ecli_2ebashScript_str16, 12, "=$f command ");
HEFF_LIT(g_std_2ecli_2ebashScript_str17, 11, " \"$@\"; s=$\?");
HEFF_LIT(g_std_2ecli_2ebashScript_str18, 18, "      [[ $last == ");
HEFF_LIT(g_std_2ecli_2ebashScript_str19, 14, " || $last == \"");
HEFF_LIT(g_std_2ecli_2ebashScript_str20, 31, " \"* ]] && history -s -- \"$line\"");
HEFF_LIT(g_std_2ecli_2ebashScript_str21, 10, "  command ");
HEFF_LIT(g_std_2ecli_2ebashScript_str22, 5, " \"$@\"");
HEFF_LIT(g_std_2ecli_2ebashScript_str23, 1, "}");
HEFF_LIT(g_std_2ecli_2ebashScript_str24, 4, "  fi");
HEFF_LIT(g_std_2ecli_2ebashScript_str25, 6, "    fi");
HEFF_LIT(g_std_2ecli_2ebashScript_str26, 13, "    return $s");
HEFF_LIT(g_std_2ecli_2ebashScript_str27, 18, "      eval \"$line\"");
HEFF_LIT(g_std_2ecli_2ebashScript_str28, 12, "      return");
HEFF_LIT(g_std_2ecli_2ebashScript_str29, 32, "      read -r _ last <<< \"$last\"");
HEFF_LIT(g_std_2ecli_2ebashScript_str30, 27, "    if [[ -n $line ]]; then");
HEFF_LIT(g_std_2ecli_2ebashScript_str31, 47, "      last=$(HISTTIMEFORMAT= builtin history 1)");
HEFF_LIT(g_std_2ecli_2ebashScript_str32, 29, "    line=$(<\"$f\"); rm -f \"$f\"");
HEFF_LIT(g_std_2ecli_2ebashScript_str33, 23, "    local f s line last");
HEFF_LIT(g_std_2ecli_2ebashScript_str34, 29, "  if [[ -t 0 && -t 1 ]]; then");
HEFF_LIT(g_std_2ecli_2ebashScript_str35, 1, "}");
HEFF_LIT(g_std_2ecli_2ebashScript_str36, 13, "      done ;;");
HEFF_LIT(g_std_2ecli_2ebashScript_str37, 6, "  esac");
HEFF_LIT(g_std_2ecli_2ebashScript_str38, 77, "        if [[ $last == *=* ]]; then w=${w#*=}; [[ $cur == = ]] && w=\"=$w\"; fi");
HEFF_LIT(g_std_2ecli_2ebashScript_str39, 25, "        COMPREPLY+=(\"$w\")");
HEFF_LIT(g_std_2ecli_2ebashScript_str40, 30, "      for w in \"${out[@]}\"; do");
HEFF_LIT(g_std_2ecli_2ebashScript_str41, 22, "        w=${w%%$'\\t'*}");
HEFF_LIT(g_std_2ecli_2ebashScript_str42, 51, "    ':dirs') COMPREPLY=($(compgen -d -- \"$cur\")) ;;");
HEFF_LIT(g_std_2ecli_2ebashScript_str43, 6, "    *)");
HEFF_LIT(g_std_2ecli_2ebashScript_str44, 21, "  case \"${out[0]}\" in");
HEFF_LIT(g_std_2ecli_2ebashScript_str45, 103, "    ':files '*) COMPREPLY=($(compgen -d -- \"$cur\") $(compgen -f -X \"!*${out[0]#:files }\" -- \"$cur\")) ;;");
HEFF_LIT(g_std_2ecli_2ebashScript_str46, 14, "  COMPREPLY=()");
HEFF_LIT(g_std_2ecli_2ebashScript_str47, 58, "  [[ $line == *' ' || ${#words[@]} -eq 1 ]] && words+=('')");
HEFF_LIT(g_std_2ecli_2ebashScript_str48, 31, "  last=${words[${#words[@]}-1]}");
HEFF_LIT(g_std_2ecli_2ebashScript_str49, 20, "  local -a words out");
HEFF_LIT(g_std_2ecli_2ebashScript_str50, 28, "  read -ra words <<< \"$line\"");
HEFF_LIT(g_std_2ecli_2ebashScript_str51, 75, "  local line=${COMP_LINE:0:COMP_POINT} cur=${COMP_WORDS[COMP_CWORD]} w last");
HEFF_LIT(g_std_2ecli_2ebashScript_str52, 1, "\012");
Clo g_std_2ecli_2ebashScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ebashScript_entry, 1, 0};

V g_std_2ecli_2ebashScript(V v_prog_240) {
top: ;
  V v_t_241 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ebashScript_str0), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ebashScript_str1));
  V v_t_242 = heff_strAppend(heff_strAppend(v_t_241, heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ebashScript_str2));
  V v_t_243 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ebashScript_str3), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ebashScript_str4));
  V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ebashScript_str5), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ebashScript_str6));
  V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ebashScript_str7), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ebashScript_str8));
  V v_t_246 = heff_strAppend(v_t_245, heff_dup(v_prog_240));
  V v_t_247 = heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ebashScript_str9));
  V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ebashScript_str10), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ebashScript_str11));
  V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ebashScript_str12));
  V v_t_2410 = (g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236(MK_INT(32LL), v_prog_240, MK_INT(0LL), ((V)&g_std_2ecli_2ebashScript_str13)));
  V v_t_2411 = heff_strAppend(((V)&g_std_2ecli_2ebashScript_str14), heff_strAppend(v_t_2410, ((V)&g_std_2ecli_2ebashScript_str15)));
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_std_2ecli_2ebashScript_str16)), heff_dup(v_prog_240));
  V v_t_2413 = heff_strAppend(v_t_2412, ((V)&g_std_2ecli_2ebashScript_str17));
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ebashScript_str18), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ebashScript_str19));
  V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ebashScript_str20));
  V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ebashScript_str21), v_prog_240), ((V)&g_std_2ecli_2ebashScript_str22));
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str23), NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str24), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str25), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str26), v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str27), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str28), v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str29), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str30), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str31), v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str32), v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str33), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str34), v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str35), heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str36), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str37), v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str38), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str39), v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str40), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str41), v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str42), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str43), v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str44), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str45), v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str46), v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str47), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str48), v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str49), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str50), v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ebashScript_str51), v_t_2434})});
  return ({ V a_0 = ((V)&g_std_2ecli_2ebashScript_str52); V a_1 = v_t_242; V a_2 = v_t_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2435, 2); r_; });
}
V g_std_2ecli_2ebashScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ebashScript(a[0]);
}
HEFF_LIT(g_std_2ecli_2ezshScript_str0, 0, "");
HEFF_LIT(g_std_2ecli_2ezshScript_str1, 2, "# ");
HEFF_LIT(g_std_2ecli_2ezshScript_str2, 14, ": written by `");
HEFF_LIT(g_std_2ecli_2ezshScript_str3, 17, " completions zsh`");
HEFF_LIT(g_std_2ecli_2ezshScript_str4, 1, "_");
HEFF_LIT(g_std_2ecli_2ezshScript_str5, 4, "() {");
HEFF_LIT(g_std_2ecli_2ezshScript_str6, 16, "  out=(\"${(@f)$(");
HEFF_LIT(g_std_2ecli_2ezshScript_str7, 38, " complete \"${(@)words[2,CURRENT]}\")}\")");
HEFF_LIT(g_std_2ecli_2ezshScript_str8, 16, "      _describe ");
HEFF_LIT(g_std_2ecli_2ezshScript_str9, 9, " cands ;;");
HEFF_LIT(g_std_2ecli_2ezshScript_str10, 24, "if [ \"$funcstack[1]\" = _");
HEFF_LIT(g_std_2ecli_2ezshScript_str11, 10, " ]; then _");
HEFF_LIT(g_std_2ecli_2ezshScript_str12, 11, " \"$@\"; else");
HEFF_LIT(g_std_2ecli_2ezshScript_str13, 9, "compdef _");
HEFF_LIT(g_std_2ecli_2ezshScript_str14, 1, " ");
HEFF_LIT(g_std_2ecli_2ezshScript_str15, 32, "    f=$(mktemp \"${TMPDIR:-/tmp}/");
HEFF_LIT(g_std_2ecli_2ezshScript_str16, 23, ".XXXXXX\") || { command ");
HEFF_LIT(g_std_2ecli_2ezshScript_str17, 15, " \"$@\"; return }");
HEFF_LIT(g_std_2ecli_2ezshScript_str18, 6, "      ");
HEFF_LIT(g_std_2ecli_2ezshScript_str19, 7, "_CHOSEN");
HEFF_LIT(g_std_2ecli_2ezshScript_str20, 12, "=$f command ");
HEFF_LIT(g_std_2ecli_2ezshScript_str21, 10, "  command ");
HEFF_LIT(g_std_2ecli_2ezshScript_str22, 5, " \"$@\"");
HEFF_LIT(g_std_2ecli_2ezshScript_str23, 2, "__");
HEFF_LIT(g_std_2ecli_2ezshScript_str24, 22, "_history() { [[ $1 != ");
HEFF_LIT(g_std_2ecli_2ezshScript_str25, 10, "$'\\n' ]] }");
HEFF_LIT(g_std_2ecli_2ezshScript_str26, 29, "add-zsh-hook zshaddhistory __");
HEFF_LIT(g_std_2ecli_2ezshScript_str27, 8, "_history");
HEFF_LIT(g_std_2ecli_2ezshScript_str28, 2, "fi");
HEFF_LIT(g_std_2ecli_2ezshScript_str29, 25, "autoload -Uz add-zsh-hook");
HEFF_LIT(g_std_2ecli_2ezshScript_str30, 1, "}");
HEFF_LIT(g_std_2ecli_2ezshScript_str31, 4, "  fi");
HEFF_LIT(g_std_2ecli_2ezshScript_str32, 74, "    if [[ -n $line ]]; then print -rs -- \"$line\"; eval \"$line\"; return; fi");
HEFF_LIT(g_std_2ecli_2ezshScript_str33, 13, "    return $s");
HEFF_LIT(g_std_2ecli_2ezshScript_str34, 17, "      line=$(<$f)");
HEFF_LIT(g_std_2ecli_2ezshScript_str35, 25, "    } always { rm -f $f }");
HEFF_LIT(g_std_2ecli_2ezshScript_str36, 11, " \"$@\"; s=$\?");
HEFF_LIT(g_std_2ecli_2ezshScript_str37, 5, "    {");
HEFF_LIT(g_std_2ecli_2ezshScript_str38, 29, "  if [[ -t 0 && -t 1 ]]; then");
HEFF_LIT(g_std_2ecli_2ezshScript_str39, 18, "    local f s line");
HEFF_LIT(g_std_2ecli_2ezshScript_str40, 4, "() {");
HEFF_LIT(g_std_2ecli_2ezshScript_str41, 1, "}");
HEFF_LIT(g_std_2ecli_2ezshScript_str42, 6, "  esac");
HEFF_LIT(g_std_2ecli_2ezshScript_str43, 10, "        fi");
HEFF_LIT(g_std_2ecli_2ezshScript_str44, 10, "      done");
HEFF_LIT(g_std_2ecli_2ezshScript_str45, 12, "        else");
HEFF_LIT(g_std_2ecli_2ezshScript_str46, 32, "          cands+=(\"${l//:/\\\\:}\")");
HEFF_LIT(g_std_2ecli_2ezshScript_str47, 36, "        if [[ $l == *$'\\t'* ]]; then");
HEFF_LIT(g_std_2ecli_2ezshScript_str48, 55, "          cands+=(\"${${l%%$'\\t'*}//:/\\\\:}:${l#*$'\\t'}\")");
HEFF_LIT(g_std_2ecli_2ezshScript_str49, 23, "      for l in $out; do");
HEFF_LIT(g_std_2ecli_2ezshScript_str50, 31, "        [[ -z $l ]] && continue");
HEFF_LIT(g_std_2ecli_2ezshScript_str51, 25, "    ':dirs') _files -/ ;;");
HEFF_LIT(g_std_2ecli_2ezshScript_str52, 6, "    *)");
HEFF_LIT(g_std_2ecli_2ezshScript_str53, 17, "  case $out[1] in");
HEFF_LIT(g_std_2ecli_2ezshScript_str54, 49, "    ':files '*) _files -g \"*${out[1]#:files }\" ;;");
HEFF_LIT(g_std_2ecli_2ezshScript_str55, 9, "  local l");
HEFF_LIT(g_std_2ecli_2ezshScript_str56, 20, "  local -a out cands");
HEFF_LIT(g_std_2ecli_2ezshScript_str57, 9, "#compdef ");
HEFF_LIT(g_std_2ecli_2ezshScript_str58, 0, "");
HEFF_LIT(g_std_2ecli_2ezshScript_str59, 1, "\012");
Clo g_std_2ecli_2ezshScript_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2ezshScript_entry, 1, 0};

V g_std_2ecli_2ezshScript(V v_prog_240) {
top: ;
  V v_t_241 = (g_prelude_2emapRunes_2emapRunesFrom_240_24s880034364x1138731236(MK_INT(32LL), v_prog_240, MK_INT(0LL), ((V)&g_std_2ecli_2ezshScript_str0)));
  V v_t_242 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str1), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str2));
  V v_t_243 = heff_strAppend(heff_strAppend(v_t_242, heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str3));
  V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str4), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str5));
  V v_t_245 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str6), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str7));
  V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str8), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str9));
  V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str10), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str11));
  V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str12));
  V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str13), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str14));
  V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str15), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str16));
  V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str17));
  V v_t_2412 = heff_strAppend(((V)&g_std_2ecli_2ezshScript_str18), heff_strAppend(v_t_241, ((V)&g_std_2ecli_2ezshScript_str19)));
  V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_std_2ecli_2ezshScript_str20)), heff_dup(v_prog_240));
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str21), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str22));
  V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str23), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str24));
  V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str25));
  V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_std_2ecli_2ezshScript_str26), heff_dup(v_prog_240)), ((V)&g_std_2ecli_2ezshScript_str27));
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str28), NTAG(TAG_Nil)});
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str29), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str30), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str31), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str32), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str33), v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str34), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str35), v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_std_2ecli_2ezshScript_str36)), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str37), v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str38), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str39), v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2ezshScript_str40)), v_t_2426});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_249, heff_dup(v_prog_240)), v_t_2427});
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str41), heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str42), v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str43), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str44), v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str45), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str46), v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str47), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str48), v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str49), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str50), v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str51), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str52), v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str53), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str54), v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str55), heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_std_2ecli_2ezshScript_str56), v_t_2437})});
  V v_xs_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_std_2ecli_2ezshScript_str57), v_prog_240), heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2438})});
  switch (heff_tag_of(v_xs_2439)) {
  case TAG_Nil: {
    return ((V)&g_std_2ecli_2ezshScript_str58);
  }
  case TAG_Cons: {
    V v_x_2440 = heff_field(v_xs_2439, 0);
    V v_xs_2441 = heff_field(v_xs_2439, 1);
    heff_take_n(v_xs_2439, 3ULL, 2);
    return ({ V a_0 = ((V)&g_std_2ecli_2ezshScript_str59); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
  }
  default: return heff_nomatch(v_xs_2439);
  }
}
V g_std_2ecli_2ezshScript_entry(V self, V *a) {
  (void)self;
  return g_std_2ecli_2ezshScript(a[0]);
}
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str0, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str1, 2, ": ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str2, 8, "\012usage: ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str3, 1, " ");
HEFF_LIT(g_std_2ecli_2eoutcomeOf_24cpr_str4, 1, "\012");

HeffT2 g_std_2ecli_2eoutcomeOf_24cpr(V v_prog_240, V v_k_241, V v_ws_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2ecli_2eparse_24cpr(heff_dup(heff_rfield(v_k_241, 3)), v_ws_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_245;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_Help: {
        V v_t_247 = (g_std_2ecli_2ehelpOf(v_prog_240, v_k_241));
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_247}});
      }
      default: {
        V v_t_248 = ({ V a_0 = v_it1_246; V r_ = (g_std_2ecli_2eproblemSaid(a_0)); heff_drop(v_it1_246); r_; });
        V v_t_249 = (g_std_2ecli_2eheadOf(heff_dup(v_k_241)));
        V v_t_2410 = heff_strAppend(heff_strAppend(heff_dup(v_prog_240), ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str0)), heff_get_n(v_k_241, 0, 4));
        V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str1)), v_t_248);
        V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str2)), v_prog_240);
        V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str3)), v_t_249);
        V v_f_2414 = heff_strAppend(v_t_2413, ((V)&g_std_2ecli_2eoutcomeOf_24cpr_str4));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
      }
      }
    } else {
      heff_drop(v_prog_240);
      heff_drop_rec(v_k_241, 4);
      V v_x_2415 = v_field_245;
      return ((HeffT2){{heff_word_i64(((int64_t)2ULL)), v_x_2415}});
    }
  }
}
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str0, 4, "help");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str1, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str2, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str3, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str4, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str5, 6, "--help");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str6, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str7, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str8, 2, "-h");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str9, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str10, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str11, 11, "completions");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str12, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str13, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str14, 4, "fish");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str15, 4, "bash");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str16, 3, "zsh");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str17, 25, " completions: a shell is ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str18, 6, ", not ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str19, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str20, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str21, 1, "\012");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str22, 8, "complete");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str23, 13, ": no command ");
HEFF_LIT(g_std_2ecli_2ereadLine_24cpr_str24, 1, "\012");

HeffT2 g_std_2ecli_2ereadLine_24cpr(V v_prog_240, V v_cs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    V v_t_243 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_243}});
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_x32_245 = heff_field(v_x3_242, 1);
    if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_24cpr_str0), 2)) {
      switch (heff_tag_of(v_x32_245)) {
      case TAG_Nil: {
        V v_t_246 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_246}});
      }
      case TAG_Cons: {
        V v_x322_248 = heff_field(v_x32_245, 1);
        switch (heff_tag_of(v_x322_248)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x32_245)) {
          case TAG_Cons: {
            V v_w_249 = heff_field(v_x32_245, 0);
            HeffT2 v_t_2411 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_w_249, v_cs_241));
            {
              V v_field_2413 = v_t_2411.f[1];
              int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
              if ((v_tag_2412 == ((int64_t)0ULL))) {
                heff_drop(v_cs_241);
                V v_k_2414 = v_field_2413;
                V v_t_2415 = (g_std_2ecli_2ehelpOf(v_prog_240, v_k_2414));
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2415}});
              } else {
                heff_drop(v_field_2413);
                V v_t_2416 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
                V v_t_2417 = heff_strAppend(heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2ereadLine_24cpr_str1)), heff_dup(v_w_249));
                V v_f_2418 = heff_strAppend(heff_strAppend(v_t_2417, ((V)&g_std_2ecli_2ereadLine_24cpr_str2)), v_t_2416);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x32_245)}});
          }
        }
        case TAG_Cons: {
          HeffT2 v_t_2421 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_x31_244, v_cs_241));
          {
            V v_field_2423 = v_t_2421.f[1];
            int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
            if ((v_tag_2422 == ((int64_t)0ULL))) {
              heff_drop(v_cs_241);
              V v_k_2424 = v_field_2423;
              HEFF_LAST return g_std_2ecli_2eoutcomeOf_24cpr(v_prog_240, v_k_2424, heff_dup(v_x32_245));
            } else {
              heff_drop(v_field_2423);
              V v_t_2425 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
              V v_t_2426 = heff_strAppend(heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2ereadLine_24cpr_str3)), heff_dup(v_x31_244));
              V v_f_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_std_2ecli_2ereadLine_24cpr_str4)), v_t_2425);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2427}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x322_248)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x32_245)}});
      }
    } else {
      if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_24cpr_str5), 2)) {
        switch (heff_tag_of(v_x32_245)) {
        case TAG_Nil: {
          V v_t_2428 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2428}});
        }
        case TAG_Cons: {
          HeffT2 v_t_2431 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_x31_244, v_cs_241));
          {
            V v_field_2433 = v_t_2431.f[1];
            int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
            if ((v_tag_2432 == ((int64_t)0ULL))) {
              heff_drop(v_cs_241);
              V v_k_2434 = v_field_2433;
              HEFF_LAST return g_std_2ecli_2eoutcomeOf_24cpr(v_prog_240, v_k_2434, heff_dup(v_x32_245));
            } else {
              heff_drop(v_field_2433);
              V v_t_2435 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
              V v_t_2436 = heff_strAppend(heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2ereadLine_24cpr_str6)), heff_dup(v_x31_244));
              V v_f_2437 = heff_strAppend(heff_strAppend(v_t_2436, ((V)&g_std_2ecli_2ereadLine_24cpr_str7)), v_t_2435);
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x32_245)}});
        }
      } else {
        if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_24cpr_str8), 2)) {
          switch (heff_tag_of(v_x32_245)) {
          case TAG_Nil: {
            V v_t_2438 = (g_std_2ecli_2eusage(v_prog_240, v_cs_241));
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2438}});
          }
          case TAG_Cons: {
            HeffT2 v_t_2441 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_x31_244, v_cs_241));
            {
              V v_field_2443 = v_t_2441.f[1];
              int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
              if ((v_tag_2442 == ((int64_t)0ULL))) {
                heff_drop(v_cs_241);
                V v_k_2444 = v_field_2443;
                HEFF_LAST return g_std_2ecli_2eoutcomeOf_24cpr(v_prog_240, v_k_2444, heff_dup(v_x32_245));
              } else {
                heff_drop(v_field_2443);
                V v_t_2445 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
                V v_t_2446 = heff_strAppend(heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2ereadLine_24cpr_str9)), heff_dup(v_x31_244));
                V v_f_2447 = heff_strAppend(heff_strAppend(v_t_2446, ((V)&g_std_2ecli_2ereadLine_24cpr_str10)), v_t_2445);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2447}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x32_245)}});
          }
        } else {
          if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_24cpr_str11), 2)) {
            switch (heff_tag_of(v_x32_245)) {
            case TAG_Nil: {
              HeffT2 v_t_2448 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_x31_244, v_cs_241));
              {
                V v_field_2450 = v_t_2448.f[1];
                int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
                if ((v_tag_2449 == ((int64_t)0ULL))) {
                  heff_drop(v_cs_241);
                  V v_k_2451 = v_field_2450;
                  HEFF_LAST return g_std_2ecli_2eoutcomeOf_24cpr(v_prog_240, v_k_2451, heff_dup(v_x32_245));
                } else {
                  heff_drop(v_field_2450);
                  V v_t_2452 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
                  V v_t_2453 = heff_strAppend(heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2ereadLine_24cpr_str12)), heff_dup(v_x31_244));
                  V v_f_2454 = heff_strAppend(heff_strAppend(v_t_2453, ((V)&g_std_2ecli_2ereadLine_24cpr_str13)), v_t_2452);
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2454}});
                }
              }
            }
            case TAG_Cons: {
              V v_x322_2456 = heff_field(v_x32_245, 1);
              switch (heff_tag_of(v_x322_2456)) {
              case TAG_Nil: {
                heff_drop(v_cs_241);
                switch (heff_tag_of(v_x32_245)) {
                case TAG_Cons: {
                  V v_sh_2457 = heff_field(v_x32_245, 0);
                  if (heff_strEq_c_lent(v_sh_2457, ((V)&g_std_2ecli_2ereadLine_24cpr_str14), 2)) {
                    V v_t_2459 = (g_std_2ecli_2efishScript(v_prog_240));
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2459}});
                  } else {
                    if (heff_strEq_c_lent(v_sh_2457, ((V)&g_std_2ecli_2ereadLine_24cpr_str15), 2)) {
                      V v_t_2460 = (g_std_2ecli_2ebashScript(v_prog_240));
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2460}});
                    } else {
                      if (heff_strEq_c_lent(v_sh_2457, ((V)&g_std_2ecli_2ereadLine_24cpr_str16), 2)) {
                        V v_t_2461 = (g_std_2ecli_2ezshScript(v_prog_240));
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2461}});
                      } else {
                        V v_t_2462 = ({ V b_0 = heff_dup(g_std_2ecli_2eshells_get()); V r_ = (g_std_2ecli_2eorList(b_0)); heff_drop(b_0); r_; });
                        V v_t_2463 = heff_strAppend(heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2ereadLine_24cpr_str17)), v_t_2462);
                        V v_t_2464 = heff_strAppend(heff_strAppend(v_t_2463, ((V)&g_std_2ecli_2ereadLine_24cpr_str18)), heff_dup(v_sh_2457));
                        V v_f_2465 = heff_strAppend(v_t_2464, ((V)&g_std_2ecli_2ereadLine_24cpr_str19));
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2465}});
                      }
                    }
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x32_245)}});
                }
              }
              case TAG_Cons: {
                HeffT2 v_t_2468 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_x31_244, v_cs_241));
                {
                  V v_field_2470 = v_t_2468.f[1];
                  int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
                  if ((v_tag_2469 == ((int64_t)0ULL))) {
                    heff_drop(v_cs_241);
                    V v_k_2471 = v_field_2470;
                    HEFF_LAST return g_std_2ecli_2eoutcomeOf_24cpr(v_prog_240, v_k_2471, heff_dup(v_x32_245));
                  } else {
                    heff_drop(v_field_2470);
                    V v_t_2472 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
                    V v_t_2473 = heff_strAppend(heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2ereadLine_24cpr_str20)), heff_dup(v_x31_244));
                    V v_f_2474 = heff_strAppend(heff_strAppend(v_t_2473, ((V)&g_std_2ecli_2ereadLine_24cpr_str21)), v_t_2472);
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2474}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x322_2456)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x32_245)}});
            }
          } else {
            if (heff_strEq_c_lent(v_x31_244, ((V)&g_std_2ecli_2ereadLine_24cpr_str22), 2)) {
              heff_drop(v_prog_240);
              V v_t_2475 = (g_std_2ecli_2einitOf(heff_dup(v_x32_245)));
              V v_t_2476 = (g_std_2ecli_2elastOf(v_x32_245));
              V v_t_2477 = ({ V a_0 = v_cs_241; V a_1 = v_t_2475; V a_2 = v_t_2476; V r_ = (g_std_2ecli_2ecompleteWords(a_0, a_1, a_2)); heff_drop(v_t_2475); r_; });
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_2477}});
            } else {
              HeffT2 v_t_2478 = (g_list_2efind_24s1867824208x1412174996_24cpr(v_x31_244, v_cs_241));
              {
                V v_field_2480 = v_t_2478.f[1];
                int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
                if ((v_tag_2479 == ((int64_t)0ULL))) {
                  heff_drop(v_cs_241);
                  V v_k_2481 = v_field_2480;
                  HEFF_LAST return g_std_2ecli_2eoutcomeOf_24cpr(v_prog_240, v_k_2481, heff_dup(v_x32_245));
                } else {
                  heff_drop(v_field_2480);
                  V v_t_2482 = (g_std_2ecli_2eusage(heff_dup(v_prog_240), v_cs_241));
                  V v_t_2483 = heff_strAppend(heff_strAppend(v_prog_240, ((V)&g_std_2ecli_2ereadLine_24cpr_str23)), heff_dup(v_x31_244));
                  V v_f_2484 = heff_strAppend(heff_strAppend(v_t_2483, ((V)&g_std_2ecli_2ereadLine_24cpr_str24)), v_t_2482);
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2484}});
                }
              }
            }
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}