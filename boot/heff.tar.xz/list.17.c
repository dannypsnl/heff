// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ArgEvidence 24309
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_BadShape 33347
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Done 47505
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_EProject 35489
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_ExplicitParam 63083
#define TAG_Given 9359
#define TAG_GivenBuilt 47694
#define TAG_GivenOther 31238
#define TAG_GivenSame 9069
#define TAG_GivenU 27811
#define TAG_IVal 40987
#define TAG_ImplicitParam 51130
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_Keep 49586
#define TAG_Left 13886
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkCArm 24694
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkRegex 19093
#define TAG_NoShape 40346
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Positional 16703
#define TAG_RLocal 34280
#define TAG_RecordShape 6130
#define TAG_Right 62770
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagShape 40544
#define TAG_TagVariant 25174
#define TAG_Typed 36072
#define TAG_WordAdd 60179
#define TAG_WordDiv 63235
#define TAG_WordEq 48587
#define TAG_WordLe 48792
#define TAG_WordLt 48807
#define TAG_WordMod 6526
#define TAG_WordMul 6720
#define TAG_WordQuot 65290
#define TAG_WordRem 11030
#define TAG_WordSub 12476
#define TAG_WordToFloat 50865
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_branches 719731544
#define LBL_caps 9541544
#define LBL_cons 9554936
#define LBL_current 1358797751
#define LBL_doc 309170
#define LBL_e 319
#define LBL_end 310101
#define LBL_endLine 771859886
#define LBL_facts 298546081
#define LBL_flds 9641116
#define LBL_group 299987609
#define LBL_holes 300818381
#define LBL_index 301704428
#define LBL_input 301716452
#define LBL_integrations 139286697
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_labels 836724522
#define LBL_launch 837298910
#define LBL_lengths 294322319
#define LBL_line 9817275
#define LBL_muts 9858798
#define LBL_n 328
#define LBL_name 9869138
#define LBL_numbered 1006183371
#define LBL_offset 927361982
#define LBL_out 319944
#define LBL_part 9928890
#define LBL_pending 1696753626
#define LBL_places 961367927
#define LBL_record 1012233084
#define LBL_ren 322325
#define LBL_severity 75955546
#define LBL_shape 310758331
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_startLine 1642416498
#define LBL_tag 324116
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tuple 312083426
#define LBL_tys 324872
#define LBL_uses 10094739
#define LBL_value 313331083
#define LBL_vars 10107635
static uint32_t shape_binders__uses[] = {LBL_binders, LBL_uses};
static uint32_t shape_group__branches__current[] = {LBL_group, LBL_branches, LBL_current};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_kinds__cons[] = {LBL_kinds, LBL_cons};
static uint32_t shape_line__offset__out[] = {LBL_line, LBL_offset, LBL_out};
static uint32_t shape_name__doc__shape[] = {LBL_name, LBL_doc, LBL_shape};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_part__input[] = {LBL_part, LBL_input};
static uint32_t shape_ren__caps__vars__holes__n[] = {LBL_ren, LBL_caps, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_start__end__tok__text__startLine__endLine[] = {LBL_start, LBL_end, LBL_tok, LBL_text, LBL_startLine, LBL_endLine};
static uint32_t shape_tag__index__tys__flds__places[] = {LBL_tag, LBL_index, LBL_tys, LBL_flds, LBL_places};
static uint32_t shape_text__at[] = {LBL_text, LBL_at};
static uint32_t shape_tuple__numbered__kinds__record__labels__cons__group[] = {LBL_tuple, LBL_numbered, LBL_kinds, LBL_record, LBL_labels, LBL_cons, LBL_group};
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2ecpr_2efitting(V);
V g_heff_2ecompile_2ecpr_2efitting_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2efitting_clo;
V g_heff_2ecompile_2ecpr_2etagLayout(V, V, V);
V g_heff_2ecompile_2ecpr_2etagLayout_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecpr_2etagLayout_clo;
HeffT2 g_heff_2ecompile_2ecpr_2etagLayout_24cpr(V, V, V);
V g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603(V);
V g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_heff_2ecompile_2escalars_2ecallersRw(V, V);
V g_heff_2ecompile_2escalars_2ecallersRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ecallersRw_clo;
V g_heff_2ecompile_2escalars_2ecallsLoopW(V, V);
V g_heff_2ecompile_2escalars_2ecallsLoopW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ecallsLoopW_clo;
V g_heff_2ecompile_2esimplify_2ecanonVisit(V, V);
V g_heff_2ecompile_2esimplify_2ecanonVisit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecanonVisit_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908_clo;
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(V, V, V, V);
V g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2earguments_24s293651280x633455360_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(V, V);
V g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481_clo;
V g_heff_2esyntax_2efmt_2elayout_2ecomment(V);
V g_heff_2esyntax_2efmt_2elayout_2ecomment_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ecomment_clo;
V g_heff_2esyntax_2efmt_2etokens_2ecountNl(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2ecountNl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2ecountNl_clo;
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(V, V, V);
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240_clo;
V g_heff_2esyntax_2esurface_2epatTags(V, V);
V g_heff_2esyntax_2esurface_2epatTags_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatTags_clo;
V g_heff_2esyntax_2esurface_2esigBinders(V, V, V);
V g_heff_2esyntax_2esurface_2esigBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigBinders_clo;
V g_list_2eany_24s1598387467x1906338007(V);
V g_list_2eany_24s1598387467x1906338007_entry(V self, V *a);
extern Clo g_list_2eany_24s1598387467x1906338007_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
V g_list_2eascending_24s390745979x1196509894(V, V, V);
V g_list_2eascending_24s390745979x1196509894_entry(V self, V *a);
extern Clo g_list_2eascending_24s390745979x1196509894_clo;
V g_list_2eascending_24s91816391x1950127237(V, V, V, V, V);
V g_list_2eascending_24s91816391x1950127237_entry(V self, V *a);
extern Clo g_list_2eascending_24s91816391x1950127237_clo;
V g_list_2ecollapse_24s1189723159x1707000933(V, V, V, V);
V g_list_2ecollapse_24s1189723159x1707000933_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s1189723159x1707000933_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1134152647x940271785(V, V);
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1134152647x940271785_clo;
V g_list_2efoldl_24f1428393365x1980555854(V, V, V);
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1428393365x1980555854_clo;
V g_list_2efoldl_24f1488358745x465096512(V, V);
V g_list_2efoldl_24f1488358745x465096512_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1488358745x465096512_clo;
V g_list_2efoldl_24f1559904364x1248618624(V, V, V);
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1559904364x1248618624_clo;
V g_list_2efoldl_24f2071981990x435576741(V, V, V);
V g_list_2efoldl_24f2071981990x435576741_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2071981990x435576741_clo;
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24s1048046132x95752937(V, V);
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1048046132x95752937_clo;
V g_list_2efoldl_24s1165300915x1297435540(V, V);
V g_list_2efoldl_24s1165300915x1297435540_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1165300915x1297435540_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1389405036x1664963487(V, V, V);
V g_list_2efoldl_24s1389405036x1664963487_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1389405036x1664963487_clo;
V g_list_2efoldl_24s1431636639x1417377628(V, V);
V g_list_2efoldl_24s1431636639x1417377628_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1431636639x1417377628_clo;
V g_list_2efoldl_24s1663776184x1429962564(V, V);
V g_list_2efoldl_24s1663776184x1429962564_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1663776184x1429962564_clo;
V g_list_2efoldl_24s1663776184x1429962564_24scalars(V, V, V);
V g_list_2efoldl_24s1663776184x1429962564_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1663776184x1429962564_24scalars_clo;
V g_list_2efoldl_24s1872971975x1696014049(V, V, V);
V g_list_2efoldl_24s1872971975x1696014049_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1872971975x1696014049_clo;
V g_list_2efoldl_24s1879887278x1868824044(V, V);
V g_list_2efoldl_24s1879887278x1868824044_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1879887278x1868824044_clo;
V g_list_2efoldl_24s1991317015x801331450(V, V);
V g_list_2efoldl_24s1991317015x801331450_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1991317015x801331450_clo;
V g_list_2efoldl_24s2031248677x950202423(V, V);
V g_list_2efoldl_24s2031248677x950202423_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2031248677x950202423_clo;
V g_list_2efoldl_24s344878118x1065108086(V, V, V);
V g_list_2efoldl_24s344878118x1065108086_entry(V self, V *a);
extern Clo g_list_2efoldl_24s344878118x1065108086_clo;
V g_list_2efoldl_24s415128528x640682339(V, V);
V g_list_2efoldl_24s415128528x640682339_entry(V self, V *a);
extern Clo g_list_2efoldl_24s415128528x640682339_clo;
V g_list_2efoldl_24s419339443x1702462498(V, V);
V g_list_2efoldl_24s419339443x1702462498_entry(V self, V *a);
extern Clo g_list_2efoldl_24s419339443x1702462498_clo;
V g_list_2efoldl_24s44351024x1408738471_24scalars(V, V, V);
V g_list_2efoldl_24s44351024x1408738471_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_24scalars_clo;
V g_list_2efoldl_24s496727651x1448898893(V, V);
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a);
extern Clo g_list_2efoldl_24s496727651x1448898893_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2ekeepIf_24s1161549307x1906011635_24dps(V, V);
V g_list_2ekeepIf_24s1161549307x1906011635_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_24dps_clo;
V g_list_2elookup_24s1507486579x90027037(V, V);
V g_list_2elookup_24s1507486579x90027037_entry(V self, V *a);
extern Clo g_list_2elookup_24s1507486579x90027037_clo;
HeffT2 g_list_2elookup_24s1507486579x90027037_24cpr(V, V);
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24dps(V, V, V);
V g_list_2emap_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24dps_clo;
V g_list_2emap_24f201346761x152404242_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24f201346761x152404242_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f201346761x152404242_24dps_clo;
V g_list_2emap_24f2124896334x71745266(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f2124896334x71745266_entry(V self, V *a);
extern Clo g_list_2emap_24f2124896334x71745266_clo;
V g_list_2emap_24f2124896334x71745266_24dps(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f2124896334x71745266_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f2124896334x71745266_24dps_clo;
V g_list_2emap_24f768999161x1997188166_24dps(V, V, V, V);
V g_list_2emap_24f768999161x1997188166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_24dps_clo;
V g_list_2emap_24s1007499915x73800978_24dps(V, V);
V g_list_2emap_24s1007499915x73800978_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_24dps_clo;
V g_list_2emap_24s1036840854x702708481_24dps(V, V, V);
V g_list_2emap_24s1036840854x702708481_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1036840854x702708481_24dps_clo;
V g_list_2emap_24s1134414872x1001811115(V);
V g_list_2emap_24s1134414872x1001811115_entry(V self, V *a);
extern Clo g_list_2emap_24s1134414872x1001811115_clo;
V g_list_2emap_24s1134414872x1001811115_24dps(V, V);
V g_list_2emap_24s1134414872x1001811115_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1134414872x1001811115_24dps_clo;
V g_list_2emap_24s1258450377x973220636(V);
V g_list_2emap_24s1258450377x973220636_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_clo;
V g_list_2emap_24s1258450377x973220636_24dps(V, V);
V g_list_2emap_24s1258450377x973220636_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1258450377x973220636_24dps_clo;
V g_list_2emap_24s1263350589x621576050(V);
V g_list_2emap_24s1263350589x621576050_entry(V self, V *a);
extern Clo g_list_2emap_24s1263350589x621576050_clo;
V g_list_2emap_24s126994153x1029399760_24dps(V, V);
V g_list_2emap_24s126994153x1029399760_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s126994153x1029399760_24dps_clo;
V g_list_2emap_24s1276400643x126214923_24dps(V, V);
V g_list_2emap_24s1276400643x126214923_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1276400643x126214923_24dps_clo;
V g_list_2emap_24s146946949x1862800301_24dps(V, V);
V g_list_2emap_24s146946949x1862800301_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s146946949x1862800301_24dps_clo;
V g_list_2emap_24s1478286876x830244177(V);
V g_list_2emap_24s1478286876x830244177_entry(V self, V *a);
extern Clo g_list_2emap_24s1478286876x830244177_clo;
V g_list_2emap_24s1478286876x830244177_24dps(V, V);
V g_list_2emap_24s1478286876x830244177_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1478286876x830244177_24dps_clo;
V g_list_2emap_24s152505078x225062837_24dps(V, V);
V g_list_2emap_24s152505078x225062837_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_24dps_clo;
V g_list_2emap_24s1531069132x955165792_24dps(V, V);
V g_list_2emap_24s1531069132x955165792_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1531069132x955165792_24dps_clo;
V g_list_2emap_24s1531382666x123921537_24dps(V, V);
V g_list_2emap_24s1531382666x123921537_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1531382666x123921537_24dps_clo;
V g_list_2emap_24s1539380703x380520933_24dps(V, V);
V g_list_2emap_24s1539380703x380520933_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1539380703x380520933_24dps_clo;
V g_list_2emap_24s1556510018x266294768(V);
V g_list_2emap_24s1556510018x266294768_entry(V self, V *a);
extern Clo g_list_2emap_24s1556510018x266294768_clo;
V g_list_2emap_24s1556510018x266294768_24dps(V, V);
V g_list_2emap_24s1556510018x266294768_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1556510018x266294768_24dps_clo;
V g_list_2emap_24s1709068899x1960726563(V, V, V, V);
V g_list_2emap_24s1709068899x1960726563_entry(V self, V *a);
extern Clo g_list_2emap_24s1709068899x1960726563_clo;
V g_list_2emap_24s1709068899x1960726563_24dps(V, V, V, V, V);
V g_list_2emap_24s1709068899x1960726563_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1709068899x1960726563_24dps_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
V g_list_2emap_24s1915587473x866090925_24dps(V, V, V);
V g_list_2emap_24s1915587473x866090925_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1915587473x866090925_24dps_clo;
V g_list_2emap_24s1937570095x2110149801_24dps(V, V);
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24dps_clo;
V g_list_2emap_24s2051429168x672290949(V);
V g_list_2emap_24s2051429168x672290949_entry(V self, V *a);
extern Clo g_list_2emap_24s2051429168x672290949_clo;
V g_list_2emap_24s2051429168x672290949_24dps(V, V);
V g_list_2emap_24s2051429168x672290949_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2051429168x672290949_24dps_clo;
V g_list_2emap_24s2090270526x1588636862(V);
V g_list_2emap_24s2090270526x1588636862_entry(V self, V *a);
extern Clo g_list_2emap_24s2090270526x1588636862_clo;
V g_list_2emap_24s215892288x1392224072(V, V);
V g_list_2emap_24s215892288x1392224072_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_clo;
V g_list_2emap_24s215892288x1392224072_24dps(V, V, V);
V g_list_2emap_24s215892288x1392224072_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s215892288x1392224072_24dps_clo;
V g_list_2emap_24s249042484x1701682908_24dps(V, V);
V g_list_2emap_24s249042484x1701682908_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_24dps_clo;
V g_list_2emap_24s262223576x596329185(V, V, V, V, V);
V g_list_2emap_24s262223576x596329185_entry(V self, V *a);
extern Clo g_list_2emap_24s262223576x596329185_clo;
V g_list_2emap_24s262223576x596329185_24dps(V, V, V, V, V, V);
V g_list_2emap_24s262223576x596329185_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s262223576x596329185_24dps_clo;
V g_list_2emap_24s388277778x1355328594(V);
V g_list_2emap_24s388277778x1355328594_entry(V self, V *a);
extern Clo g_list_2emap_24s388277778x1355328594_clo;
V g_list_2emap_24s471405029x78128406_24dps(V, V);
V g_list_2emap_24s471405029x78128406_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_24dps_clo;
V g_list_2emap_24s502656580x1955732096_24dps(V, V);
V g_list_2emap_24s502656580x1955732096_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_24dps_clo;
V g_list_2emap_24s513201124x806973253_24dps(V, V);
V g_list_2emap_24s513201124x806973253_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_24dps_clo;
V g_list_2emap_24s939813003x1383013550_24dps(V, V);
V g_list_2emap_24s939813003x1383013550_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_24dps_clo;
V g_list_2emap_24s954476090x2099974361(V);
V g_list_2emap_24s954476090x2099974361_entry(V self, V *a);
extern Clo g_list_2emap_24s954476090x2099974361_clo;
V g_list_2emap_24s976303750x321235480_24dps(V, V);
V g_list_2emap_24s976303750x321235480_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_24dps_clo;
V g_list_2emerge_24s991540778x2011810329(V, V);
V g_list_2emerge_24s991540778x2011810329_entry(V self, V *a);
extern Clo g_list_2emerge_24s991540778x2011810329_clo;
V g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096(V, V, V);
V g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_entry(V self, V *a);
extern Clo g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096_clo;
V g_list_2emergeRuns_24s429166959x353941515(V, V, V, V);
V g_list_2emergeRuns_24s429166959x353941515_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s429166959x353941515_clo;
V g_list_2epushRun_24s1176995660x590208736(V, V, V, V, V);
V g_list_2epushRun_24s1176995660x590208736_entry(V self, V *a);
extern Clo g_list_2epushRun_24s1176995660x590208736_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2erunFrom(V, V, V);
V g_list_2erunFrom_entry(V self, V *a);
extern Clo g_list_2erunFrom_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1876770336x1656095219(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1876770336x1656095219_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1876770336x1656095219_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_regex_2eemit(V, V);
V g_regex_2eemit_entry(V self, V *a);
extern Clo g_regex_2eemit_clo;
HeffT3 g_regex_2ereadFrom_24cpr(V, V, V, V, V);
V g_std_2ecli_2ereading_get(void);
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2e_3c_3e_24tok2(V, V, V);
V g_std_2edoc_2e_3c_3e_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_24tok2_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_list_2emap_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_entry, 2, 0};

V g_list_2emap(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = ({ V a_0 = v_f_240; V a_1 = v_xs_243; V a_2 = v_cell_245; V r_ = (g_list_2emap_24dps(a_0, a_1, a_2)); heff_drop(v_f_240); r_; });
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_entry(V self, V *a) {
  (void)self;
  return g_list_2emap(a[0], a[1]);
}
Clo g_list_2emap_24s1937570095x2110149801_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1937570095x2110149801_24dps_entry, 2, 0};

V g_list_2emap_24s1937570095x2110149801_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_247);
    V t_0 = v_xs_243;
    V t_1 = v_u_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1937570095x2110149801_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1937570095x2110149801_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1872971975x1696014049_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1872971975x1696014049_entry, 3, 0};

V g_list_2efoldl_24s1872971975x1696014049(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_src_245 = heff_dup(v_lit_240);
    V v_acc_246 = v_z_241;
    V v_offset_247 = heff_take_field(v_acc_246, 1);
    V v_line_248 = heff_take_field(v_acc_246, 0);
    V v_out_249 = heff_take_field(v_acc_246, 2);
    V v_e_2410 = v_x_243;
    V v_t_2411 = (g_heff_2esyntax_2efmt_2etokens_2ecountNl(v_src_245, heff_dup(v_offset_247), heff_rfield(v_e_2410, 0)));
    V v_t_2412 = (g_heff_2esyntax_2efmt_2etokens_2ecountNl(v_src_245, heff_dup(heff_rfield(v_e_2410, 0)), heff_rfield(v_e_2410, 1)));
    V v_t_2413 = (g_heff_2esyntax_2efmt_2etokens_2ecountNl(v_src_245, heff_dup(v_offset_247), heff_rfield(v_e_2410, 0)));
    V v_t_2414 = (g_heff_2esyntax_2efmt_2etokens_2ecountNl(v_src_245, v_offset_247, heff_rfield(v_e_2410, 0)));
    V v_t_2415 = ({ V a_0 = v_src_245; V a_1 = heff_dup(heff_rfield(v_e_2410, 0)); V a_2 = heff_rfield(v_e_2410, 1); V r_ = (g_heff_2esyntax_2efmt_2etokens_2ecountNl(a_0, a_1, a_2)); heff_drop(v_src_245); r_; });
    V v_t_2416 = heff_intAdd(heff_intAdd_lent(v_line_248, v_t_2411, 2), v_t_2412);
    V v_t_2417 = heff_intAdd(heff_intAdd_lent(v_line_248, v_t_2414, 2), v_t_2415);
    V v_t_2418 = heff_rec_n(6, shape_start__end__tok__text__startLine__endLine, (V[]){heff_take_field(v_e_2410, 0), heff_dup(heff_rfield(v_e_2410, 1)), heff_take_field(v_e_2410, 2), heff_take_field(v_e_2410, 3), heff_intAdd(v_line_248, v_t_2413), v_t_2417});
    V v_t_2419 = ({ V rv_0 = v_t_2416; V rv_1 = heff_get_n(v_e_2410, 1, 6); V rv_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_out_249}); V rr_ = heff_rec_reuse_nf(v_acc_246, 0ULL, 3, shape_line__offset__out, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
    V t_0 = v_lit_240;
    V t_1 = v_t_2419;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1872971975x1696014049_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efoldl_24s1872971975x1696014049(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24s1709068899x1960726563_str0, 1, "`");
HEFF_LIT(g_list_2emap_24s1709068899x1960726563_str1, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_list_2emap_24s1709068899x1960726563_str2, 7, " := e`)");
V g_list_2emap_24s1709068899x1960726563_lam0(V self, V *args);
Clo g_list_2emap_24s1709068899x1960726563_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1709068899x1960726563_entry, 4, 0};

V g_list_2emap_24s1709068899x1960726563(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_cx_246 = heff_dup(v_lit_240);
    V v_rest_247 = heff_dup(v_lit_241);
    V v_end_248 = heff_dup(v_lit_242);
    V v_x5_249 = v_x_244;
    V v_t_2459;
    switch (heff_tag_of(v_x5_249)) {
    case TAG_MkPair: {
      V v_p_2410 = heff_field(v_x5_249, 0);
      V v_ss_2411 = heff_field(v_x5_249, 1);
      V v_ru_24x5_249_24MkPair = heff_take_reuse_n(v_x5_249, 3ULL, 2);
      V v_x1_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_2411)));
      V v_t_2429;
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_Nil: {
        v_t_2429 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        V v_x_2413 = heff_field(v_x1_2412, 0);
        heff_take_n(v_x1_2412, 1ULL, 2);
        switch (heff_tag_of(v_x_2413)) {
        case TAG_At: {
          V v_it11_2415 = heff_field(v_x_2413, 0);
          heff_take_n(v_x_2413, 1ULL, 2);
          switch (heff_tag_of(v_it11_2415)) {
          case TAG_StmtBind: {
            heff_take_n(v_it11_2415, 0ULL, 3);
            v_t_2429 = NTAG(TAG_True);
            break;
          }
          case TAG_StmtLet: {
            heff_take_n(v_it11_2415, 0ULL, 2);
            v_t_2429 = NTAG(TAG_True);
            break;
          }
          case TAG_StmtExpr: {
            V v_e_2422 = heff_field(v_it11_2415, 0);
            heff_take_n(v_it11_2415, 1ULL, 1);
            v_t_2429 = (g_heff_2esyntax_2epresyntax_2estmtsFall_2eexprFalls_240(v_e_2422));
            break;
          }
          case TAG_StmtLetMut: {
            heff_take_n(v_it11_2415, 0ULL, 3);
            v_t_2429 = NTAG(TAG_True);
            break;
          }
          case TAG_StmtLetElse: {
            heff_take_n(v_it11_2415, 0ULL, 3);
            v_t_2429 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_it11_2415);
          }
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        break;
      }
      default: heff_nomatch(v_x1_2412);
      }
      if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
        heff_drop(v_t_2429);
        V v_t_2430 = (g_prelude_2e_2b_2b(v_ss_2411, v_rest_247));
        v_t_2459 = (g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(v_cx_246, v_end_248, heff_tag_re_n(v_ru_24x5_249_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_p_2410, v_t_2430})));
      } else {
        heff_drop(v_rest_247);
        heff_drop_cell(v_ru_24x5_249_24MkPair, 2);
        heff_drop(v_t_2429);
        V v_lit_2431 = v_p_2410;
        V v_lit_2432 = v_ss_2411;
        V v_cx_2433 = v_cx_246;
        V v_end_2434 = v_end_248;
        V v_xs_2435 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_lit_2431)));
        HeffT2 v_t_2437 = ({ V b_0 = heff_clo_n(g_list_2emap_24s1709068899x1960726563_lam0, 1, 1, (V[]){heff_dup(v_cx_2433)}); V a_1 = v_xs_2435; HeffT2 r_ = (g_list_2efind_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_xs_2435); r_; });
        {
          V v_field_2439 = v_t_2437.f[1];
          int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
          if ((v_tag_2438 == ((int64_t)0ULL))) {
            heff_drop(v_lit_2432);
            heff_drop_rec(v_cx_2433, 7);
            heff_drop(v_end_2434);
            V v_x_2440 = v_field_2439;
            V v_t_2443;
            switch (heff_tag_of(v_lit_2431)) {
            case TAG_At: {
              V v_s_2442 = heff_dup(heff_field(v_lit_2431, 1));
              v_t_2443 = v_s_2442;
              break;
            }
            default: heff_nomatch(v_lit_2431);
            }
            V v_t_2446;
            switch (heff_tag_of(v_lit_2431)) {
            case TAG_At: {
              V v_s_2445 = heff_dup(heff_field(v_lit_2431, 1));
              v_t_2446 = v_s_2445;
              break;
            }
            default: heff_nomatch(v_lit_2431);
            }
            V v_t_2447 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1709068899x1960726563_str0), heff_dup(v_x_2440)), ((V)&g_list_2emap_24s1709068899x1960726563_str1));
            V v_t_2448 = heff_strAppend(heff_strAppend(v_t_2447, v_x_2440), ((V)&g_list_2emap_24s1709068899x1960726563_str2));
            V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2448}), heff_dup(v_t_2443)});
            V v_t_2450 = ({ V rv_1 = heff_get_n(v_t_2443, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2446, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_lit_2431, v_t_2449}), v_t_2450});
          } else {
            heff_drop(v_field_2439);
            V v_e_2451 = ({ V a_0 = v_cx_2433; V a_1 = v_lit_2432; V a_2 = v_end_2434; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_lit_2432); r_; });
            V v_t_2454;
            switch (heff_tag_of(v_lit_2431)) {
            case TAG_At: {
              V v_s_2453 = heff_dup(heff_field(v_lit_2431, 1));
              v_t_2454 = v_s_2453;
              break;
            }
            default: heff_nomatch(v_lit_2431);
            }
            V v_t_2457;
            switch (heff_tag_of(v_e_2451)) {
            case TAG_At: {
              V v_s_2456 = heff_dup(heff_field(v_e_2451, 1));
              v_t_2457 = v_s_2456;
              break;
            }
            default: heff_nomatch(v_e_2451);
            }
            V v_t_2458 = ({ V rv_1 = heff_get_n(v_t_2457, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2454, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_lit_2431, v_e_2451}), v_t_2458});
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x5_249);
    }
    V v_cell_2460 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2459, heff_hole()});
    V v_u_2461 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_xs_245; V a_4 = v_cell_2460; V r_ = (g_list_2emap_24s1709068899x1960726563_24dps(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_242); r_; });
    heff_drop(v_u_2461);
    return v_cell_2460;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s1709068899x1960726563_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1709068899x1960726563(a[0], a[1], a[2], a[3]);
}
V g_list_2emap_24s1709068899x1960726563_lam0(V self, V *args) {
  V v_x_2436 = args[0];
  V v_cx_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2436; V b_1 = heff_get_n(v_cx_2433, 1, 7); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_2436); heff_drop(b_1); r_; });
}
Clo g_list_2emap_24s1036840854x702708481_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1036840854x702708481_24dps_entry, 3, 0};

V g_list_2emap_24s1036840854x702708481_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_245 = heff_dup(v_lit_240);
    V v_x2_246 = v_x_243;
    V v_t_2424;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_At: {
      V v_x21_247 = heff_field(v_x2_246, 0);
      V v_sp_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24At = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      switch (heff_tag_of(v_x21_247)) {
      case TAG_MkEquation: {
        V v_f_249 = heff_field(v_x21_247, 0);
        V v_fsp_2410 = heff_field(v_x21_247, 1);
        V v_ps_2411 = heff_field(v_x21_247, 2);
        V v_rhs_2412 = heff_field(v_x21_247, 3);
        V v_ru_24x21_247_24MkEquation = heff_take_reuse_n(v_x21_247, 15ULL, 4);
        V v_x1_2413 = heff_tr(heff_call(heff_get_n(v_r_245, 0, 2), 1, (V[]){v_rhs_2412}));
        V v_t_2423;
        switch (heff_tag_of(v_x1_2413)) {
        case TAG_IsInferable: {
          V v_i_2414 = heff_field(v_x1_2413, 0);
          V v_ru_24x1_2413_24IsInferable = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
          V v_t_2417;
          switch (heff_tag_of(v_i_2414)) {
          case TAG_At: {
            V v_s_2416 = heff_dup(heff_field(v_i_2414, 1));
            v_t_2417 = v_s_2416;
            break;
          }
          default: heff_nomatch(v_i_2414);
          }
          v_t_2423 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2413_24IsInferable, TAG_CInf, 1, (V[]){v_i_2414}), v_t_2417});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2418 = heff_field(v_x1_2413, 0);
          heff_take_n(v_x1_2413, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_246_24At, 2);
          v_t_2423 = v_c_2418;
          break;
        }
        case TAG_IsType: {
          V v_t_2419 = heff_field(v_x1_2413, 0);
          V v_ru_24x1_2413_24IsType = heff_take_reuse_n(v_x1_2413, 1ULL, 1);
          V v_t_2422;
          switch (heff_tag_of(v_t_2419)) {
          case TAG_At: {
            V v_s_2421 = heff_dup(heff_field(v_t_2419, 1));
            v_t_2422 = v_s_2421;
            break;
          }
          default: heff_nomatch(v_t_2419);
          }
          v_t_2423 = heff_tag_at_n(v_ru_24x2_246_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2413_24IsType, TAG_CType, 1, (V[]){v_t_2419}), v_t_2422});
          break;
        }
        default: heff_nomatch(v_x1_2413);
        }
        v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_247_24MkEquation, TAG_MkEquation, 4, 7ULL, (V[]){v_f_249, v_fsp_2410, v_ps_2411, v_t_2423}), v_sp_248});
        break;
      }
      default: heff_nomatch(v_x21_247);
      }
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_cell_2425 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
    V v_u_2426 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2425);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2426;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1036840854x702708481_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s1036840854x702708481_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1258450377x973220636_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1258450377x973220636_entry, 1, 0};

V g_list_2emap_24s1258450377x973220636(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = v_x_241;
    V v_t_2425;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_At: {
      V v_x21_244 = heff_field(v_x2_243, 0);
      V v_sp_245 = heff_field(v_x2_243, 1);
      V v_ru_24x2_243_24At = heff_take_reuse_n(v_x2_243, 3ULL, 2);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_TagVariant: {
        V v_t_246 = heff_field(v_x21_244, 0);
        V v_tsp_247 = heff_field(v_x21_244, 1);
        V v_args_248 = heff_field(v_x21_244, 2);
        V v_ru_24x21_244_24TagVariant = heff_take_reuse_n(v_x21_244, 7ULL, 3);
        V v_t_249 = (g_list_2emap_24s1887874170x1747433177(v_args_248));
        v_t_2425 = heff_tag_re_n(v_ru_24x2_243_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_244_24TagVariant, TAG_TagVariant, 3, 3ULL, (V[]){v_t_246, v_tsp_247, v_t_249}), v_sp_245});
        break;
      }
      case TAG_BadVariant: {
        V v_e_2410 = heff_field(v_x21_244, 0);
        V v_ru_24x21_244_24BadVariant = heff_take_reuse_n(v_x21_244, 1ULL, 1);
        HeffT3 v_t_2411 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_2410));
        {
          V v_field_2413 = v_t_2411.f[1];
          V v_field_2414 = v_t_2411.f[2];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          V v_t_2424;
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_c_2415 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2413, v_field_2414});
            V v_t_2418;
            switch (heff_tag_of(v_c_2415)) {
            case TAG_At: {
              V v_s_2417 = heff_dup(heff_field(v_c_2415, 1));
              v_t_2418 = v_s_2417;
              break;
            }
            default: heff_nomatch(v_c_2415);
            }
            v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2415}), v_t_2418});
          } else {
            if ((v_tag_2412 == ((int64_t)1ULL))) {
              V v_i_2419 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2413, v_field_2414});
              V v_t_2422;
              switch (heff_tag_of(v_i_2419)) {
              case TAG_At: {
                V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
                v_t_2422 = v_s_2421;
                break;
              }
              default: heff_nomatch(v_i_2419);
              }
              v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2419}), v_t_2422});
            } else {
              V v_t_2423 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2413, v_field_2414});
              v_t_2424 = v_t_2423;
            }
          }
          v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_244_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2424}), v_sp_245});
        }
        break;
      }
      default: heff_nomatch(v_x21_244);
      }
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_cell_2426 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
    V v_u_2427 = (g_list_2emap_24s1258450377x973220636_24dps(v_xs_242, v_cell_2426));
    heff_drop(v_u_2427);
    return v_cell_2426;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1258450377x973220636_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1258450377x973220636(a[0]);
}
Clo g_list_2emap_24s1276400643x126214923_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1276400643x126214923_24dps_entry, 2, 0};

V g_list_2emap_24s1276400643x126214923_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = v_x_242;
    V v_t_2425;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_At: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      V v_sp_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24At = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_MkEquation: {
        V v_f_247 = heff_field(v_x21_245, 0);
        V v_fsp_248 = heff_field(v_x21_245, 1);
        V v_ps_249 = heff_field(v_x21_245, 2);
        V v_rhs_2410 = heff_field(v_x21_245, 3);
        V v_ru_24x21_245_24MkEquation = heff_take_reuse_n(v_x21_245, 15ULL, 4);
        HeffT3 v_t_2411 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_rhs_2410));
        {
          V v_field_2413 = v_t_2411.f[1];
          V v_field_2414 = v_t_2411.f[2];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          V v_t_2424;
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_c_2415 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2413, v_field_2414});
            v_t_2424 = v_c_2415;
          } else {
            if ((v_tag_2412 == ((int64_t)1ULL))) {
              V v_i_2416 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2413, v_field_2414});
              V v_t_2419;
              switch (heff_tag_of(v_i_2416)) {
              case TAG_At: {
                V v_s_2418 = heff_dup(heff_field(v_i_2416, 1));
                v_t_2419 = v_s_2418;
                break;
              }
              default: heff_nomatch(v_i_2416);
              }
              v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2416}), v_t_2419});
            } else {
              V v_t_2420 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){v_field_2413, v_field_2414});
              V v_t_2423;
              switch (heff_tag_of(v_t_2420)) {
              case TAG_At: {
                V v_s_2422 = heff_dup(heff_field(v_t_2420, 1));
                v_t_2423 = v_s_2422;
                break;
              }
              default: heff_nomatch(v_t_2420);
              }
              v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2420}), v_t_2423});
            }
          }
          v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_245_24MkEquation, TAG_MkEquation, 4, 7ULL, (V[]){v_f_247, v_fsp_248, v_ps_249, v_t_2424}), v_sp_246});
        }
        break;
      }
      default: heff_nomatch(v_x21_245);
      }
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_cell_2426 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
    V v_u_2427 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2426);
    V t_0 = v_xs_243;
    V t_1 = v_u_2427;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1276400643x126214923_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1276400643x126214923_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s2051429168x672290949_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2051429168x672290949_entry, 1, 0};

V g_list_2emap_24s2051429168x672290949(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = v_x_241;
    V v_t_2440;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_At: {
      V v_x21_244 = heff_field(v_x2_243, 0);
      V v_sp_245 = heff_field(v_x2_243, 1);
      V v_ru_24x2_243_24At = heff_take_reuse_n(v_x2_243, 3ULL, 2);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_ExplicitParam: {
        V v_x_246 = heff_field(v_x21_244, 0);
        V v_xsp_247 = heff_field(v_x21_244, 1);
        V v_t_248 = heff_field(v_x21_244, 2);
        V v_ru_24x21_244_24ExplicitParam = heff_take_reuse_n(v_x21_244, 7ULL, 3);
        HeffT3 v_t_249 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_248));
        {
          V v_field_2411 = v_t_249.f[1];
          V v_field_2412 = v_t_249.f[2];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          V v_t_2422;
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_c_2413 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2411, v_field_2412});
            V v_t_2416;
            switch (heff_tag_of(v_c_2413)) {
            case TAG_At: {
              V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
              v_t_2416 = v_s_2415;
              break;
            }
            default: heff_nomatch(v_c_2413);
            }
            v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
          } else {
            if ((v_tag_2410 == ((int64_t)1ULL))) {
              V v_i_2417 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2411, v_field_2412});
              V v_t_2420;
              switch (heff_tag_of(v_i_2417)) {
              case TAG_At: {
                V v_s_2419 = heff_dup(heff_field(v_i_2417, 1));
                v_t_2420 = v_s_2419;
                break;
              }
              default: heff_nomatch(v_i_2417);
              }
              v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2417}), v_t_2420});
            } else {
              V v_t_2421 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2411, v_field_2412});
              v_t_2422 = v_t_2421;
            }
          }
          v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_244_24ExplicitParam, TAG_ExplicitParam, 3, 3ULL, (V[]){v_x_246, v_xsp_247, v_t_2422}), v_sp_245});
        }
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_2423 = heff_field(v_x21_244, 0);
        V v_xsp_2424 = heff_field(v_x21_244, 1);
        V v_t_2425 = heff_field(v_x21_244, 2);
        V v_ru_24x21_244_24ImplicitParam = heff_take_reuse_n(v_x21_244, 7ULL, 3);
        HeffT3 v_t_2426 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2425));
        {
          V v_field_2428 = v_t_2426.f[1];
          V v_field_2429 = v_t_2426.f[2];
          int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
          V v_t_2439;
          if ((v_tag_2427 == ((int64_t)0ULL))) {
            V v_c_2430 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2428, v_field_2429});
            V v_t_2433;
            switch (heff_tag_of(v_c_2430)) {
            case TAG_At: {
              V v_s_2432 = heff_dup(heff_field(v_c_2430, 1));
              v_t_2433 = v_s_2432;
              break;
            }
            default: heff_nomatch(v_c_2430);
            }
            v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2430}), v_t_2433});
          } else {
            if ((v_tag_2427 == ((int64_t)1ULL))) {
              V v_i_2434 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2428, v_field_2429});
              V v_t_2437;
              switch (heff_tag_of(v_i_2434)) {
              case TAG_At: {
                V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
                v_t_2437 = v_s_2436;
                break;
              }
              default: heff_nomatch(v_i_2434);
              }
              v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2434}), v_t_2437});
            } else {
              V v_t_2438 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_At, 2, (V[]){v_field_2428, v_field_2429});
              v_t_2439 = v_t_2438;
            }
          }
          v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_244_24ImplicitParam, TAG_ImplicitParam, 3, 3ULL, (V[]){v_x_2423, v_xsp_2424, v_t_2439}), v_sp_245});
        }
        break;
      }
      default: heff_nomatch(v_x21_244);
      }
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_cell_2441 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2440, heff_hole()});
    V v_u_2442 = (g_list_2emap_24s2051429168x672290949_24dps(v_xs_242, v_cell_2441));
    heff_drop(v_u_2442);
    return v_cell_2441;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2051429168x672290949_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2051429168x672290949(a[0]);
}
Clo g_list_2emap_24s126994153x1029399760_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s126994153x1029399760_24dps_entry, 2, 0};

V g_list_2emap_24s126994153x1029399760_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2420;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2419;
      switch (heff_tag_of(v_a_244)) {
      case TAG_ArgExplicit: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24ArgExplicit = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_a_246)) {
        case TAG_At: {
          V v_a_247 = heff_field(v_a_246, 0);
          V v_a_248 = heff_field(v_a_246, 1);
          heff_take_n(v_a_246, 3ULL, 2);
          V v_t_249 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_247));
          v_t_2410 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_249, v_a_248});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        v_t_2419 = heff_tag_at_n(v_ru_24a_244_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_2410});
        break;
      }
      case TAG_ArgProject: {
        V v_a_2411 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24ArgProject = heff_take_reuse_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2419 = heff_tag_re_n(v_ru_24a_244_24ArgProject, TAG_ArgProject, 1, 1ULL, (V[]){v_a_2411});
        break;
      }
      case TAG_ArgNamed: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_a_2413 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24ArgNamed = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_t_2417;
        switch (heff_tag_of(v_a_2413)) {
        case TAG_At: {
          V v_a_2414 = heff_field(v_a_2413, 0);
          V v_a_2415 = heff_field(v_a_2413, 1);
          heff_take_n(v_a_2413, 3ULL, 2);
          V v_t_2416 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_2414));
          v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){v_t_2416, v_a_2415});
          break;
        }
        default: heff_nomatch(v_a_2413);
        }
        v_t_2419 = heff_tag_re_n(v_ru_24a_244_24ArgNamed, TAG_ArgNamed, 2, 1ULL, (V[]){v_a_2412, v_t_2417});
        break;
      }
      case TAG_ArgEvidence: {
        V v_a_2418 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24ArgEvidence = heff_take_reuse_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x_242_24At, 2);
        v_t_2419 = heff_tag_re_n(v_ru_24a_244_24ArgEvidence, TAG_ArgEvidence, 1, 1ULL, (V[]){v_a_2418});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2421 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2420, heff_hole()});
    V v_u_2422 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2421);
    V t_0 = v_xs_243;
    V t_1 = v_u_2422;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s126994153x1029399760_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s126994153x1029399760_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s249042484x1701682908_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s249042484x1701682908_24dps_entry, 2, 0};

V g_list_2emap_24s249042484x1701682908_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      V v_t_2416;
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24SetField = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_t_2411;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_2410, v_a_249));
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2416 = heff_tag_re_n(v_ru_24a_244_24SetField, TAG_SetField, 3, 3ULL, (V[]){v_a_246, v_a_247, v_t_2411});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_2412 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24BadFieldSet = heff_take_reuse_n(v_a_244, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_a_2412)) {
        case TAG_At: {
          V v_a_2413 = heff_field(v_a_2412, 0);
          V v_a_2414 = heff_field(v_a_2412, 1);
          heff_take_n(v_a_2412, 3ULL, 2);
          v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_a_2414, v_a_2413));
          break;
        }
        default: heff_nomatch(v_a_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24a_244_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2415});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2417 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){v_t_2416, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2418);
    V t_0 = v_xs_243;
    V t_1 = v_u_2419;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s249042484x1701682908_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s249042484x1701682908_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s513201124x806973253_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513201124x806973253_24dps_entry, 2, 0};

V g_list_2emap_24s513201124x806973253_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_text_244 = heff_take_field(v_x_242, 1);
    V v_start_245 = heff_take_field(v_x_242, 3);
    V v_end_246 = heff_get_n(v_x_242, 4, 9);
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EProject, 1, (V[]){v_text_244}), heff_rec_n(2, shape_start__end, (V[]){v_start_245, v_end_246})});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
    V t_0 = v_xs_243;
    V t_1 = v_u_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513201124x806973253_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s513201124x806973253_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s415128528x640682339_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s415128528x640682339_entry, 2, 0};

V g_list_2efoldl_24s415128528x640682339(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_245 = heff_field(v_x_242, 1);
      v_t_246 = ({ V a_0 = heff_dup(v_a_245); V a_1 = v_z_240; V r_ = (g_heff_2esyntax_2esurface_2epatTags(a_0, a_1)); heff_drop(v_z_240); r_; });
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s415128528x640682339_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s415128528x640682339(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1389405036x1664963487_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1389405036x1664963487_entry, 3, 0};

V g_list_2efoldl_24s1389405036x1664963487(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2esyntax_2esurface_2esigBinders(heff_dup(v_lit_240), v_z_241, heff_dup(v_x_243)));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1389405036x1664963487_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl_24s1389405036x1664963487(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s146946949x1862800301_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s146946949x1862800301_24dps_entry, 2, 0};

V g_list_2emap_24s146946949x1862800301_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_text_244 = heff_take_field(v_x_242, 1);
    V v_start_245 = heff_take_field(v_x_242, 3);
    V v_end_246 = heff_get_n(v_x_242, 4, 9);
    V v_t_247 = heff_rec_n(2, shape_name__span, (V[]){v_text_244, heff_rec_n(2, shape_start__end, (V[]){v_start_245, v_end_246})});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
    V t_0 = v_xs_243;
    V t_1 = v_u_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s146946949x1862800301_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s146946949x1862800301_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2efoldl_24s1048046132x95752937_str0, 2, "a$");
HEFF_LIT(g_list_2efoldl_24s1048046132x95752937_str1, 2, "a$");
Clo g_list_2efoldl_24s1048046132x95752937_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1048046132x95752937_entry, 2, 0};

V g_list_2efoldl_24s1048046132x95752937(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_x1_244 = v_z_240;
    V v_x_245 = v_x_242;
    V v_t_2414;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_MkPair: {
      V v_xs_246 = heff_field(v_x1_244, 0);
      V v_st_247 = heff_field(v_x1_244, 1);
      V v_ru_24x1_244_24MkPair = heff_take_reuse_n(v_x1_244, 3ULL, 2);
      V v_t_248 = heff_intShow(heff_dup(heff_rfield(v_st_247, 4)));
      V v_t_249 = ({ V a_0 = heff_take_field(v_st_247, 0); V a_1 = v_x_245; V b_2 = heff_strAppend(((V)&g_list_2efoldl_24s1048046132x95752937_str0), v_t_248); V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, b_2)); heff_drop(v_x_245); heff_drop(b_2); r_; });
      V v_t_2410 = heff_intShow(heff_dup(heff_rfield(v_st_247, 4)));
      V v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_list_2efoldl_24s1048046132x95752937_str1), v_t_2410), v_xs_246});
      V v_t_2412 = heff_intAdd(heff_take_field(v_st_247, 4), MK_INT(1LL));
      V v_t_2413 = ({ V rv_0 = v_t_249; V rv_4 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_st_247, 14ULL, 5, shape_ren__caps__vars__holes__n, 252u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; rr_; });
      v_t_2414 = heff_tag_at_n(v_ru_24x1_244_24MkPair, TAG_MkPair, 2, (V[]){v_t_2411, v_t_2413});
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    V t_0 = v_t_2414;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1048046132x95752937(a[0], a[1]);
}
Clo g_list_2emap_24s1531069132x955165792_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1531069132x955165792_24dps_entry, 2, 0};

V g_list_2emap_24s1531069132x955165792_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ecompile_2eir_2eisValue(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_xs_243;
    V t_1 = v_u_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1531069132x955165792_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1531069132x955165792_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1556510018x266294768_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1556510018x266294768_entry, 1, 0};

V g_list_2emap_24s1556510018x266294768(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      heff_take_n(v_x_241, 4ULL, 3);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_2446;
    switch (heff_tag_of(v_t_246)) {
    case TAG_EVar: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_True);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_t_246, 0ULL, 3);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_t_246, 0ULL, 4);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_t_246, 0ULL, 3);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_t_246, 0ULL, 3);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_t_246, 0ULL, 1);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_t_246, 0ULL, 2);
      v_t_2446 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_cell_2447 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2446, heff_hole()});
    V v_u_2448 = (g_list_2emap_24s1556510018x266294768_24dps(v_xs_242, v_cell_2447));
    heff_drop(v_u_2448);
    return v_cell_2447;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1556510018x266294768_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1556510018x266294768(a[0]);
}
Clo g_list_2efoldl_24s419339443x1702462498_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s419339443x1702462498_entry, 2, 0};

V g_list_2efoldl_24s419339443x1702462498(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2ecanonVisit(v_z_240, v_x_242));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s419339443x1702462498_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s419339443x1702462498(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1203202837x1639358108_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1203202837x1639358108_entry, 2, 0};

V g_list_2efoldl_24s1203202837x1639358108(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_x_242}), v_z_240});
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1203202837x1639358108(a[0], a[1]);
}
Clo g_list_2emap_24s471405029x78128406_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s471405029x78128406_24dps_entry, 2, 0};

V g_list_2emap_24s471405029x78128406_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_a_246 = heff_field(v_x_242, 2);
      heff_take_n(v_x_242, 7ULL, 3);
      v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_a_244, v_a_245}), heff_tag_n(TAG_ASts, 1, (V[]){v_a_246})});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_248);
    V t_0 = v_xs_243;
    V t_1 = v_u_249;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s471405029x78128406_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s471405029x78128406_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s976303750x321235480_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s976303750x321235480_24dps_entry, 2, 0};

V g_list_2emap_24s976303750x321235480_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_Given: {
      V v_e_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = v_e_244;
      break;
    }
    case TAG_GivenU: {
      V v_e_246 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_2410 = v_e_246;
      break;
    }
    case TAG_LentVar: {
      V v_x_247 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2410 = heff_tag_n(TAG_RLocal, 1, (V[]){v_x_247});
      break;
    }
    case TAG_LentValue: {
      V v_e_249 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2410 = v_e_249;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2411);
    V t_0 = v_xs_243;
    V t_1 = v_u_2412;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s976303750x321235480_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s976303750x321235480_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1879887278x1868824044_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1879887278x1868824044_entry, 2, 0};

V g_list_2efoldl_24s1879887278x1868824044(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkCArm: {
      V v_a_2410 = heff_field(v_x_242, 6);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1879887278x1868824044_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1879887278x1868824044(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s215892288x1392224072_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s215892288x1392224072_entry, 2, 0};

V g_list_2emap_24s215892288x1392224072(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_lit_240), v_x_242}), heff_hole()});
    V v_u_245 = ({ V a_0 = v_lit_240; V a_1 = v_xs_243; V a_2 = v_cell_244; V r_ = (g_list_2emap_24s215892288x1392224072_24dps(a_0, a_1, a_2)); heff_drop(v_lit_240); r_; });
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s215892288x1392224072_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s215892288x1392224072(a[0], a[1]);
}
HEFF_LIT(g_list_2efoldl_24s1165300915x1297435540_str0, 0, "");
HEFF_LIT(g_list_2efoldl_24s1165300915x1297435540_str1, 1, ",");
HEFF_LIT(g_list_2efoldl_24s1165300915x1297435540_str2, 0, "");
HEFF_LIT(g_list_2efoldl_24s1165300915x1297435540_str3, 1, "#");
Clo g_list_2efoldl_24s1165300915x1297435540_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1165300915x1297435540_entry, 2, 0};

V g_list_2efoldl_24s1165300915x1297435540(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_root_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_root_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_s_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 1));
      v_s_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_2443;
    switch (heff_tag_of(v_s_249)) {
    case TAG_NoShape: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop(v_root_246);
      v_a_2443 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_RecordShape: {
      V v_ls_2410 = heff_field(v_s_249, 0);
      V v_ts_2411 = heff_field(v_s_249, 1);
      heff_take_n(v_s_249, 3ULL, 2);
      V v_root_2412 = v_root_246;
      V v_ls_2413 = v_ls_2410;
      V v_ts_2414 = v_ts_2411;
      V v_rs_2415 = (g_list_2emap_24s1263350589x621576050(heff_dup(v_ts_2414)));
      V v_x2_2416 = (g_list_2emap_24s2090270526x1588636862(v_rs_2415));
      V v_t_2419;
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_list_2efoldl_24s1165300915x1297435540_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_xs_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_list_2efoldl_24s1165300915x1297435540_str1); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2416);
      }
      V v_t_2420 = (g_list_2emap_24s1263350589x621576050(heff_dup(v_ts_2414)));
      V v_t_2421 = (g_list_2emap_24s388277778x1355328594(heff_dup(v_ts_2414)));
      V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2414));
      V v_t_2423 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2422, MK_INT(1LL))));
      V v_t_2424 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_tag__index__tys__flds__places, (V[]){((V)&g_list_2efoldl_24s1165300915x1297435540_str2), MK_INT(0LL), v_ts_2414, v_t_2421, v_t_2423}), NTAG(TAG_Nil)});
      V v_t_2425 = heff_rec_n(7, shape_tuple__numbered__kinds__record__labels__cons__group, (V[]){heff_strAppend(((V)&g_list_2efoldl_24s1165300915x1297435540_str3), v_t_2419), NTAG(TAG_False), v_t_2420, NTAG(TAG_True), v_ls_2413, v_t_2424, v_root_2412});
      v_a_2443 = (g_heff_2ecompile_2ecpr_2efitting(v_t_2425));
      break;
    }
    case TAG_TagShape: {
      V v_m_2426 = heff_field(v_s_249, 0);
      V v_ru_24s_249_24TagShape = heff_take_reuse_n(v_s_249, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      V v_root_2427 = heff_dup(v_root_246);
      V v_ts_2428 = (g_std_2eordmap_2etoList_2etoListOnto_240(v_m_2426, NTAG(TAG_Nil)));
      V v_ts_2429 = ({ V a_0 = v_m_2426; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2426); r_; });
      V v_x_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2429));
      V v_t_2431 = heff_rec_n(2, shape_kinds__cons, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      V v_t_2432 = (g_list_2efoldl_24s1431636639x1417377628(v_t_2431, v_ts_2429));
      V v_t_2433 = heff_bool(heff_intLt_c_lent(MK_INT(1LL), v_x_2430, 1));
      heff_drop(v_x_2430);
      HeffT2 v_t_2434 = (g_heff_2ecompile_2ecpr_2etagLayout_24cpr(v_root_246, v_t_2433, v_t_2432));
      {
        V v_field_2436 = v_t_2434.f[1];
        int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
        if ((v_tag_2435 == ((int64_t)0ULL))) {
          heff_drop(v_root_2427);
          heff_drop(v_ts_2428);
          V v_lay_2437 = v_field_2436;
          v_a_2443 = heff_tag_at_n(v_ru_24s_249_24TagShape, TAG_Just, 1, (V[]){v_lay_2437});
        } else {
          heff_drop_cell(v_ru_24s_249_24TagShape, 1);
          heff_drop(v_field_2436);
          V v_ts_2438 = (g_list_2emap_24s954476090x2099974361(v_ts_2428));
          V v_x_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2438));
          V v_t_2440 = heff_rec_n(2, shape_kinds__cons, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
          V v_t_2441 = (g_list_2efoldl_24s1431636639x1417377628(v_t_2440, v_ts_2438));
          V v_t_2442 = heff_bool(heff_intLt_c_lent(MK_INT(1LL), v_x_2439, 1));
          heff_drop(v_x_2439);
          v_a_2443 = (g_heff_2ecompile_2ecpr_2etagLayout(v_root_2427, v_t_2442, v_t_2441));
        }
      }
      break;
    }
    case TAG_BadShape: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      heff_drop(v_root_246);
      v_a_2443 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_s_249);
    }
    V v_t_2448;
    switch (heff_tag_of(v_a_2443)) {
    case TAG_Nothing: {
      heff_drop(v_x_242);
      v_t_2448 = v_z_240;
      break;
    }
    case TAG_Just: {
      V v_a_2444 = heff_field(v_a_2443, 0);
      heff_take_n(v_a_2443, 1ULL, 1);
      V v_t_2447;
      switch (heff_tag_of(v_x_242)) {
      case TAG_MkPair: {
        V v_a_2445 = heff_field(v_x_242, 0);
        heff_take_n(v_x_242, 1ULL, 2);
        v_t_2447 = v_a_2445;
        break;
      }
      default: heff_nomatch(v_x_242);
      }
      v_t_2448 = ({ V a_0 = v_z_240; V a_1 = v_t_2447; V a_2 = v_a_2444; V r_ = (g_std_2eordmap_2einsert_24s615484302x989744458(a_0, a_1, a_2)); heff_drop(v_t_2447); heff_drop(v_a_2444); r_; });
      break;
    }
    default: heff_nomatch(v_a_2443);
    }
    V t_0 = v_t_2448;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1165300915x1297435540_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1165300915x1297435540(a[0], a[1]);
}
Clo g_list_2emap_24s1478286876x830244177_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1478286876x830244177_entry, 1, 0};

V g_list_2emap_24s1478286876x830244177(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1478286876x830244177_24dps(v_xs_242, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1478286876x830244177_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1478286876x830244177(a[0]);
}
Clo g_list_2emap_24s1915587473x866090925_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1915587473x866090925_24dps_entry, 3, 0};

V g_list_2emap_24s1915587473x866090925_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_dup(v_lit_240);
    V v_d_246 = v_x_243;
    V v_t_247 = heff_dup(heff_rfield(v_d_246, 2));
    V v_t_2421;
    switch (heff_tag_of(v_t_247)) {
    case TAG_ECall: {
      V v_g_248 = heff_field(v_t_247, 0);
      V v_args_249 = heff_field(v_t_247, 1);
      V v_ru_24t_247_24ECall = heff_take_reuse_n(v_t_247, 3ULL, 2);
      HeffT2 v_t_2410 = ({ V a_0 = v_m_245; V a_1 = v_g_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_g_248); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop(v_args_249);
          heff_drop_cell(v_ru_24t_247_24ECall, 2);
          V v_x_2413 = v_field_2412;
          heff_drop(v_x_2413);
          V v_body_2414 = (g_heff_2ecompile_2escalars_2ecallersRw(v_m_245, heff_take_field(v_d_246, 2)));
          v_t_2421 = ({ V rv_2 = v_body_2414; V rr_ = heff_rec_reuse_nf(v_d_246, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        } else {
          heff_drop(v_field_2412);
          V v_t_2415 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24t_247_24ECall, v_args_249, NTAG(TAG_Nil)));
          V v_t_2416 = (g_heff_2ecompile_2escalars_2ecallsLoopW(v_m_245, v_t_2415));
          if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
            heff_drop(v_t_2416);
            V v_body_2417 = (g_heff_2ecompile_2escalars_2ecallersRw(v_m_245, heff_take_field(v_d_246, 2)));
            v_t_2421 = ({ V rv_2 = v_body_2417; V rr_ = heff_rec_reuse_nf(v_d_246, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          } else {
            heff_drop(v_m_245);
            heff_drop(v_t_2416);
            v_t_2421 = v_d_246;
          }
        }
      }
      break;
    }
    default: {
      V v_t_2418 = (g_heff_2ecompile_2eir_2epartsOnto(v_t_247, NTAG(TAG_Nil)));
      V v_t_2419 = (g_heff_2ecompile_2escalars_2ecallsLoopW(v_m_245, v_t_2418));
      if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
        heff_drop(v_t_2419);
        V v_body_2420 = (g_heff_2ecompile_2escalars_2ecallersRw(v_m_245, heff_take_field(v_d_246, 2)));
        v_t_2421 = ({ V rv_2 = v_body_2420; V rr_ = heff_rec_reuse_nf(v_d_246, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      } else {
        heff_drop(v_m_245);
        heff_drop(v_t_2419);
        v_t_2421 = v_d_246;
      }
      break;
    }
    }
    V v_cell_2422 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2421, heff_hole()});
    V v_u_2423 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2422);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2423;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1915587473x866090925_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2emap_24s1915587473x866090925_24dps(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1663776184x1429962564_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1663776184x1429962564_entry, 2, 0};

V g_list_2efoldl_24s1663776184x1429962564(V v_z_240, V v_x3_241) {
top: ;
  V v_facts_242 = heff_take_field(v_z_240, 0);
  V v_lengths_243 = heff_get_n(v_z_240, 1, 2);
  return (g_list_2efoldl_24s1663776184x1429962564_24scalars(v_facts_242, v_lengths_243, v_x3_241));
}
V g_list_2efoldl_24s1663776184x1429962564_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1663776184x1429962564(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2elookup_24s1507486579x90027037_clo = {{0x80000000u, K_CLO, 0}, g_list_2elookup_24s1507486579x90027037_entry, 2, 0};

V g_list_2elookup_24s1507486579x90027037(V v_k_240, V v_x2_241) {
top: ;
  HeffT2 v_t_242 = (g_list_2elookup_24s1507486579x90027037_24cpr(v_k_240, v_x2_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_244});
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_list_2elookup_24s1507486579x90027037_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2elookup_24s1507486579x90027037(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1598387467x1906338007_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1598387467x1906338007_entry, 1, 0};

V g_list_2eany_24s1598387467x1906338007(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    HeffT2 v_t_243 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x11_246 = v_field_245;
        heff_drop(v_x11_246);
        switch (heff_tag_of(v_x_241)) {
        case TAG_WordAdd: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_WordSub: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_WordMul: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_WordDiv: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_WordMod: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_WordQuot: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_WordRem: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_WordEq: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_WordLt: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_WordLe: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_WordToFloat: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        default: {
          return NTAG(TAG_True);
        }
        }
      } else {
        heff_drop(v_field_245);
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s1598387467x1906338007_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s1598387467x1906338007(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s152505078x225062837_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s152505078x225062837_24dps_entry, 2, 0};

V g_list_2emap_24s152505078x225062837_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_244);
    V t_0 = v_xs_243;
    V t_1 = v_u_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s152505078x225062837_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s152505078x225062837_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s502656580x1955732096_24dps_str0, 1, "_");
Clo g_list_2emap_24s502656580x1955732096_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s502656580x1955732096_24dps_entry, 2, 0};

V g_list_2emap_24s502656580x1955732096_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(v_x_242, 0, 5);
    V v_t_2424;
    switch (heff_tag_of(v_t_244)) {
    case TAG_At: {
      V v_x11_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 2);
      switch (heff_tag_of(v_x11_245)) {
      case TAG_PatVar: {
        V v_x_247 = heff_field(v_x11_245, 0);
        V v_ru_24x11_245_24PatVar = heff_take_reuse_n(v_x11_245, 1ULL, 1);
        if (heff_strEq_c_lent(v_x_247, ((V)&g_list_2emap_24s502656580x1955732096_24dps_str0), 2)) {
          heff_drop(v_x_247);
          heff_drop_cell(v_ru_24x11_245_24PatVar, 1);
          v_t_2424 = NTAG(TAG_Nothing);
        } else {
          v_t_2424 = heff_tag_at_n(v_ru_24x11_245_24PatVar, TAG_Just, 1, (V[]){v_x_247});
        }
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_245, 0ULL, 3);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_245, 0ULL, 3);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_245, 0ULL, 1);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_245, 0ULL, 3);
        v_t_2424 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_245);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_cell_2425 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2424, heff_hole()});
    V v_u_2426 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2425);
    V t_0 = v_xs_243;
    V t_1 = v_u_2426;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s502656580x1955732096_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s502656580x1955732096_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s939813003x1383013550_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s939813003x1383013550_24dps_entry, 2, 0};

V g_list_2emap_24s939813003x1383013550_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_get_n(v_x_242, 2, 5);
    V v_t_249;
    switch (heff_tag_of(v_t_244)) {
    case TAG_SizeDefault: {
      v_t_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeNumber: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SizeName: {
      V v_x_246 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 3);
      v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2410);
    V t_0 = v_xs_243;
    V t_1 = v_u_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s939813003x1383013550_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s939813003x1383013550_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1991317015x801331450_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1991317015x801331450_entry, 2, 0};

V g_list_2efoldl_24s1991317015x801331450(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_a_247), NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1991317015x801331450_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1991317015x801331450(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1134414872x1001811115_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1134414872x1001811115_entry, 1, 0};

V g_list_2emap_24s1134414872x1001811115(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 3), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1134414872x1001811115_24dps(v_xs_242, v_cell_243));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1134414872x1001811115_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1134414872x1001811115(a[0]);
}
Clo g_list_2emap_24s262223576x596329185_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s262223576x596329185_entry, 5, 0};

V g_list_2emap_24s262223576x596329185(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_247 = heff_strAppend(heff_dup(v_lit_240), heff_dup(v_lit_241));
    V v_t_248 = heff_strSlice_lent(v_x_245, v_lit_242, heff_strLength_lent(v_a_247, 0), 4);
    V v_t_2411;
    if (heff_strEq_c(v_t_248, v_a_247)) {
      int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_lit_240, 0)) + heff_peek_word(v_lit_243));
      V v_t_2410 = heff_strSlice_lent(v_x_245, heff_box_word(v_t_249), heff_strLength_lent(v_x_245, 0), 6);
      v_t_2411 = heff_rec_n(2, shape_name__key, (V[]){v_t_2410, v_x_245});
    } else {
      v_t_2411 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_x_245), v_x_245});
    }
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
    V v_u_2413 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_xs_246; V a_5 = v_cell_2412; V r_ = (g_list_2emap_24s262223576x596329185_24dps(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_240); heff_drop(v_lit_241); heff_drop(v_lit_243); r_; });
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s262223576x596329185_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s262223576x596329185(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s1161549307x1906011635_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1161549307x1906011635_entry, 1, 0};

V g_list_2ekeepIf_24s1161549307x1906011635(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_SError: {
      V v_cell_244 = heff_tag_re_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2ekeepIf_24s1161549307x1906011635_24dps(v_xs_242, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_SWarning: {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SDebug: {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1161549307x1906011635(a[0]);
}
V g_list_2emergeRuns_24s429166959x353941515_lam0(V self, V *args);
Clo g_list_2emergeRuns_24s429166959x353941515_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s429166959x353941515_entry, 4, 0};

V g_list_2emergeRuns_24s429166959x353941515(V v_lit_240, V v_lit_241, V v_stack_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_MkPair: {
    V v_run_244 = heff_field(v_x3_243, 0);
    V v_x32_245 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    switch (heff_tag_of(v_x32_245)) {
    case TAG_Nil: {
      return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_run_244; V a_3 = v_stack_242; V r_ = (g_list_2ecollapse_24s1189723159x1707000933(a_0, a_1, a_2, a_3)); heff_drop(v_stack_242); r_; });
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x32_245, 0);
      V v_xs_247 = heff_field(v_x32_245, 1);
      heff_take_n(v_x32_245, 3ULL, 2);
      V v_t_248 = (g_list_2epushRun_24s1176995660x590208736(v_lit_240, v_lit_241, MK_INT(0LL), v_run_244, v_stack_242));
      V v_t_2412 = (g_list_2erunFrom(heff_clo_n(g_list_2emergeRuns_24s429166959x353941515_lam0, 2, 2, (V[]){heff_dup(v_lit_240), heff_dup(v_lit_241)}), v_x_246, v_xs_247));
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_t_248;
      V t_3 = v_t_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_stack_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x32_245);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2emergeRuns_24s429166959x353941515_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2emergeRuns_24s429166959x353941515(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_list_2emergeRuns_24s429166959x353941515_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_a_2410 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_a_2411 = heff_strCompare(v_a_249, v_a_2410);
  V v_ret_24bool = heff_bool((heff_intLt_c_lent(v_a_2411, v_lit_240, 0) || heff_intEq_c_lent(v_a_2411, v_lit_241, 0)));
  heff_drop(self);
  heff_drop(v_a_2411);
  return v_ret_24bool;
}
Clo g_list_2eascending_24s91816391x1950127237_clo = {{0x80000000u, K_CLO, 0}, g_list_2eascending_24s91816391x1950127237_entry, 5, 0};

V g_list_2eascending_24s91816391x1950127237(V v_lit_240, V v_lit_241, V v_x_242, V v_acc_243, V v_x4_244) {
top: ;
  switch (heff_tag_of(v_x4_244)) {
  case TAG_Nil: {
    heff_drop(v_x_242);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_246 = heff_field(v_x4_244, 0);
    V v_ys_247 = heff_field(v_x4_244, 1);
    V v_ru_24x4_244_24Cons = heff_take_reuse_n(v_x4_244, 3ULL, 2);
    V v_a_248 = heff_strCompare_lent(v_x_242, v_y_246, 1);
    if ((heff_intLt_c_lent(v_a_248, v_lit_240, 0) || heff_intEq_c_lent(v_a_248, v_lit_241, 0))) {
      heff_drop(v_a_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = heff_dup(v_y_246);
      V t_3 = heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_246, v_acc_243});
      V t_4 = v_ys_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x_242 = t_2;
      v_acc_243 = t_3;
      v_x4_244 = t_4;
      goto top;
    } else {
      heff_drop(v_a_248);
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, heff_tag_re_n(v_ru_24x4_244_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_246, v_ys_247})});
    }
  }
  default: return heff_nomatch(v_x4_244);
  }
}
V g_list_2eascending_24s91816391x1950127237_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eascending_24s91816391x1950127237(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
V g_list_2efoldl_24s44351024x1408738471_24scalars_lam0(V self, V *args);
Clo g_list_2efoldl_24s44351024x1408738471_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s44351024x1408738471_24scalars_entry, 3, 0};

V g_list_2efoldl_24s44351024x1408738471_24scalars(V v_binders_240, V v_uses_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_binders__uses, (V[]){v_binders_240, v_uses_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_x1_245 = heff_dup(v_x_243);
    V v_a_2458;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_At: {
      V v_x11_246 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24At = heff_take_reuse_n(v_x1_245, 1ULL, 2);
      switch (heff_tag_of(v_x11_246)) {
      case TAG_DeclEquations: {
        V v_ty_2411 = heff_field(v_x11_246, 3);
        V v_eqs_2412 = heff_field(v_x11_246, 4);
        heff_take_n(v_x11_246, 24ULL, 5);
        V v_a_2413 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), heff_dup(v_ty_2411)));
        V v_binders_2414 = heff_take_field(v_a_2413, 0);
        V v_uses_2415 = heff_get_n(v_a_2413, 1, 2);
        V v_b_2438 = ({ V b_0 = heff_clo_n(g_list_2efoldl_24s44351024x1408738471_24scalars_lam0, 2, 1, (V[]){v_ty_2411}); V a_1 = heff_dup(g_heff_2eelab_2elocals_2enone_get()); V a_2 = v_eqs_2412; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_eqs_2412); r_; });
        V v_binders_2439 = heff_take_field(v_b_2438, 0);
        V v_uses_2440 = heff_take_field(v_b_2438, 1);
        V v_t_2441 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x1_245_24At, v_binders_2414, v_binders_2439));
        V v_t_2442 = (g_prelude_2e_2b_2b(v_uses_2415, v_uses_2440));
        v_a_2458 = ({ V rv_0 = v_t_2441; V rv_1 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_b_2438, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
        break;
      }
      case TAG_DeclDefine: {
        V v_ps_2445 = heff_field(v_x11_246, 2);
        V v_ty_2446 = heff_field(v_x11_246, 3);
        V v_body_2447 = heff_field(v_x11_246, 4);
        heff_take_n(v_x11_246, 28ULL, 5);
        heff_drop_cell(v_ru_24x1_245_24At, 2);
        v_a_2458 = ({ V a_0 = v_ty_2446; V a_1 = v_body_2447; V a_2 = NTAG(TAG_Nil); V a_3 = v_ps_2445; V r_ = (g_heff_2eelab_2elocals_2earguments_24s293651280x633455360(a_0, a_1, a_2, a_3)); heff_drop(v_ty_2446); heff_drop(v_body_2447); r_; });
        break;
      }
      case TAG_DeclTheory: {
        V v_ps_2450 = heff_field(v_x11_246, 2);
        V v_body_2451 = heff_field(v_x11_246, 3);
        heff_take_n(v_x11_246, 12ULL, 4);
        heff_drop_cell(v_ru_24x1_245_24At, 2);
        v_a_2458 = ({ V a_0 = v_body_2451; V a_1 = NTAG(TAG_Nil); V a_2 = v_ps_2450; V r_ = (g_heff_2eelab_2elocals_2earguments_24s1500734611x902047908(a_0, a_1, a_2)); heff_drop(v_body_2451); r_; });
        break;
      }
      case TAG_DeclPrimitive: {
        V v_t_2454 = heff_field(v_x11_246, 2);
        heff_take_n(v_x11_246, 4ULL, 3);
        heff_drop_cell(v_ru_24x1_245_24At, 2);
        v_a_2458 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), v_t_2454));
        break;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_245_24At, 2);
        v_a_2458 = heff_dup(g_heff_2eelab_2elocals_2enone_get());
        break;
      }
      case TAG_DeclWatch: {
        V v_e_2457 = heff_field(v_x11_246, 0);
        heff_take_n(v_x11_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x1_245_24At, 2);
        v_a_2458 = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(NTAG(TAG_Nil), v_e_2457));
        break;
      }
      default: heff_nomatch(v_x11_246);
      }
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    V v_binders_2459 = heff_take_field(v_a_2458, 0);
    V v_uses_2460 = heff_get_n(v_a_2458, 1, 2);
    V v_t_2461 = (g_prelude_2e_2b_2b(v_binders_240, v_binders_2459));
    V v_t_2462 = (g_prelude_2e_2b_2b(v_uses_241, v_uses_2460));
    V t_0 = v_t_2461;
    V t_1 = v_t_2462;
    V t_2 = v_xs_244;
    v_binders_240 = t_0;
    v_uses_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s44351024x1408738471_24scalars_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s44351024x1408738471_24scalars(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_list_2efoldl_24s44351024x1408738471_24scalars_lam0(V self, V *args) {
  V v_acc_2416 = args[0];
  V v_eq_2417 = args[1];
  V v_ty_2411 = heff_env(self)[0];
  V v_binders_2418 = heff_take_field(v_acc_2416, 0);
  V v_uses_2419 = heff_get_n(v_acc_2416, 1, 2);
  heff_clo_take(self, 1);
  V v_env_2420 = (g_list_2efoldl_24f1488358745x465096512(NTAG(TAG_Nil), v_ty_2411));
  V v_x3_2421 = v_eq_2417;
  V v_b_2433;
  switch (heff_tag_of(v_x3_2421)) {
  case TAG_At: {
    V v_x31_2422 = heff_field(v_x3_2421, 0);
    V v_ru_24x3_2421_24At = heff_take_reuse_n(v_x3_2421, 1ULL, 2);
    switch (heff_tag_of(v_x31_2422)) {
    case TAG_MkEquation: {
      V v_ps_2426 = heff_field(v_x31_2422, 2);
      V v_rhs_2427 = heff_field(v_x31_2422, 3);
      heff_take_n(v_x31_2422, 12ULL, 4);
      V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ps_2426));
      V v_bs_2429 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2428; V r_ = (g_list_2efoldl_24s2031248677x950202423(a_0, a_1)); heff_drop(v_t_2428); r_; });
      V v_env_2430 = (g_list_2efoldl_24s1370882877x364361272(v_env_2420, heff_dup(v_bs_2429)));
      V v_b_2431 = ({ V a_0 = v_env_2430; V a_1 = v_rhs_2427; V r_ = (g_heff_2eelab_2elocals_2ewalkF_24s647638360x416151481(a_0, a_1)); heff_drop(v_env_2430); r_; });
      V v_t_2432 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_2421_24At, v_bs_2429, heff_take_field(v_b_2431, 0)));
      v_b_2433 = ({ V rv_0 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_b_2431, 2ULL, 2, shape_binders__uses, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      break;
    }
    default: heff_nomatch(v_x31_2422);
    }
    break;
  }
  default: heff_nomatch(v_x3_2421);
  }
  V v_binders_2434 = heff_take_field(v_b_2433, 0);
  V v_uses_2435 = heff_take_field(v_b_2433, 1);
  V v_t_2436 = (g_prelude_2e_2b_2b(v_binders_2418, v_binders_2434));
  V v_t_2437 = (g_prelude_2e_2b_2b(v_uses_2419, v_uses_2435));
  return ({ V rv_0 = v_t_2436; V rv_1 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_b_2433, 0ULL, 2, shape_binders__uses, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
Clo g_list_2emerge_24s991540778x2011810329_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s991540778x2011810329_entry, 2, 0};

V g_list_2emerge_24s991540778x2011810329(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return (g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096(NTAG(TAG_True), v_xs_240, v_ys_241));
  }
  case TAG_Cons: {
    V v_a_242 = heff_dup(heff_field(v_xs_240, 0));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_a_242, 5);
      return (g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096(NTAG(TAG_True), v_xs_240, v_ys_241));
    }
    case TAG_Cons: {
      V v_b_244 = heff_dup(heff_field(v_ys_241, 0));
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_a_242, 0)), 1, 2);
      V v_t_247 = heff_get_n(heff_get_n(v_a_242, 0, 5), 0, 2);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_b_244, 0)), 1, 2);
      V v_t_249 = heff_get_n(heff_get_n(v_b_244, 0, 5), 0, 2);
      if (heff_intLe_c(heff_intSub(v_t_246, v_t_247), heff_intSub(v_t_248, v_t_249))) {
        return (g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096(NTAG(TAG_True), v_xs_240, v_ys_241));
      } else {
        return (g_list_2emerge_2emergeFrom_240_24s1347095278x1389872096(NTAG(TAG_False), v_ys_241, v_xs_240));
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s991540778x2011810329_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s991540778x2011810329(a[0], a[1]);
}
Clo g_list_2efoldl_24s496727651x1448898893_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s496727651x1448898893_entry, 2, 0};

V g_list_2efoldl_24s496727651x1448898893(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkEquation: {
        V v_a_249 = heff_field(v_a_244, 3);
        v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_249));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2411 = (g_prelude_2e_2b_2b(v_t_2410, v_z_240));
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s496727651x1448898893(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eascending_24s390745979x1196509894_clo = {{0x80000000u, K_CLO, 0}, g_list_2eascending_24s390745979x1196509894_entry, 3, 0};

V g_list_2eascending_24s390745979x1196509894(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 5);
    V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_244 = heff_field(v_x4_242, 0);
    V v_ys_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_246 = heff_get_n(heff_get_n(v_x_240, 2, 5), 0, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_y_244, 2)), 0, 2);
    if (heff_intLe_c(v_t_246, v_t_247)) {
      V t_0 = heff_dup(v_y_244);
      V t_1 = heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_y_244, v_acc_241});
      V t_2 = v_ys_245;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    } else {
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, heff_tag_re_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_y_244, v_ys_245})});
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2eascending_24s390745979x1196509894_entry(V self, V *a) {
  (void)self;
  return g_list_2eascending_24s390745979x1196509894(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1007499915x73800978_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1007499915x73800978_24dps_entry, 2, 0};

V g_list_2emap_24s1007499915x73800978_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_p_244 = v_x_242;
    V v_t_245 = heff_rec_n(3, shape_group__branches__current, (V[]){MK_INT(-1LL), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    HeffT3 v_t_246 = ({ V a_0 = v_p_244; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_245; V a_4 = NTAG(TAG_Nil); HeffT3 r_ = (g_regex_2ereadFrom_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_p_244); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      V v_field_249 = v_t_246.f[2];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      V v_t_2419;
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_field_249);
        V v_why_2410 = v_field_248;
        v_t_2419 = heff_tag_n(TAG_Left, 1, (V[]){v_why_2410});
      } else {
        V v_node_2411 = v_field_248;
        V v_groups_2412 = v_field_249;
        V v_t_2413 = (g_regex_2eemit(v_node_2411, MK_INT(1LL)));
        V v_t_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_Done), NTAG(TAG_Nil)});
        V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Keep, 1, (V[]){MK_INT(1LL)}), v_t_2414});
        V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2415));
        V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Keep, 1, (V[]){MK_INT(0LL)}), v_t_2416});
        V v_t_2418 = heff_tag_n(TAG_MkRegex, 2, (V[]){heff_arrayFromList(v_t_2417), v_groups_2412});
        v_t_2419 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2418});
      }
      V v_cell_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
      V v_u_2421 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2420);
      V t_0 = v_xs_243;
      V t_1 = v_u_2421;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1007499915x73800978_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1007499915x73800978_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s344878118x1065108086_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s344878118x1065108086_entry, 3, 0};

V g_list_2efoldl_24s344878118x1065108086(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_at_245 = heff_dup(heff_rfield(v_x_243, 0));
    V v_launch_246 = heff_dup(heff_rfield(v_x_243, 2));
    V v_pending_247 = heff_dup(heff_rfield(v_x_243, 1));
    V v_t_248 = (g_prelude_2e_2b_2b_24f1876770336x1656095219(v_z_241, v_at_245, v_launch_246, heff_dup(v_lit_240), heff_get_n(v_pending_247, 4, 7)));
    V t_0 = v_lit_240;
    V t_1 = v_t_248;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s344878118x1065108086_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl_24s344878118x1065108086(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1531382666x123921537_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1531382666x123921537_24dps_entry, 2, 0};

V g_list_2emap_24s1531382666x123921537_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_args_244 = heff_take_field(v_x_242, 3);
    V v_name_245 = heff_take_field(v_x_242, 0);
    V v_doc_246 = heff_get_n(v_x_242, 1, 4);
    V v_t_247 = heff_tr(heff_call(v_args_244, 1, (V[]){heff_dup(g_std_2ecli_2ereading_get())}));
    V v_t_248 = heff_rec_n(3, shape_name__doc__shape, (V[]){v_name_245, v_doc_246, heff_get_n(v_t_247, 0, 2)});
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_249);
    V t_0 = v_xs_243;
    V t_1 = v_u_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1531382666x123921537_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1531382666x123921537_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s1539380703x380520933_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1539380703x380520933_24dps_str1, 0, "");
Clo g_list_2emap_24s1539380703x380520933_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1539380703x380520933_24dps_entry, 2, 0};

V g_list_2emap_24s1539380703x380520933_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_strRunes(((V)&g_list_2emap_24s1539380703x380520933_24dps_str0)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_245 = heff_rec_n(2, shape_text__at, (V[]){heff_strRunes(((V)&g_list_2emap_24s1539380703x380520933_24dps_str1)), v_t_244});
    V v_t_246 = heff_rec_n(2, shape_part__input, (V[]){heff_tag_n(TAG_Positional, 1, (V[]){v_x_242}), heff_tag_n(TAG_Typed, 1, (V[]){v_t_245})});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_247);
    V t_0 = v_xs_243;
    V t_1 = v_u_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1539380703x380520933_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2emap_24s1539380703x380520933_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f1428393365x1980555854_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1428393365x1980555854_entry, 3, 0};

V g_list_2efoldl_24f1428393365x1980555854(V v_z_240, V v_p_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = heff_tag_re_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_243, v_z_240});
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_z_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_z_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1428393365x1980555854(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f2071981990x435576741_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2071981990x435576741_entry, 3, 0};

V g_list_2efoldl_24f2071981990x435576741(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    switch (heff_tag_of(v_x_243)) {
    case TAG_GivenBuilt: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_GivenSame: {
      V t_0 = v_lit_240;
      V t_1 = heff_intAdd_lent(v_z_241, v_lit_240, 1);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_GivenOther: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f2071981990x435576741_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl_24f2071981990x435576741(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24f768999161x1997188166_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f768999161x1997188166_24dps_entry, 4, 0};

V g_list_2emap_24f768999161x1997188166_24dps(V v_lit_240, V v_box_24i_241, V v_box_24n_242, V v_d_243) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  int64_t v_n_242 = heff_peek_word(v_box_24n_242);
top: ;
  if ((v_n_242 <= v_i_241)) {
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strByteAt_lent(v_lit_240, heff_box_word(v_i_241), 2), heff_hole()});
    V v_u_245 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_244);
    V t_0 = v_lit_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    int64_t t_2 = v_n_242;
    V t_3 = v_u_245;
    v_lit_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
}
V g_list_2emap_24f768999161x1997188166_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24f768999161x1997188166_24dps(a0, a[1], a2, a3); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emap_24f201346761x152404242_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f201346761x152404242_24dps_entry, 8, 0};

V g_list_2emap_24f201346761x152404242_24dps(V v_box_24lit_240, V v_lit_241, V v_box_24lit_242, V v_box_24lit_243, V v_box_24lit_244, V v_a_245, V v_box_24b_246, V v_d_247) {
  int64_t v_lit_240 = heff_peek_word(v_box_24lit_240);
  int64_t v_lit_242 = heff_peek_word(v_box_24lit_242);
  int64_t v_lit_243 = heff_peek_word(v_box_24lit_243);
  int64_t v_lit_244 = heff_peek_word(v_box_24lit_244);
  int64_t v_b_246 = heff_peek_word(v_box_24b_246);
top: ;
  if ((v_b_246 < heff_peek_word(v_a_245))) {
    heff_drop(v_a_245);
    return heff_setField(heff_dup(v_d_247), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_249;
    if (((v_lit_240 <= heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_a_245, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_a_245, 0)) <= v_lit_242))) {
      int64_t v_t_248 = (heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_a_245, 0)) + v_lit_243);
      v_t_249 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_248))));
    } else {
      v_t_249 = heff_strSlice_lent(v_lit_241, v_a_245, heff_box_word((heff_peek_word(v_a_245) + v_lit_244)), 4);
    }
    V v_cell_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setFieldPeek(v_d_247, MK_INT(1LL), v_cell_2410);
    int64_t t_0 = v_lit_240;
    V t_1 = v_lit_241;
    int64_t t_2 = v_lit_242;
    int64_t t_3 = v_lit_243;
    int64_t t_4 = v_lit_244;
    V t_5 = heff_box_word((heff_unbox_word(v_a_245) + ((int64_t)1ULL)));
    int64_t t_6 = v_b_246;
    V t_7 = v_u_2411;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_a_245 = t_5;
    v_b_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
}
V g_list_2emap_24f201346761x152404242_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2emap_24f201346761x152404242_24dps(a0, a1, a2, a3, a4, a[5], a6, a7); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a6); heff_drop(a7); return r;
}
Clo g_list_2efoldl_24f1134152647x940271785_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1134152647x940271785_entry, 2, 0};

V g_list_2efoldl_24f1134152647x940271785(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ecomment(heff_rfield(v_x_242, 0)));
    V v_x_245 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_244));
    V v_t_246 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_245));
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f1134152647x940271785_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24f1134152647x940271785(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24f1559904364x1248618624_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1559904364x1248618624_entry, 3, 0};

V g_list_2efoldl_24f1559904364x1248618624(V v_z_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_x_243)}));
    V v_t_246 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_245));
    V t_0 = v_t_246;
    V t_1 = v_f_241;
    V t_2 = v_xs_244;
    v_z_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1559904364x1248618624_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_list_2efoldl_24f1559904364x1248618624(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f2094160282x1876485468_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f2094160282x1876485468_entry, 3, 0};

V g_list_2efoldl_24f2094160282x1876485468(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_dup(heff_rfield(v_x_243, 1));
    switch (heff_tag_of(v_t_245)) {
    case TAG_SError: {
      V t_0 = v_lit_240;
      V t_1 = heff_intAdd_lent(v_z_241, v_lit_240, 1);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_SWarning: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    case TAG_SDebug: {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_list_2efoldl_24f2094160282x1876485468(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_list_2emap_24f2124896334x71745266_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f2124896334x71745266_entry, 12, 0};

V g_list_2emap_24f2124896334x71745266(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_lit_244, V v_lit_245, V v_box_24lit_246, V v_box_24lit_247, V v_lit_248, V v_lit_249, V v_box_24lit_2410, V v_x2_2411) {
  int64_t v_lit_243 = heff_peek_word(v_box_24lit_243);
  int64_t v_lit_246 = heff_peek_word(v_box_24lit_246);
  int64_t v_lit_247 = heff_peek_word(v_box_24lit_247);
  int64_t v_lit_2410 = heff_peek_word(v_box_24lit_2410);
top: ;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24Cons = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_a_2414 = heff_dup(heff_rfield(v_x_2412, 0));
    if ((heff_intLe_c_lent(v_lit_240, heff_strFind_lent(v_lit_241, v_a_2414, v_lit_242, 0), 2) ? (((v_lit_243 <= heff_unbox_word(heff_strByteAt_lent(v_a_2414, v_lit_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_a_2414, v_lit_245, 0)) <= v_lit_246)) ? 0 : ((v_lit_247 <= heff_unbox_word(heff_strByteAt_lent(v_a_2414, v_lit_248, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_a_2414, v_lit_249, 0)) <= v_lit_2410) : 1)) : 1)) {
      heff_drop(v_a_2414);
      V v_t_2415 = ({ V rr_ = heff_rec_reuse_na(v_x_2412, 3ULL, 2, shape_name__key, 15u, 0u); rr_; });
      V v_cell_2416 = heff_tag_at_n(v_ru_24x2_2411_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
      V v_u_2417 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V b_3 = heff_box_word(v_lit_243); V a_4 = v_lit_244; V a_5 = v_lit_245; V b_6 = heff_box_word(v_lit_246); V b_7 = heff_box_word(v_lit_247); V a_8 = v_lit_248; V a_9 = v_lit_249; V b_10 = heff_box_word(v_lit_2410); V a_11 = v_xs_2413; V a_12 = v_cell_2416; V r_ = (g_list_2emap_24f2124896334x71745266_24dps(a_0, a_1, a_2, b_3, a_4, a_5, b_6, b_7, a_8, a_9, b_10, a_11, a_12)); heff_drop(b_3); heff_drop(b_6); heff_drop(b_7); heff_drop(b_10); r_; });
      heff_drop(v_u_2417);
      return v_cell_2416;
    } else {
      heff_drop_rec(v_x_2412, 2);
      heff_drop_cell(v_ru_24x2_2411_24Cons, 2);
      heff_drop(v_a_2414);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      int64_t t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      int64_t t_6 = v_lit_246;
      int64_t t_7 = v_lit_247;
      V t_8 = v_lit_248;
      V t_9 = v_lit_249;
      int64_t t_10 = v_lit_2410;
      V t_11 = v_xs_2413;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_lit_248 = t_8;
      v_lit_249 = t_9;
      v_lit_2410 = t_10;
      v_x2_2411 = t_11;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_list_2emap_24f2124896334x71745266_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a6 = a[6]; V a7 = a[7]; V a8 = a[8]; V a9 = a[9]; V a10 = a[10]; V r = g_list_2emap_24f2124896334x71745266(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a[11]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a6); heff_drop(a7); heff_drop(a8); heff_drop(a9); heff_drop(a10); return r;
}