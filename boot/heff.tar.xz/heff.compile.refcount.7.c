// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CIf 14188
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondRel 54343
#define TAG_CondRelU 46269
#define TAG_CondTrue 53113
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_KnownCell 38933
#define TAG_KnownClo 18392
#define TAG_KnownRec 32578
#define TAG_KnownTag 34380
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Reuse 22912
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38305
#define LBL_after 294093302
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_cells 295903083
#define LBL_flat 9641024
#define LBL_funs 9650075
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_lent 9813446
#define LBL_n 328
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tag 324116
#define LBL_takes 311482598
#define LBL_tokens 1078955205
#define LBL_workers 1757018875
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tokens, LBL_ret};
static uint32_t shape_n__tag[] = {LBL_n, LBL_tag};
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2erefcount_2eanyW(V, V);
V g_heff_2ecompile_2erefcount_2eanyW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eanyW_clo;
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_clo;
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630_clo;
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447(V, V);
V g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_clo;
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_clo;
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_clo;
V g_heff_2ecompile_2erefcount_2edropOf(V, V);
V g_heff_2ecompile_2erefcount_2edropOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropOf_clo;
V g_heff_2ecompile_2erefcount_2edropsOf(V, V);
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2edropsOf_clo;
V g_heff_2ecompile_2erefcount_2eelemS(V, V);
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eelemS_clo;
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
HeffT4 g_heff_2ecompile_2erefcount_2efunPlain_24cpr(V, V, V, V);
HeffT4 g_heff_2ecompile_2erefcount_2efunWith_24cpr(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2efvArm(V);
V g_heff_2ecompile_2erefcount_2efvArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efvArm_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2eindexIn(V, V, V);
V g_heff_2ecompile_2erefcount_2eindexIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eindexIn_clo;
HeffT2 g_heff_2ecompile_2erefcount_2eindexIn_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ejustsOf(V);
V g_heff_2ecompile_2erefcount_2ejustsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ejustsOf_clo;
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps(V, V);
V g_heff_2ecompile_2erefcount_2ejustsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ejustsOf_24dps_clo;
V g_heff_2ecompile_2erefcount_2ekeepBits_24f399512368x496480558(V, V);
V g_heff_2ecompile_2erefcount_2ekeepBits_24f399512368x496480558_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ekeepBits_24f399512368x496480558_clo;
V g_heff_2ecompile_2erefcount_2enotFlatAt(V, V, V);
V g_heff_2ecompile_2erefcount_2enotFlatAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2enotFlatAt_clo;
HeffT2 g_heff_2ecompile_2erefcount_2enthValue_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(V, V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852_clo;
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(V, V, V);
V g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338_clo;
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok1(V, V, V, V, V);
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_clo;
HeffT4 g_heff_2ecompile_2erefcount_2ercDef_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2erebuiltOp_24s510905267x500217447_24cpr(V, V);
HeffT2 g_heff_2ecompile_2erefcount_2erebuiltSts_24s860872616x1839682545_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531(V, V);
V g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_clo;
V g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_24dps(V, V, V, V);
V g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_24dps_clo;
HeffT2 g_heff_2ecompile_2erefcount_2erebuiltVs_24s1306915676x1772197351_24cpr(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs(V, V);
V g_heff_2ecompile_2erefcount_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseArgs_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2ereusePrim_get(void);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24dps_24cpr(V, V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV(V, V, V);
V g_heff_2ecompile_2erefcount_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ereuseV_clo;
HeffT2 g_heff_2ecompile_2erefcount_2ereuseV_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2esameBits(V, V, V, V);
V g_heff_2ecompile_2erefcount_2esameBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2esameBits_clo;
V g_heff_2ecompile_2erefcount_2eshapesOfV(V, V);
V g_heff_2ecompile_2erefcount_2eshapesOfV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2eshapesOfV_clo;
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(V, V, V);
V g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187_clo;
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(V, V);
V g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565_clo;
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(V, V, V, V);
V g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797_clo;
V g_heff_2ecompile_2erefcount_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erefcount_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithBorrowed_clo;
V g_heff_2ecompile_2erefcount_2ewithFrame(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithFrame_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithFrame_clo;
V g_heff_2ecompile_2erefcount_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo;
V g_heff_2ecompile_2erefcount_2ewithPath(V, V, V);
V g_heff_2ecompile_2erefcount_2ewithPath_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithPath_clo;
V g_heff_2ecompile_2erefcount_2ewithTakes(V, V);
V g_heff_2ecompile_2erefcount_2ewithTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2ewithTakes_clo;
HeffT2 g_heff_2ecompile_2erepr_2eprimShape_24cpr(V);
V g_list_2eany_24s910662703x1730636603(V);
V g_list_2eany_24s910662703x1730636603_entry(V self, V *a);
extern Clo g_list_2eany_24s910662703x1730636603_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1428393365x1980555854(V, V, V);
V g_list_2efoldl_24f1428393365x1980555854_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1428393365x1980555854_clo;
V g_list_2efoldl_24s1060781110x816201608(V, V);
V g_list_2efoldl_24s1060781110x816201608_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1060781110x816201608_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1548442597x958354846(V, V);
V g_list_2efoldl_24s1548442597x958354846_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1548442597x958354846_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s976906006x1321876394(V, V, V, V);
V g_list_2efoldl_24s976906006x1321876394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s976906006x1321876394_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1068270568x176847536(V);
V g_list_2emap_24s1068270568x176847536_entry(V self, V *a);
extern Clo g_list_2emap_24s1068270568x176847536_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1796125103x644876049_24tok1(V, V);
V g_list_2emap_24s1796125103x644876049_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24tok1_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
Clo g_heff_2ecompile_2erefcount_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erefcount_2ewithKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ewithKnown_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2ewithKnown(V v_x_240, V v_k_241, V v_ce_242) {
top: ;
  V v_t_243 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_ce_242, 8), v_x_240, v_k_241));
  return ({ V rv_8 = v_t_243; V rr_ = heff_rec_reuse_nf(v_ce_242, 130815ULL, 17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, 4294770687u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
}
V g_heff_2ecompile_2erefcount_2ewithKnown_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erefcount_2ewithKnown(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erefcount_2edropsOf_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2edropsOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2edropsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2edropsOf_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2edropsOf(V v_ce_240, V v_xs_241) {
top: ;
  V v_reprs_242 = heff_take_field(v_ce_240, 10);
  V v_known_243 = heff_get_n(v_ce_240, 8, 17);
  V v_t_249 = ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_clo_n(g_heff_2ecompile_2erefcount_2edropsOf_lam0, 1, 1, (V[]){v_reprs_242}); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24f1428393365x1980555854(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2edropsOf_lam1, 2, 1, (V[]){v_known_243}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_249); r_; });
}
V g_heff_2ecompile_2erefcount_2edropsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2edropsOf(a[0], a[1]);
}
V g_heff_2ecompile_2erefcount_2edropsOf_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_reprs_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_245 = ({ V a_0 = v_reprs_242; V a_1 = v_x_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_reprs_242); heff_drop(v_x_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_246 == ((int64_t)0ULL)) ? ({ V v_x_248 = heff_dup(v_field_247); int c_ = 0; heff_drop(v_x_248); c_; }) : 1));
    heff_drop(v_field_247);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2erefcount_2edropsOf_lam1(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_known_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = ({ V a_0 = v_known_243; V a_1 = v_x_2411; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_known_243); r_; });
  V v_t_2413 = (g_heff_2ecompile_2erefcount_2edropOf(v_x_2411, v_t_2412));
  return (g_prelude_2e_2b_2b(v_t_2413, v_acc_2410));
}
Clo g_heff_2ecompile_2erefcount_2eindexIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2eindexIn_entry, 3, 0};

V g_heff_2ecompile_2erefcount_2eindexIn(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2erefcount_2eindexIn_24cpr(v_l_240, v_i_241, v_x3_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2erefcount_2eindexIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2erefcount_2eindexIn(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}

static V g_heff_2ecompile_2erefcount_2ereusePrim_val;
static HEFF_ONCE g_heff_2ecompile_2erefcount_2ereusePrim_st;
static V g_heff_2ecompile_2erefcount_2ereusePrim_init(void) {
  return NTAG(TAG_Reuse);
}
V g_heff_2ecompile_2erefcount_2ereusePrim_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erefcount_2ereusePrim_st)) return g_heff_2ecompile_2erefcount_2ereusePrim_val;
  return heff_global(&g_heff_2ecompile_2erefcount_2ereusePrim_val, &g_heff_2ecompile_2erefcount_2ereusePrim_st, g_heff_2ecompile_2erefcount_2ereusePrim_init);
}
Clo g_heff_2ecompile_2erefcount_2ejustsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ejustsOf_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2ejustsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2erefcount_2ejustsOf_24dps(v_rest_242, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2ejustsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2ejustsOf(a[0]);
}
Clo g_heff_2ecompile_2erefcount_2esameBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2esameBits_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2esameBits(V v_ce_240, V v_x2_241, V v_t_242, V v_es_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SVar: {
    V v_ru_244 = heff_field(v_x2_241, 0);
    HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_ce_240, 8, 17); V a_1 = v_ru_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_it1_248 = v_field_247;
        switch (heff_tag_of(v_it1_248)) {
        case TAG_KnownTag: {
          heff_take_n(v_it1_248, 0ULL, 1);
          return MK_INT(0LL);
        }
        case TAG_KnownCell: {
          V v_t0_2411 = heff_field(v_it1_248, 1);
          V v_vs_2412 = heff_field(v_it1_248, 2);
          heff_take_n(v_it1_248, 6ULL, 3);
          if ((heff_strEq_c_lent(v_t_242, v_t0_2411, 0) && ({ V v_t_2437 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2412)); int c_ = ({ V v_t_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_es_243)); int c_ = heff_intEq_c_lent(v_t_2437, v_t_2438, 0); heff_drop(v_t_2438); c_; }); heff_drop(v_t_2437); c_; }))) {
            heff_drop(v_t0_2411);
            return ({ V a_0 = v_vs_2412; V a_1 = v_es_243; V r_ = (g_heff_2ecompile_2erefcount_2ekeepBits_24f399512368x496480558(a_0, a_1)); heff_drop(v_vs_2412); r_; });
          } else {
            heff_drop(v_t0_2411);
            heff_drop(v_vs_2412);
            return MK_INT(0LL);
          }
        }
        case TAG_KnownRec: {
          heff_take_n(v_it1_248, 0ULL, 1);
          return MK_INT(0LL);
        }
        case TAG_KnownClo: {
          heff_take_n(v_it1_248, 0ULL, 1);
          return MK_INT(0LL);
        }
        default: return heff_nomatch(v_it1_248);
        }
      } else {
        heff_drop(v_field_247);
        return MK_INT(0LL);
      }
    }
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  case TAG_SInt: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  case TAG_SFloat: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  case TAG_SStr: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  case TAG_SBytes: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  case TAG_SFixed: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  case TAG_SFloat32: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  case TAG_SPrimFn: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  case TAG_SLam: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  case TAG_STag: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  case TAG_SRec: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  case TAG_SProj: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  case TAG_SPrim: {
    heff_drop_rec(v_ce_240, 17);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erefcount_2esameBits_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2esameBits(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erefcount_2efvArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2efvArm_entry, 1, 0};

V g_heff_2ecompile_2erefcount_2efvArm(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_ATail: {
    V v_t_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ATail = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ATail, TAG_ITl, 1, (V[]){v_t_241}), NTAG(TAG_Nil)});
    HeffT2 v_t_243 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_242));
    {
      V v_field_244 = v_t_243.f[0];
      V v_field_245 = v_t_243.f[1];
      V v_bs_246 = v_field_244;
      V v_ms_247 = v_field_245;
      V v_ms_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_247));
      V v_t_249 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_246; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_246); r_; });
      return ({ V a_0 = v_t_249; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_248; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
    }
  }
  case TAG_ASts: {
    V v_ss_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ASts = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ASts, TAG_ISts, 1, (V[]){v_ss_2410}), NTAG(TAG_Nil)});
    HeffT2 v_t_2412 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2411));
    {
      V v_field_2413 = v_t_2412.f[0];
      V v_field_2414 = v_t_2412.f[1];
      V v_bs_2415 = v_field_2413;
      V v_ms_2416 = v_field_2414;
      V v_ms_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_2416));
      V v_t_2418 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_bs_2415; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_bs_2415); r_; });
      return ({ V a_0 = v_t_2418; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_ms_2417; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erefcount_2efvArm_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2efvArm(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ereuseV_24cpr_str0, 0, "");
V g_heff_2ecompile_2erefcount_2ereuseV_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ereuseV_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2ereuseV_24cpr(V v_ru_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SVar: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SGlobal: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SInt: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SFloat: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SStr: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SBytes: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SFixed: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SFloat32: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SPrimFn: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SLam: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_STag: {
    V v_t_2415 = heff_field(v_x3_242, 0);
    V v_argv_2416 = heff_field(v_x3_242, 1);
    V v_ts_2417 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24STag = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_2416));
    if ((heff_intEq_c(heff_dup(v_t_2418), heff_dup(heff_rfield(v_n_241, 0))) && ((heff_strEq_c(heff_dup(heff_rfield(v_n_241, 1)), ((V)&g_heff_2ecompile_2erefcount_2ereuseV_24cpr_str0)) || heff_strEq_c(heff_dup(heff_rfield(v_n_241, 1)), heff_dup(v_t_2415))) && ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2415, 0))) ? !(heff_unbox_word(heff_strByteAt_lent(v_t_2415, MK_INT(0LL), 2)) == ((int64_t)35ULL)) : 1)))) {
      heff_drop_rec(v_n_241, 2);
      heff_drop(v_t_2418);
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_re_n(v_ru_24x3_242_24STag, TAG_STag, 3, 7ULL, (V[]){v_t_2415, v_argv_2416, v_ts_2417}), NTAG(TAG_Nil)});
      V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_ru_240}), v_t_2419});
      return ((HeffT2){{NTAG(TAG_True), heff_tag_n(TAG_SPrim, 2, (V[]){heff_dup(g_heff_2ecompile_2erefcount_2ereusePrim_get()), v_t_2420})}});
    } else {
      heff_drop(v_t_2418);
      V v_x3_2422 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseV_24cpr_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_argv_2416; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_argv_2416); r_; });
      switch (heff_tag_of(v_x3_2422)) {
      case TAG_MkPair: {
        V v_b_2423 = heff_field(v_x3_2422, 0);
        V v_argv_2424 = heff_field(v_x3_2422, 1);
        heff_take_n(v_x3_2422, 3ULL, 2);
        return ((HeffT2){{v_b_2423, heff_tag_re_n(v_ru_24x3_242_24STag, TAG_STag, 3, 5ULL, (V[]){v_t_2415, v_argv_2424, v_ts_2417})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x3_2422)}});
      }
    }
  }
  case TAG_SRec: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SProj: {
    heff_drop(v_ru_240);
    heff_drop_rec(v_n_241, 2);
    return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
  }
  case TAG_SPrim: {
    V v_x31_2431 = heff_dup(heff_field(v_x3_242, 0));
    V v_x32_2432 = heff_dup(heff_field(v_x3_242, 1));
    switch (heff_tag_of(v_x31_2431)) {
    case TAG_Reuse: {
      switch (heff_tag_of(v_x32_2432)) {
      case TAG_Nil: {
        heff_drop(v_ru_240);
        heff_drop_rec(v_n_241, 2);
        return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
      }
      case TAG_Cons: {
        V v_cell_2433 = heff_field(v_x32_2432, 0);
        V v_x322_2434 = heff_field(v_x32_2432, 1);
        V v_ru_24x32_2432_24Cons = heff_take_reuse_n(v_x32_2432, 3ULL, 2);
        switch (heff_tag_of(v_x322_2434)) {
        case TAG_Nil: {
          heff_drop(v_ru_240);
          heff_drop_rec(v_n_241, 2);
          heff_drop(v_cell_2433);
          heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
          return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
        }
        case TAG_Cons: {
          V v_x3221_2435 = heff_field(v_x322_2434, 0);
          V v_x3222_2436 = heff_field(v_x322_2434, 1);
          V v_ru_24x322_2434_24Cons = heff_take_reuse_n(v_x322_2434, 3ULL, 2);
          switch (heff_tag_of(v_x3221_2435)) {
          case TAG_SVar: {
            heff_take_n(v_x3221_2435, 0ULL, 1);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          case TAG_SGlobal: {
            heff_take_n(v_x3221_2435, 0ULL, 1);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          case TAG_SInt: {
            heff_take_n(v_x3221_2435, 0ULL, 1);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          case TAG_SFloat: {
            heff_take_na(v_x3221_2435, 0ULL, 1);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          case TAG_SStr: {
            heff_take_n(v_x3221_2435, 0ULL, 1);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          case TAG_SBytes: {
            heff_take_n(v_x3221_2435, 0ULL, 1);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          case TAG_SFixed: {
            heff_take_n(v_x3221_2435, 0ULL, 2);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          case TAG_SFloat32: {
            heff_take_na(v_x3221_2435, 0ULL, 1);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          case TAG_SPrimFn: {
            heff_take_n(v_x3221_2435, 0ULL, 1);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          case TAG_SLam: {
            heff_take_n(v_x3221_2435, 0ULL, 2);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          case TAG_STag: {
            V v_t_2449 = heff_field(v_x3221_2435, 0);
            V v_argv_2450 = heff_field(v_x3221_2435, 1);
            V v_ts_2451 = heff_field(v_x3221_2435, 2);
            V v_ru_24x3221_2435_24STag = heff_take_reuse_n(v_x3221_2435, 7ULL, 3);
            switch (heff_tag_of(v_x3222_2436)) {
            case TAG_Nil: {
              heff_drop_tag(v_x3_242, 2);
              V v_x5_2453 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseV_24cpr_lam1, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_argv_2450; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_argv_2450); r_; });
              switch (heff_tag_of(v_x5_2453)) {
              case TAG_MkPair: {
                V v_b_2454 = heff_field(v_x5_2453, 0);
                V v_argv_2455 = heff_field(v_x5_2453, 1);
                V v_ru_24x5_2453_24MkPair = heff_take_reuse_n(v_x5_2453, 3ULL, 2);
                V v_t_2456 = heff_tag_at_n(v_ru_24x32_2432_24Cons, TAG_Cons, 2, (V[]){heff_tag_re_n(v_ru_24x3221_2435_24STag, TAG_STag, 3, 5ULL, (V[]){v_t_2449, v_argv_2455, v_ts_2451}), NTAG(TAG_Nil)});
                V v_t_2457 = heff_tag_at_n(v_ru_24x5_2453_24MkPair, TAG_SPrim, 2, (V[]){NTAG(TAG_Reuse), heff_tag_at_n(v_ru_24x322_2434_24Cons, TAG_Cons, 2, (V[]){v_cell_2433, v_t_2456})});
                return ((HeffT2){{v_b_2454, v_t_2457}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x5_2453)}});
              }
            }
            case TAG_Cons: {
              heff_take_n(v_x3222_2436, 0ULL, 2);
              heff_drop(v_ru_240);
              heff_drop_rec(v_n_241, 2);
              heff_drop(v_cell_2433);
              heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
              heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
              heff_drop(v_t_2449);
              heff_drop(v_argv_2450);
              heff_drop(v_ts_2451);
              heff_drop_cell(v_ru_24x3221_2435_24STag, 3);
              return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
            }
            default: return ((HeffT2){{heff_nomatch(v_x3222_2436)}});
            }
          }
          case TAG_SRec: {
            heff_take_n(v_x3221_2435, 0ULL, 2);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          case TAG_SProj: {
            heff_take_n(v_x3221_2435, 0ULL, 4);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          case TAG_SPrim: {
            heff_take_n(v_x3221_2435, 0ULL, 2);
            heff_drop(v_ru_240);
            heff_drop_rec(v_n_241, 2);
            heff_drop(v_cell_2433);
            heff_drop_cell(v_ru_24x32_2432_24Cons, 2);
            heff_drop(v_x3222_2436);
            heff_drop_cell(v_ru_24x322_2434_24Cons, 2);
            return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x3221_2435)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x322_2434)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x32_2432)}});
      }
    }
    default: {
      heff_drop(v_ru_240);
      heff_drop_rec(v_n_241, 2);
      heff_drop(v_x31_2431);
      heff_drop(v_x32_2432);
      return ((HeffT2){{NTAG(TAG_False), v_x3_242}});
    }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseV_24cpr_lam0(V self, V *args) {
  V v_v_2421 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2421));
}
V g_heff_2ecompile_2erefcount_2ereuseV_24cpr_lam1(V self, V *args) {
  V v_v_2452 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2452));
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24dps_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24dps_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24dps_24cpr(V v_ru_240, V v_n_241, V v_x4_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_TSeq: {
    V v_ss_244 = heff_field(v_x4_242, 0);
    V v_t_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TSeq = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_246 = (g_heff_2ecompile_2erefcount_2ereuseSts_24s1779385304x854264108_24cpr(v_ru_240, v_n_241, heff_dup(v_ss_244)));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      V v_it1_249 = v_field_247;
      V v_ss2_2410 = v_field_248;
      if ((heff_dup(v_it1_249) == NTAG(TAG_True))) {
        heff_drop(v_ss_244);
        heff_drop_cell(v_ru_24x4_242_24TSeq, 2);
        heff_drop(v_it1_249);
        V v_u_2411 = heff_setFieldPeek(v_d_243, MK_INT(1LL), heff_tag_n(TAG_TSeq, 2, (V[]){v_ss2_2410, v_t_245}));
        V v_f_2412 = heff_hole();
        return ((HeffT2){{NTAG(TAG_True), v_f_2412}});
      } else {
        heff_drop(v_it1_249);
        heff_drop(v_ss2_2410);
        V v_cell_2413 = heff_tag_re_n(v_ru_24x4_242_24TSeq, TAG_TSeq, 2, 1ULL, (V[]){v_ss_244, heff_hole()});
        V v_u_2414 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2413);
        V t_0 = v_ru_240;
        V t_1 = v_n_241;
        V t_2 = v_t_245;
        V t_3 = v_u_2414;
        v_ru_240 = t_0;
        v_n_241 = t_1;
        v_x4_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  case TAG_TReturn: {
    V v_o_2415 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_2416 = (g_heff_2ecompile_2erefcount_2ereuseOp_24cpr(heff_dup(v_ru_240), heff_dup(v_n_241), v_o_2415));
    {
      V v_field_2417 = v_t_2416.f[0];
      V v_field_2418 = v_t_2416.f[1];
      V v_b_2419 = v_field_2417;
      V v_o2_2420 = v_field_2418;
      V v_u_2421 = heff_setFieldPeek(v_d_243, MK_INT(1LL), heff_tag_n(TAG_TReturn, 1, (V[]){v_o2_2420}));
      V v_f_2422 = heff_hole();
      return ((HeffT2){{v_b_2419, v_f_2422}});
    }
  }
  case TAG_TLoop: {
    V v_vs_2423 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    V v_t_2425 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24dps_24cpr_lam0, 1, 2, (V[]){heff_dup(v_ru_240), heff_dup(v_n_241)}); V a_1 = v_vs_2423; V r_ = (g_heff_2ecompile_2erefcount_2ereuseArgs(a_0, a_1)); heff_drop(v_vs_2423); r_; });
    switch (heff_tag_of(v_t_2425)) {
    case TAG_MkPair: {
      V v_b_2426 = heff_field(v_t_2425, 0);
      V v_vs2_2427 = heff_field(v_t_2425, 1);
      heff_take_n(v_t_2425, 3ULL, 2);
      V v_u_2428 = heff_setFieldPeek(v_d_243, MK_INT(1LL), heff_tag_n(TAG_TLoop, 1, (V[]){v_vs2_2427}));
      V v_f_2429 = heff_hole();
      return ((HeffT2){{v_b_2426, v_f_2429}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2425)}});
    }
  }
  case TAG_TIf: {
    V v_c_2430 = heff_field(v_x4_242, 0);
    V v_t_2431 = heff_field(v_x4_242, 1);
    V v_e_2432 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_2433 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(v_ru_240, v_n_241, v_t_2431));
    {
      V v_field_2434 = v_t_2433.f[0];
      V v_field_2435 = v_t_2433.f[1];
      V v_bt_2436 = v_field_2434;
      V v_t2_2437 = v_field_2435;
      HeffT2 v_t_2438 = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(v_ru_240, v_n_241, v_e_2432));
      {
        V v_field_2439 = v_t_2438.f[0];
        V v_field_2440 = v_t_2438.f[1];
        V v_be_2441 = v_field_2439;
        V v_e2_2442 = v_field_2440;
        V v_u_2443 = heff_setFieldPeek(v_d_243, MK_INT(1LL), heff_tag_n(TAG_TIf, 3, (V[]){v_c_2430, v_t2_2437, v_e2_2442}));
        V v_f_2444 = heff_hole();
        V v_t_2445 = heff_bool(((heff_dup(v_bt_2436) == NTAG(TAG_True)) || (heff_dup(v_be_2441) == NTAG(TAG_True))));
        heff_drop(v_bt_2436);
        heff_drop(v_be_2441);
        return ((HeffT2){{v_t_2445, v_f_2444}});
      }
    }
  }
  case TAG_TCase: {
    V v_v_2446 = heff_field(v_x4_242, 0);
    V v_arms_2447 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TCase = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_ps_2457 = (g_list_2emap_24tok2(v_ru_24x4_242_24TCase, heff_clo_n(g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24dps_24cpr_lam1, 1, 2, (V[]){heff_dup(v_ru_240), heff_dup(v_n_241)}), v_arms_2447));
    V v_b_2458 = (g_list_2eany_24s910662703x1730636603(v_ps_2457));
    V v_as2_2459 = (g_list_2emap_24s1173914895x100384474(v_ps_2457));
    V v_u_2460 = heff_setFieldPeek(v_d_243, MK_INT(1LL), heff_tag_n(TAG_TCase, 2, (V[]){v_v_2446, v_as2_2459}));
    V v_f_2461 = heff_hole();
    return ((HeffT2){{v_b_2458, v_f_2461}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24dps_24cpr_lam0(V self, V *args) {
  V v_v_2424 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erefcount_2ereuseV(v_ru_240, v_n_241, v_v_2424));
}
V g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24dps_24cpr_lam1(V self, V *args) {
  V v_x4_2448 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  switch (heff_tag_of(v_x4_2448)) {
  case TAG_MkArm: {
    V v_t_2449 = heff_field(v_x4_2448, 0);
    V v_vs_2450 = heff_field(v_x4_2448, 1);
    V v_b_2451 = heff_field(v_x4_2448, 2);
    V v_ru_24x4_2448_24MkArm = heff_take_reuse_n(v_x4_2448, 7ULL, 3);
    heff_clo_take(self, 2);
    HeffT2 v_t_2452 = ({ V a_0 = v_ru_240; V a_1 = v_n_241; V a_2 = v_b_2451; HeffT2 r_ = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(a_0, a_1, a_2)); heff_drop(v_ru_240); heff_drop(v_n_241); r_; });
    {
      V v_field_2453 = v_t_2452.f[0];
      V v_field_2454 = v_t_2452.f[1];
      V v_b_2455 = v_field_2453;
      V v_x_2456 = v_field_2454;
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2455, heff_tag_re_n(v_ru_24x4_2448_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2449, v_vs_2450, v_x_2456})});
    }
  }
  default: return heff_nomatch(v_x4_2448);
  }
}

HeffT2 g_heff_2ecompile_2erefcount_2enthValue_24cpr(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_v_242 = heff_field(v_x2_241, 0);
    V v_vs_243 = heff_field(v_x2_241, 1);
    if (heff_intLe_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_242)}});
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_vs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_entry, 9, 0};

V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(V v_ce_240, V v_x_241, V v_fa_242, V v_binding_243, V v_known_244, V v_takes_245, V v_rest_246, V v_after_247, V v_wb_248) {
top: ;
  V v_wanted_249 = (g_prelude_2e_2b_2b(heff_dup(v_fa_242), heff_dup(v_wb_248)));
  V v_xs_2412 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam0, 1, 1, (V[]){v_wanted_249}); V a_1 = heff_dup(heff_rfield(v_ce_240, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2413 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_240), v_xs_2412));
  V v_t_2414 = (g_list_2emap_24s1796125103x644876049(v_t_2413));
  V v_wanted_2415 = (g_prelude_2e_2b_2b(v_fa_242, heff_dup(v_wb_248)));
  V v_t_2417 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam1, 1, 1, (V[]){v_wanted_2415}); V a_1 = heff_dup(heff_rfield(v_ce_240, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2418 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2417, heff_dup(v_wb_248), heff_dup(v_ce_240)));
  V v_t_2419 = (g_heff_2ecompile_2erefcount_2ewithTakes(v_takes_245, v_t_2418));
  V v_t_2420 = heff_tr(heff_call(v_binding_243, 1, (V[]){v_t_2419}));
  V v_t_2421 = (g_heff_2ecompile_2erefcount_2eelemS(v_x_241, v_wb_248));
  V v_t_2438;
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_t_2421);
    v_t_2438 = NTAG(TAG_Nil);
  } else {
    heff_drop(v_t_2421);
    V v_lit_2422 = heff_dup(v_x_241);
    V v_ce_2424;
    switch (heff_tag_of(v_known_244)) {
    case TAG_Nothing: {
      v_ce_2424 = heff_dup(v_ce_240);
      break;
    }
    case TAG_Just: {
      V v_k_2423 = heff_field(v_known_244, 0);
      v_ce_2424 = (g_heff_2ecompile_2erefcount_2ewithKnown(v_x_241, v_k_2423, heff_dup(v_ce_240)));
      break;
    }
    default: heff_nomatch(v_known_244);
    }
    V v_reprs_2425 = heff_take_field(v_ce_2424, 10);
    V v_known_2426 = heff_get_n(v_ce_2424, 8, 17);
    HeffT2 v_t_2427 = ({ V a_0 = v_reprs_2425; V a_1 = v_lit_2422; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_reprs_2425); r_; });
    {
      V v_field_2429 = v_t_2427.f[1];
      int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
      V v_t_2431;
      if ((v_tag_2428 == ((int64_t)0ULL))) {
        heff_drop(v_lit_2422);
        V v_x_2430 = v_field_2429;
        heff_drop(v_x_2430);
        v_t_2431 = NTAG(TAG_Nil);
      } else {
        heff_drop(v_field_2429);
        v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_2422, NTAG(TAG_Nil)});
      }
      V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2431));
      V v_t_2437 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam2, 2, 1, (V[]){v_known_2426}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2432; V r_ = (g_list_2efoldl(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2432); r_; });
      v_t_2438 = (g_list_2emap_24s1796125103x644876049(v_t_2437));
    }
  }
  V v_t_2440 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam3, 1, 1, (V[]){heff_dup(v_wb_248)}); V a_1 = heff_dup(heff_rfield(v_ce_240, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2441 = ({ V a_0 = v_x_241; V a_1 = v_wb_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_wb_248); r_; });
  V v_t_2446;
  if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
    heff_drop(v_t_2441);
    HeffT2 v_t_2442 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_ce_240, 10), v_x_241));
    {
      V v_field_2444 = v_t_2442.f[1];
      int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
      if ((v_tag_2443 == ((int64_t)0ULL))) {
        V v_x_2445 = v_field_2444;
        heff_drop(v_x_2445);
        v_t_2446 = NTAG(TAG_Nil);
      } else {
        heff_drop(v_field_2444);
        v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
      }
    }
  } else {
    heff_drop(v_t_2441);
    v_t_2446 = NTAG(TAG_Nil);
  }
  V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2446));
  V v_t_2449;
  switch (heff_tag_of(v_known_244)) {
  case TAG_Nothing: {
    heff_drop(v_x_241);
    v_t_2449 = heff_dup(v_ce_240);
    break;
  }
  case TAG_Just: {
    V v_k_2448 = heff_field(v_known_244, 0);
    v_t_2449 = ({ V a_0 = v_x_241; V a_1 = v_k_2448; V a_2 = heff_dup(v_ce_240); V r_ = (g_heff_2ecompile_2erefcount_2ewithKnown(a_0, a_1, a_2)); heff_drop(v_x_241); r_; });
    break;
  }
  default: heff_nomatch(v_known_244);
  }
  V v_t_2450 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2449));
  V v_ce_2451 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2447, heff_get_n(v_ce_240, 5, 17), v_t_2450));
  V v_t_2452 = ({ V a_0 = v_ce_2451; V a_1 = v_rest_246; V a_2 = v_after_247; V r_ = (g_heff_2ecompile_2erefcount_2estmtsF_24s294631892x494908187(a_0, a_1, a_2)); heff_drop(v_ce_2451); r_; });
  V v_t_2453 = (g_prelude_2e_2b_2b(v_t_2438, v_t_2452));
  V v_t_2454 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2453));
  return (g_prelude_2e_2b_2b(v_t_2414, v_t_2454));
}
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8]); heff_drop(a4); return r;
}
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam0(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = ({ V a_0 = v_v_2410; V a_1 = v_wanted_249; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2410); heff_drop(v_wanted_249); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam1(V self, V *args) {
  V v_v_2416 = args[0];
  V v_wanted_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2416; V a_1 = v_wanted_2415; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2416); heff_drop(v_wanted_2415); r_; });
}
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam2(V self, V *args) {
  V v_acc_2433 = args[0];
  V v_x_2434 = args[1];
  V v_known_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = ({ V a_0 = v_known_2426; V a_1 = v_x_2434; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_known_2426); r_; });
  V v_t_2436 = (g_heff_2ecompile_2erefcount_2edropOf(v_x_2434, v_t_2435));
  return (g_prelude_2e_2b_2b(v_t_2436, v_acc_2433));
}
V g_heff_2ecompile_2erefcount_2ebindWith_24s1825146207x274971888_lam3(V self, V *args) {
  V v_v_2439 = args[0];
  V v_wb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2439; V a_1 = v_wb_248; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2439); heff_drop(v_wb_248); r_; });
}
Clo g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_entry, 4, 0};

V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(V v_ce_240, V v_x3_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_PTrue: {
    return heff_setField(heff_dup(v_d_242), heff_dup(v_i_243), NTAG(TAG_CondTrue));
  }
  case TAG_PFalse: {
    return heff_setField(heff_dup(v_d_242), heff_dup(v_i_243), NTAG(TAG_CondFalse));
  }
  case TAG_PRel: {
    V v_p_244 = heff_field(v_x3_241, 0);
    V v_a_245 = heff_field(v_x3_241, 1);
    V v_b_246 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    HeffT2 v_t_247 = (g_heff_2ecompile_2erepr_2eprimShape_24cpr(v_p_244));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_sh_2410 = v_field_249;
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_246, NTAG(TAG_Nil)});
        V v_t_2412 = (g_heff_2ecompile_2erefcount_2eoperandsAs_24s1849164943x644313852(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_get_n(v_sh_2410, 0, 2), heff_tag_n(TAG_Cons, 2, (V[]){v_a_245, v_t_2411})));
        return heff_setField(heff_dup(v_d_242), heff_dup(v_i_243), heff_tag_n(TAG_CondRelU, 2, (V[]){v_p_244, v_t_2412}));
      } else {
        heff_drop(v_field_249);
        V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_246, NTAG(TAG_Nil)});
        V v_t_2414 = (g_heff_2ecompile_2erefcount_2eoperandsF_24s530476005x441500338(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_a_245, v_t_2413})));
        return heff_setField(heff_dup(v_d_242), heff_dup(v_i_243), heff_tag_n(TAG_CondRel, 2, (V[]){v_p_244, v_t_2414}));
      }
    }
  }
  case TAG_PBool: {
    V v_v_2415 = heff_field(v_x3_241, 0);
    heff_take_n(v_x3_241, 1ULL, 1);
    V v_t_2416 = (g_heff_2ecompile_2erefcount_2evalAsF_24s1116657410x1521767797(heff_dup(v_ce_240), NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_2415));
    return heff_setField(heff_dup(v_d_242), heff_dup(v_i_243), heff_tag_n(TAG_CondBool, 1, (V[]){v_t_2416}));
  }
  case TAG_PNot: {
    V v_c_2417 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24PNot = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_cell_2418 = heff_tag_at_n(v_ru_24x3_241_24PNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2419 = heff_setFieldPeek(v_d_242, heff_dup(v_i_243), v_cell_2418);
    V t_0 = v_ce_240;
    V t_1 = v_c_2417;
    V t_2 = v_u_2419;
    V t_3 = MK_INT(0LL);
    v_ce_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2420 = heff_field(v_x3_241, 0);
    V v_b_2421 = heff_field(v_x3_241, 1);
    V v_c_2422 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24PIf = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2423 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(heff_dup(v_ce_240), v_a_2420));
    V v_t_2424 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(heff_dup(v_ce_240), v_b_2421));
    V v_cell_2425 = heff_tag_at_n(v_ru_24x3_241_24PIf, TAG_CondIf, 3, (V[]){v_t_2423, v_t_2424, heff_hole()});
    V v_u_2426 = heff_setFieldPeek(v_d_242, heff_dup(v_i_243), v_cell_2425);
    V t_0 = v_ce_240;
    V t_1 = v_c_2422;
    V t_2 = v_u_2426;
    V t_3 = MK_INT(2LL);
    v_ce_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_PLet: {
    V v_x_2427 = heff_field(v_x3_241, 0);
    V v_o_2428 = heff_field(v_x3_241, 1);
    V v_c_2429 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    HeffT2 v_t_2430 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 10), v_x_2427));
    {
      V v_field_2432 = v_t_2430.f[1];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      V v_t_2434;
      if ((v_tag_2431 == ((int64_t)0ULL))) {
        V v_x_2433 = v_field_2432;
        v_t_2434 = v_x_2433;
      } else {
        heff_drop(v_field_2432);
        v_t_2434 = NTAG(TAG_RepV);
      }
      V v_t_2435 = (g_heff_2ecompile_2erefcount_2ecompF_24s512115896x664909630(heff_dup(v_ce_240), NTAG(TAG_Nil), v_t_2434, v_o_2428));
      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2427), heff_dup(heff_rfield(v_ce_240, 6))});
      V v_t_2437 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2436, heff_dup(v_ce_240)));
      V v_t_2438 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2437, v_c_2429));
      HeffT2 v_t_2439 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_ce_240, 10), v_x_2427));
      {
        V v_field_2441 = v_t_2439.f[1];
        int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
        V v_t_2443;
        if ((v_tag_2440 == ((int64_t)0ULL))) {
          V v_x_2442 = v_field_2441;
          heff_drop(v_x_2442);
          v_t_2443 = NTAG(TAG_Nil);
        } else {
          heff_drop(v_field_2441);
          v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2427), NTAG(TAG_Nil)});
        }
        V v_t_2444 = (g_list_2emap_24s1068270568x176847536(v_t_2443));
        return heff_setField(heff_dup(v_d_242), heff_dup(v_i_243), heff_tag_n(TAG_CondLet, 4, (V[]){v_x_2427, v_t_2435, v_t_2438, v_t_2444}));
      }
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438_24dps(a0, a[1], a2, a3); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_lam0(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_lam1(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_lam2(V self, V *args);
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_lam3(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213(V v_lit_240, V v_lit_241, V v_ce_242, V v_c_243, V v_wanted_244) {
top: ;
  V v_xs_247 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_lam0, 1, 1, (V[]){heff_dup(v_wanted_244)}); V a_1 = heff_dup(heff_rfield(v_ce_242, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_248 = (g_heff_2ecompile_2erefcount_2edropsOf(heff_dup(v_ce_242), v_xs_247));
  V v_t_249 = (g_list_2emap_24s1796125103x644876049(v_t_248));
  V v_t_2411 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_lam1, 1, 1, (V[]){heff_dup(v_wanted_244)}); V a_1 = heff_dup(heff_rfield(v_ce_242, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_ce_2412 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2411, heff_dup(v_wanted_244), heff_dup(v_ce_242)));
  V v_t_2413 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_2412, 4)), heff_dup(heff_rfield(v_ce_2412, 6))));
  V v_t_2414 = (g_heff_2ecompile_2erefcount_2ewithBorrowed(v_t_2413, v_ce_2412));
  V v_t_2415 = (g_heff_2ecompile_2erefcount_2ewithTakes(NTAG(TAG_Nil), v_t_2414));
  V v_t_2416 = (g_heff_2ecompile_2erefcount_2econdF_24s1923681190x780681438(v_t_2415, v_c_243));
  V v_t_2418 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_lam2, 1, 1, (V[]){heff_dup(v_wanted_244)}); V a_1 = heff_dup(heff_rfield(v_ce_242, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2419 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2418, heff_dup(heff_rfield(v_ce_242, 5)), heff_dup(v_ce_242)));
  V v_t_2420 = (g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447(v_lit_240, v_t_2419));
  V v_t_2422 = ({ V b_0 = heff_clo_n(g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_lam3, 1, 1, (V[]){v_wanted_244}); V a_1 = heff_dup(heff_rfield(v_ce_242, 4)); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2423 = (g_heff_2ecompile_2erefcount_2ewithPath(v_t_2422, heff_dup(heff_rfield(v_ce_242, 5)), v_ce_242));
  V v_t_2424 = (g_heff_2ecompile_2erefcount_2econdArm_24s937130382x391174447(v_lit_241, v_t_2423));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_t_2416, v_t_2420, v_t_2424}), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_t_249, v_t_2425));
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_lam0(V self, V *args) {
  V v_v_245 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_246 = ({ V a_0 = v_v_245; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_245); heff_drop(v_wanted_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_246) == NTAG(TAG_True)));
  heff_drop(v_x1_246);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_lam1(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2410; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2410); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_lam2(V self, V *args) {
  V v_v_2417 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2417; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2417); heff_drop(v_wanted_244); r_; });
}
V g_heff_2ecompile_2erefcount_2econdTestWith_24s406346707x566856213_lam3(V self, V *args) {
  V v_v_2421 = args[0];
  V v_wanted_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2421; V a_1 = v_wanted_244; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_v_2421); heff_drop(v_wanted_244); r_; });
}

HeffT4 g_heff_2ecompile_2erefcount_2efunPlain_24cpr(V v_ce_240, V v_key_241, V v_xs_242, V v_b_243) {
top: ;
  HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 7), v_key_241));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    V v_t_248;
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      v_t_248 = v_x_247;
    } else {
      heff_drop(v_field_246);
      v_t_248 = NTAG(TAG_Nil);
    }
    HeffT2 v_t_249 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_ce_240, 11), v_key_241));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      V v_t_2413;
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_s_2412 = v_field_2411;
        v_t_2413 = heff_get_n(v_s_2412, 0, 2);
      } else {
        heff_drop(v_field_2411);
        v_t_2413 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_xs_242)));
      }
      V v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932(heff_rfield(v_ce_240, 11), v_key_241));
      return (g_heff_2ecompile_2erefcount_2efunWith_24cpr(v_ce_240, v_key_241, v_xs_242, v_b_243, v_t_248, v_t_2413, v_t_2414));
    }
  }
}
V g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_lam0(V self, V *args);
Clo g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_entry, 2, 0};

V g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531(V v_seen_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_TSeq: {
    V v_ss_242 = heff_field(v_x3_241, 0);
    V v_t_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24TSeq = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2erefcount_2erebuiltSts_24s860872616x1839682545_24cpr(heff_dup(v_seen_240), v_ss_242));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_s2_247 = v_field_245;
      V v_ss2_248 = v_field_246;
      V v_cell_249 = heff_tag_at_n(v_ru_24x3_241_24TSeq, TAG_TSeq, 2, (V[]){v_ss2_248, heff_hole()});
      V v_u_2410 = (g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_24dps(v_s2_247, v_t_243, v_cell_249, MK_INT(1LL)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
  }
  case TAG_TReturn: {
    V v_o_2411 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24TReturn = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_o_2411)) {
    case TAG_OSimple: {
      V v_v_2412 = heff_dup(heff_field(v_o_2411, 0));
      v_t_2420 = ({ V a_0 = v_seen_240; V a_1 = v_v_2412; V r_ = (g_heff_2ecompile_2erefcount_2eshapesOfV(a_0, a_1)); heff_drop(v_v_2412); r_; });
      break;
    }
    case TAG_OCall: {
      V v_args_2414 = heff_dup(heff_field(v_o_2411, 1));
      v_t_2420 = ({ V a_0 = heff_dup(v_seen_240); V a_1 = v_args_2414; V r_ = (g_list_2efoldl_24s1060781110x816201608(a_0, a_1)); heff_drop(v_args_2414); r_; });
      break;
    }
    case TAG_OApply: {
      V v_f_2415 = heff_dup(heff_field(v_o_2411, 0));
      V v_args_2416 = heff_dup(heff_field(v_o_2411, 1));
      v_t_2420 = ({ V a_0 = heff_dup(v_seen_240); V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_2415, v_args_2416}); V r_ = (g_list_2efoldl_24s1060781110x816201608(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    case TAG_OPrim: {
      V v_args_2418 = heff_dup(heff_field(v_o_2411, 1));
      v_t_2420 = ({ V a_0 = heff_dup(v_seen_240); V a_1 = v_args_2418; V r_ = (g_list_2efoldl_24s1060781110x816201608(a_0, a_1)); heff_drop(v_args_2418); r_; });
      break;
    }
    case TAG_OAbandon: {
      v_t_2420 = heff_dup(v_seen_240);
      break;
    }
    case TAG_OBool: {
      v_t_2420 = heff_dup(v_seen_240);
      break;
    }
    default: heff_nomatch(v_o_2411);
    }
    HeffT2 v_t_2421 = (g_heff_2ecompile_2erefcount_2erebuiltOp_24s510905267x500217447_24cpr(v_t_2420, v_o_2411));
    {
      V v_field_2422 = v_t_2421.f[0];
      V v_field_2423 = v_t_2421.f[1];
      V v_x_2424 = v_field_2422;
      heff_drop(v_x_2424);
      V v_y_2425 = v_field_2423;
      V v_t_2426 = v_y_2425;
      return heff_tag_at_n(v_ru_24x3_241_24TReturn, TAG_TReturn, 1, (V[]){v_t_2426});
    }
  }
  case TAG_TLoop: {
    V v_vs_2427 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24TLoop = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    HeffT2 v_t_2428 = (g_heff_2ecompile_2erefcount_2erebuiltVs_24s1306915676x1772197351_24cpr(heff_dup(v_seen_240), v_vs_2427));
    {
      V v_field_2429 = v_t_2428.f[0];
      V v_field_2430 = v_t_2428.f[1];
      V v_x_2431 = v_field_2429;
      heff_drop(v_x_2431);
      V v_y_2432 = v_field_2430;
      V v_t_2433 = v_y_2432;
      return heff_tag_at_n(v_ru_24x3_241_24TLoop, TAG_TLoop, 1, (V[]){v_t_2433});
    }
  }
  case TAG_TIf: {
    V v_c_2434 = heff_field(v_x3_241, 0);
    V v_t_2435 = heff_field(v_x3_241, 1);
    V v_e_2436 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24TIf = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2437 = (g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531(v_seen_240, v_t_2435));
    V v_cell_2438 = heff_tag_re_n(v_ru_24x3_241_24TIf, TAG_TIf, 3, 1ULL, (V[]){v_c_2434, v_t_2437, heff_hole()});
    V v_u_2439 = (g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_24dps(heff_dup(v_seen_240), v_e_2436, v_cell_2438, MK_INT(2LL)));
    heff_drop(v_u_2439);
    return v_cell_2438;
  }
  case TAG_TCase: {
    V v_v_2440 = heff_field(v_x3_241, 0);
    V v_arms_2441 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24TCase = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2447 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_lam0, 1, 1, (V[]){heff_dup(v_seen_240)}), v_arms_2441));
    return heff_tag_re_n(v_ru_24x3_241_24TCase, TAG_TCase, 2, 1ULL, (V[]){v_v_2440, v_t_2447});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531_lam0(V self, V *args) {
  V v_a_2442 = args[0];
  V v_seen_240 = heff_env(self)[0];
  switch (heff_tag_of(v_a_2442)) {
  case TAG_MkArm: {
    V v_t_2443 = heff_field(v_a_2442, 0);
    V v_vs_2444 = heff_field(v_a_2442, 1);
    V v_b_2445 = heff_field(v_a_2442, 2);
    V v_ru_24a_2442_24MkArm = heff_take_reuse_n(v_a_2442, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_t_2446 = ({ V a_0 = v_seen_240; V a_1 = v_b_2445; V r_ = (g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531(a_0, a_1)); heff_drop(v_seen_240); r_; });
    return heff_tag_re_n(v_ru_24a_2442_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2443, v_vs_2444, v_t_2446});
  }
  default: return heff_nomatch(v_a_2442);
  }
}
HEFF_LIT(g_heff_2ecompile_2erefcount_2ercDef_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2erefcount_2ercDef_24cpr_str1, 0, "");

HeffT4 g_heff_2ecompile_2erefcount_2ercDef_24cpr(V v_facts_240, V v_reprs_241, V v_x3_242) {
top: ;
  V v_arity_243 = heff_take_field(v_facts_240, 0);
  V v_bounce_244 = heff_take_field(v_facts_240, 1);
  V v_lent_245 = heff_take_field(v_facts_240, 3);
  V v_workers_246 = heff_take_field(v_facts_240, 4);
  V v_flat_247 = heff_take_field(v_facts_240, 5);
  V v_sure_248 = heff_take_field(v_facts_240, 6);
  V v_sureRecs_249 = heff_take_field(v_facts_240, 7);
  V v_tokens_2410 = heff_get_n(v_facts_240, 10, 11);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkDef: {
    V v_key_2411 = heff_field(v_x3_242, 0);
    V v_x33_2413 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24MkDef = heff_take_reuse_n(v_x3_242, 5ULL, 3);
    switch (heff_tag_of(v_x33_2413)) {
    case TAG_DefFun: {
      V v_xs_2414 = heff_field(v_x33_2413, 0);
      V v_x332_2415 = heff_field(v_x33_2413, 1);
      V v_ru_24x33_2413_24DefFun = heff_take_reuse_n(v_x33_2413, 3ULL, 2);
      switch (heff_tag_of(v_x332_2415)) {
      case TAG_MkBlock: {
        V v_t_2416 = heff_field(v_x332_2415, 0);
        heff_take_n(v_x332_2415, 1ULL, 1);
        V v_ce_2417 = heff_rec_n(17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, (V[]){v_arity_243, v_bounce_244, NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), v_lent_245, heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), v_reprs_241, v_workers_246, v_flat_247, v_sure_248, v_sureRecs_249, v_tokens_2410, NTAG(TAG_RepV)});
        V v_b_2418 = (g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531(NTAG(TAG_Nil), v_t_2416));
        V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_ce_2417, 15)), 1, 2);
        HeffT2 v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = v_key_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2419); r_; });
        {
          V v_field_2422 = v_t_2420.f[1];
          int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
          if ((v_tag_2421 == ((int64_t)0ULL))) {
            V v_n_2423 = v_field_2422;
            V v_ce_2424 = v_ce_2417;
            V v_key_2425 = v_key_2411;
            V v_x3_2426 = v_xs_2414;
            V v_b_2427 = v_b_2418;
            V v_n_2428 = v_n_2423;
            switch (heff_tag_of(v_x3_2426)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24x3_242_24MkDef, 3);
              heff_drop_cell(v_ru_24x33_2413_24DefFun, 2);
              heff_drop(v_n_2428);
              return (g_heff_2ecompile_2erefcount_2efunPlain_24cpr(v_ce_2424, v_key_2425, NTAG(TAG_Nil), v_b_2427));
            }
            case TAG_Cons: {
              V v_tok_2429 = heff_field(v_x3_2426, 0);
              V v_xs_2430 = heff_field(v_x3_2426, 1);
              heff_take_n(v_x3_2426, 3ULL, 2);
              V v_t_2431 = heff_tag_at_n(v_ru_24x3_242_24MkDef, TAG_KnownCell, 3, (V[]){heff_dup(v_n_2428), ((V)&g_heff_2ecompile_2erefcount_2ercDef_24cpr_str0), NTAG(TAG_Nil)});
              V v_t_2432 = ({ V a_0 = v_tok_2429; V a_1 = v_t_2431; V a_2 = v_ce_2424; V r_ = (g_heff_2ecompile_2erefcount_2ewithKnown(a_0, a_1, a_2)); heff_drop_tag(v_t_2431, 3); r_; });
              HeffT2 v_t_2433 = ({ V a_0 = v_tok_2429; V b_1 = heff_rec_n(2, shape_n__tag, (V[]){v_n_2428, ((V)&g_heff_2ecompile_2erefcount_2ercDef_24cpr_str1)}); V a_2 = v_b_2427; HeffT2 r_ = (g_heff_2ecompile_2erefcount_2ereuseTl_24s275645384x918375938_24cpr(a_0, b_1, a_2)); heff_drop(b_1); r_; });
              {
                V v_field_2434 = v_t_2433.f[0];
                V v_field_2435 = v_t_2433.f[1];
                V v_x_2436 = v_field_2434;
                heff_drop(v_x_2436);
                V v_y_2437 = v_field_2435;
                V v_t_2438 = v_y_2437;
                return (g_heff_2ecompile_2erefcount_2efunPlain_24cpr(v_t_2432, v_key_2425, heff_tag_at_n(v_ru_24x33_2413_24DefFun, TAG_Cons, 2, (V[]){v_tok_2429, v_xs_2430}), v_t_2438));
              }
            }
            default: return ((HeffT4){{heff_nomatch(v_x3_2426)}});
            }
          } else {
            heff_drop_cell(v_ru_24x3_242_24MkDef, 3);
            heff_drop_cell(v_ru_24x33_2413_24DefFun, 2);
            heff_drop(v_field_2422);
            return (g_heff_2ecompile_2erefcount_2efunPlain_24cpr(v_ce_2417, v_key_2411, v_xs_2414, v_b_2418));
          }
        }
      }
      default: return ((HeffT4){{heff_nomatch(v_x332_2415)}});
      }
    }
    case TAG_DefVal: {
      V v_x331_2439 = heff_field(v_x33_2413, 0);
      heff_take_n(v_x33_2413, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24MkDef, 3);
      switch (heff_tag_of(v_x331_2439)) {
      case TAG_MkBlock: {
        V v_t_2440 = heff_field(v_x331_2439, 0);
        heff_take_n(v_x331_2439, 1ULL, 1);
        V v_ce_2441 = heff_rec_n(17, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__flat__sure__sureRecs__tokens__ret, (V[]){v_arity_243, v_bounce_244, NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), v_lent_245, heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nil), v_reprs_241, v_workers_246, v_flat_247, v_sure_248, v_sureRecs_249, v_tokens_2410, NTAG(TAG_RepV)});
        V v_key_2442 = v_key_2411;
        V v_t_2443 = (g_heff_2ecompile_2erefcount_2erebuiltTl_24s1317589160x929854531(NTAG(TAG_Nil), v_t_2440));
        V v_t_2444 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_t_2443, NTAG(TAG_Nil)));
        V v_t_2445 = (g_list_2efoldl_24s976906006x1321876394(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2444));
        V v_t_2446 = ({ V a_0 = heff_dup(v_ce_2441); V a_1 = v_t_2445; V r_ = (g_list_2efoldl_24s1548442597x958354846(a_0, a_1)); heff_drop(v_t_2445); r_; });
        V v_t_2447 = (g_heff_2ecompile_2erefcount_2ewithFrame(NTAG(TAG_Nothing), MK_INT(0LL), v_t_2446));
        V v_ce_2448 = (g_heff_2ecompile_2erefcount_2ewithPath(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2447));
        V v_t_2449 = ({ V a_0 = v_ce_2448; V a_1 = v_t_2443; V r_ = (g_heff_2ecompile_2erefcount_2etailF_24s1025912369x1365276565(a_0, a_1)); heff_drop(v_ce_2448); r_; });
        V v_f_2450 = heff_get_n(v_ce_2441, 10, 17);
        return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), v_key_2442, v_t_2449, v_f_2450}});
      }
      default: return ((HeffT4){{heff_nomatch(v_x331_2439)}});
      }
    }
    default: return ((HeffT4){{heff_nomatch(v_x33_2413)}});
    }
  }
  default: return ((HeffT4){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_entry, 5, 0};

V g_heff_2ecompile_2erefcount_2epeekArgs_24tok1(V v_tok_240, V v_ce_241, V v_x_242, V v_argv_243, V v_rest_244) {
top: ;
  V v_borrowed_245 = heff_take_field(v_ce_241, 6);
  V v_reprs_246 = heff_take_field(v_ce_241, 10);
  V v_self_247 = heff_get_n(v_ce_241, 2, 17);
  switch (heff_tag_of(v_argv_243)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_x_242);
    heff_drop(v_rest_244);
    heff_drop(v_borrowed_245);
    heff_drop(v_reprs_246);
    heff_drop(v_self_247);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_argv1_248 = heff_field(v_argv_243, 0);
    V v_argv2_249 = heff_field(v_argv_243, 1);
    V v_ru_24argv_243_24Cons = heff_take_reuse_n(v_argv_243, 3ULL, 2);
    switch (heff_tag_of(v_argv1_248)) {
    case TAG_SVar: {
      V v_a_2410 = heff_field(v_argv1_248, 0);
      heff_take_n(v_argv1_248, 1ULL, 1);
      switch (heff_tag_of(v_argv2_249)) {
      case TAG_Nil: {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_x_242);
        heff_drop(v_rest_244);
        heff_drop(v_borrowed_245);
        heff_drop(v_reprs_246);
        heff_drop(v_self_247);
        heff_drop_cell(v_ru_24argv_243_24Cons, 2);
        heff_drop(v_a_2410);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_i_2411 = heff_field(v_argv2_249, 0);
        V v_argv22_2412 = heff_field(v_argv2_249, 1);
        heff_take_n(v_argv2_249, 3ULL, 2);
        switch (heff_tag_of(v_argv22_2412)) {
        case TAG_Nil: {
          V v_t_2413 = ({ V a_0 = v_a_2410; V a_1 = v_borrowed_245; V r_ = (g_heff_2ecompile_2erefcount_2eelemS(a_0, a_1)); heff_drop(v_borrowed_245); r_; });
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_t_2413);
            HeffT2 v_t_2414 = ({ V a_0 = v_reprs_246; V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_reprs_246); r_; });
            {
              V v_field_2416 = v_t_2414.f[1];
              int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
              if ((v_tag_2415 == ((int64_t)0ULL))) {
                V v_x_2417 = v_field_2416;
                switch (heff_tag_of(v_x_2417)) {
                case TAG_RepV: {
                  V v_t_2418 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erefcount_2enotFlatAt_clo), 2, (V[]){v_self_247, v_x_242}));
                  V v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2erefcount_2eanyW(a_0, a_1)); heff_drop(v_t_2418); r_; });
                  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
                    heff_drop(v_t_2419);
                    return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24argv_243_24Cons, TAG_MkPair, 2, (V[]){v_a_2410, v_i_2411})});
                  } else {
                    heff_drop_cell(v_tok_240, 1);
                    heff_drop_cell(v_ru_24argv_243_24Cons, 2);
                    heff_drop(v_a_2410);
                    heff_drop(v_i_2411);
                    heff_drop(v_t_2419);
                    return NTAG(TAG_Nothing);
                  }
                }
                case TAG_RepFix: {
                  heff_take_n(v_x_2417, 0ULL, 1);
                  heff_drop_cell(v_tok_240, 1);
                  heff_drop(v_x_242);
                  heff_drop(v_rest_244);
                  heff_drop(v_self_247);
                  heff_drop_cell(v_ru_24argv_243_24Cons, 2);
                  heff_drop(v_a_2410);
                  heff_drop(v_i_2411);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepF64: {
                  heff_drop_cell(v_tok_240, 1);
                  heff_drop(v_x_242);
                  heff_drop(v_rest_244);
                  heff_drop(v_self_247);
                  heff_drop_cell(v_ru_24argv_243_24Cons, 2);
                  heff_drop(v_a_2410);
                  heff_drop(v_i_2411);
                  return NTAG(TAG_Nothing);
                }
                case TAG_RepInt: {
                  heff_drop_cell(v_tok_240, 1);
                  heff_drop(v_x_242);
                  heff_drop(v_rest_244);
                  heff_drop(v_self_247);
                  heff_drop_cell(v_ru_24argv_243_24Cons, 2);
                  heff_drop(v_a_2410);
                  heff_drop(v_i_2411);
                  return NTAG(TAG_Nothing);
                }
                default: return heff_nomatch(v_x_2417);
                }
              } else {
                heff_drop(v_field_2416);
                V v_t_2421 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erefcount_2enotFlatAt_clo), 2, (V[]){v_self_247, v_x_242}));
                V v_t_2422 = ({ V a_0 = v_t_2421; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2erefcount_2eanyW(a_0, a_1)); heff_drop(v_t_2421); r_; });
                if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
                  heff_drop(v_t_2422);
                  return heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24argv_243_24Cons, TAG_MkPair, 2, (V[]){v_a_2410, v_i_2411})});
                } else {
                  heff_drop_cell(v_tok_240, 1);
                  heff_drop_cell(v_ru_24argv_243_24Cons, 2);
                  heff_drop(v_a_2410);
                  heff_drop(v_i_2411);
                  heff_drop(v_t_2422);
                  return NTAG(TAG_Nothing);
                }
              }
            }
          } else {
            heff_drop_cell(v_tok_240, 1);
            heff_drop(v_x_242);
            heff_drop(v_rest_244);
            heff_drop(v_reprs_246);
            heff_drop(v_self_247);
            heff_drop_cell(v_ru_24argv_243_24Cons, 2);
            heff_drop(v_a_2410);
            heff_drop(v_i_2411);
            heff_drop(v_t_2413);
            return NTAG(TAG_Nothing);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_argv22_2412, 0ULL, 2);
          heff_drop_cell(v_tok_240, 1);
          heff_drop(v_x_242);
          heff_drop(v_rest_244);
          heff_drop(v_borrowed_245);
          heff_drop(v_reprs_246);
          heff_drop(v_self_247);
          heff_drop_cell(v_ru_24argv_243_24Cons, 2);
          heff_drop(v_a_2410);
          heff_drop(v_i_2411);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_argv22_2412);
        }
      }
      default: return heff_nomatch(v_argv2_249);
      }
    }
    case TAG_SGlobal: {
      heff_take_n(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SInt: {
      heff_take_n(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      heff_take_na(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      heff_take_n(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      heff_take_n(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      heff_take_n(v_argv1_248, 0ULL, 2);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      heff_take_na(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_argv1_248, 0ULL, 1);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_argv1_248, 0ULL, 2);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_argv1_248, 0ULL, 3);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_argv1_248, 0ULL, 2);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_argv1_248, 0ULL, 4);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_argv1_248, 0ULL, 2);
      heff_drop_cell(v_tok_240, 1);
      heff_drop(v_x_242);
      heff_drop(v_rest_244);
      heff_drop(v_borrowed_245);
      heff_drop(v_reprs_246);
      heff_drop(v_self_247);
      heff_drop(v_argv2_249);
      heff_drop_cell(v_ru_24argv_243_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_argv1_248);
    }
  }
  default: return heff_nomatch(v_argv_243);
  }
}
V g_heff_2ecompile_2erefcount_2epeekArgs_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erefcount_2epeekArgs_24tok1(a[0], a[1], a[2], a[3], a[4]);
}