// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_BDelayedBy 11524
#define TAG_BInserted 42142
#define TAG_Become 65038
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CUndelay 45232
#define TAG_De 8978
#define TAG_Delay 58579
#define TAG_Delayed2 38439
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LChunkSnoc 25233
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_LikeRecord 38505
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkEvidenceSearch 8362
#define TAG_MkField 62648
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotInScope 14443
#define TAG_Put 28059
#define TAG_Record 39342
#define TAG_RestoreDelayed 1107
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_evidence 1128105991
#define LBL_globals 352931696
#define LBL_hidden 729654485
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_matched 1072719718
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
#define LBL_written 1834876765
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_len__names__locals__ctx__matched[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx, LBL_matched};
static uint32_t shape_scope__globals__elabFor__lams__self__insts__named__evidence[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts, LBL_named, LBL_evidence};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
HeffT2 g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2eprimInt_get(void);
V g_heff_2eelab_2ememoed_2eproj(V, V);
V g_heff_2eelab_2ememoed_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eproj_clo;
V g_heff_2eelab_2ememoed_2eprojAt(V, V, V);
V g_heff_2eelab_2ememoed_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eprojAt_clo;
V g_heff_2eelab_2emeta_2eattempt(V, V, V);
V g_heff_2eelab_2emeta_2eattempt_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eattempt_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2emeta_2eliftU_24tok1(V, V, V, V);
V g_heff_2eelab_2emeta_2eliftU_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_24tok1_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
V g_heff_2eelab_2erules_2eboundGo_24dps(V, V, V, V);
V g_heff_2eelab_2erules_2eboundGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eboundGo_24dps_clo;
V g_heff_2eelab_2erules_2echeckFields(V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckFields_clo;
HeffT2 g_heff_2eelab_2erules_2ecomputationWorld_24cpr(V, V);
V g_heff_2eelab_2erules_2edefaultAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edefaultAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultAt_clo;
V g_heff_2eelab_2erules_2edelayChkBy(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkBy_clo;
V g_heff_2eelab_2erules_2eeachSubgoal(V, V, V, V);
V g_heff_2eelab_2erules_2eeachSubgoal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeachSubgoal_clo;
V g_heff_2eelab_2erules_2eelimGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimGo_clo;
V g_heff_2eelab_2erules_2eelimWaits(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eelimWaits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eelimWaits_clo;
V g_heff_2eelab_2erules_2eerrorOf_24rec0_get(void);
V g_heff_2eelab_2erules_2eevidenceSearch_get(void);
V g_heff_2eelab_2erules_2eevidenceSearchF(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceSearchF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceSearchF_clo;
HeffT2 g_heff_2eelab_2erules_2efieldTyLate_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2efieldsNote(V);
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldsNote_clo;
V g_heff_2eelab_2erules_2eformGo(V, V, V);
V g_heff_2eelab_2erules_2eformGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformGo_clo;
V g_heff_2eelab_2erules_2eformRecord(V, V);
V g_heff_2eelab_2erules_2eformRecord_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformRecord_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2ekeepRecovered(V, V, V, V, V);
V g_heff_2eelab_2erules_2ekeepRecovered_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ekeepRecovered_clo;
V g_heff_2eelab_2erules_2eleftOver(V, V, V, V, V);
V g_heff_2eelab_2erules_2eleftOver_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eleftOver_clo;
V g_heff_2eelab_2erules_2eletted_24generate0(V, V, V);
V g_heff_2eelab_2erules_2eletted_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_24generate0_clo;
V g_heff_2eelab_2erules_2eletted_24map0(V, V);
V g_heff_2eelab_2erules_2eletted_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_24map0_clo;
V g_heff_2eelab_2erules_2elocalDef(V, V, V, V);
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elocalDef_clo;
HeffT3 g_heff_2eelab_2erules_2ementionsLocal_24cpr(V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo;
V g_heff_2eelab_2erules_2enamedFrom(V, V, V);
V g_heff_2eelab_2erules_2enamedFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedFrom_clo;
V g_heff_2eelab_2erules_2enamesFor_24dps(V, V);
V g_heff_2eelab_2erules_2enamesFor_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamesFor_24dps_clo;
V g_heff_2eelab_2erules_2enoneNamed(V, V, V);
V g_heff_2eelab_2erules_2enoneNamed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enoneNamed_clo;
V g_heff_2eelab_2erules_2eprimInt_get(void);
V g_heff_2eelab_2erules_2erebottom(V, V);
V g_heff_2eelab_2erules_2erebottom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erebottom_clo;
V g_heff_2eelab_2erules_2erecordElim(V, V, V);
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordElim_clo;
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2erecordSpec(V, V, V, V);
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordSpec_clo;
HeffT1 g_heff_2eelab_2erules_2erecovering_24cpr(V);
HeffT2 g_heff_2eelab_2erules_2esealedOf_24cpr(V, V);
V g_heff_2eelab_2erules_2especializedGo(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especializedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especializedGo_clo;
V g_heff_2eelab_2erules_2esumFormation_24generate0(V, V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24generate0_clo;
V g_heff_2eelab_2erules_2esumFormation_24generate2(V, V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24generate2_clo;
V g_heff_2eelab_2erules_2esumFormation_24map2(V, V);
V g_heff_2eelab_2erules_2esumFormation_24map2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24map2_clo;
V g_heff_2eelab_2erules_2esumFormation_24map3(V, V);
V g_heff_2eelab_2erules_2esumFormation_24map3_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24map3_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrIn(V, V, V);
V g_heff_2eelab_2erules_2etyStrIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrIn_clo;
V g_heff_2eelab_2erules_2eunsolvedWorldTm(V, V, V);
V g_heff_2eelab_2erules_2eunsolvedWorldTm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eunsolvedWorldTm_clo;
HeffT3 g_heff_2eelab_2erules_2evarGo_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
HeffT2 g_heff_2eelab_2eunify_2ezonker_24cpr(V);
V g_heff_2eelab_2evalue_2eapp_24s848338757x263511075(V);
V g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_24s848338757x263511075_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2edecodeNeuOf(V, V, V, V, V);
V g_heff_2eelab_2evalue_2edecodeNeuOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeNeuOf_clo;
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
HeffT2 g_heff_2eelab_2evalue_2eprojTyWith_24cpr(V, V, V);
V g_heff_2eelab_2evalue_2especialize(V, V, V);
V g_heff_2eelab_2evalue_2especialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_clo;
V g_heff_2eelab_2evalue_2especialize_24tok3(V, V, V, V);
V g_heff_2eelab_2evalue_2especialize_24tok3_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2especialize_24tok3_clo;
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany_24s1946659387x922023683(V, V);
V g_list_2eany_24s1946659387x922023683_entry(V self, V *a);
extern Clo g_list_2eany_24s1946659387x922023683_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f603879485x1484249893(V, V, V, V);
V g_list_2efoldl_24f603879485x1484249893_entry(V self, V *a);
extern Clo g_list_2efoldl_24f603879485x1484249893_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
HeffT2 g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2eelab_2erules_2enamesFor_24dps_str0, 1, "x");
Clo g_heff_2eelab_2erules_2enamesFor_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamesFor_24dps_entry, 2, 0};

V g_heff_2eelab_2erules_2enamesFor_24dps(V v_n_240, V v_d_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_242 = heff_intShow(heff_intSub_lent(v_n_240, MK_INT(1LL), 2));
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2eelab_2erules_2enamesFor_24dps_str0), v_t_242), heff_hole()});
    V v_u_244 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_243);
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_u_244;
    v_n_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2erules_2enamesFor_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2enamesFor_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ekeepRecovered_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2ekeepRecovered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ekeepRecovered_entry, 5, 0};

V g_heff_2eelab_2erules_2ekeepRecovered(V v_kept_240, V v_saved_241, V v_waiting_242, V v_hd_243, V v_k_244) {
top: ;
  V v_malg_245 = heff_take_field(v_hd_243, 2);
  V v_bind_246 = heff_get_n(v_hd_243, 1, 3);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam0, 1, 1, (V[]){v_kept_240})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(v_bind_246), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam1, 1, 5, (V[]){v_malg_245, v_bind_246, v_saved_241, v_waiting_242, v_k_244})});
}
V g_heff_2eelab_2erules_2ekeepRecovered_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ekeepRecovered(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam0(V self, V *args) {
  V v_c_247 = args[0];
  V v_kept_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_kept_240, heff_take_field(v_c_247, 1)});
  return ({ V rv_1 = v_t_248; V rr_ = heff_rec_reuse_nf(v_c_247, 509ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam3(V self, V *args) {
  V v_c_2417 = args[0];
  V v_saved_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_5 = heff_get_n(v_saved_241, 5, 9); V rr_ = heff_rec_reuse_nf(v_c_2417, 479ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 259071u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_waiting_242 = heff_env(self)[0];
  V v_malg_245 = heff_env(self)[1];
  V v_bind_246 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_drop(v_x_2425);
  heff_clo_take(self, 4);
  V v_t_2426 = heff_tag_n(TAG_RestoreDelayed, 2, (V[]){v_waiting_242, NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_2427}));
  V f_ = v_bind_246;
  heff_room[0] = v_t_2428;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_malg_245 = heff_env(self)[0];
  V v_bind_246 = heff_env(self)[1];
  V v_waiting_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_t_2422 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2421, NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(v_bind_246);
  heff_room[0] = v_t_2424;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam5, 1, 4, (V[]){v_waiting_242, v_malg_245, v_bind_246, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_saved_241 = heff_env(self)[0];
  V v_malg_245 = heff_env(self)[1];
  V v_bind_246 = heff_env(self)[2];
  V v_waiting_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_drop(v_x_2416);
  heff_clo_take(self, 5);
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam3, 1, 1, (V[]){v_saved_241})})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_2419}));
  V f_ = heff_dup(v_bind_246);
  heff_room[0] = v_t_2420;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam4, 1, 4, (V[]){v_malg_245, v_bind_246, v_waiting_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ekeepRecovered_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_malg_245 = heff_env(self)[0];
  V v_bind_246 = heff_env(self)[1];
  V v_saved_241 = heff_env(self)[2];
  V v_waiting_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_t_2413 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2412, NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})}));
  heff_clo_take(self, 5);
  V f_ = heff_dup(v_bind_246);
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ekeepRecovered_lam2, 1, 5, (V[]){v_saved_241, v_malg_245, v_bind_246, v_waiting_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eunsolvedWorldTm_str0, 6, "co.<+>");
Clo g_heff_2eelab_2erules_2eunsolvedWorldTm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eunsolvedWorldTm_entry, 3, 0};

V g_heff_2eelab_2erules_2eunsolvedWorldTm(V v_mc_240, V v_box_24depth_241, V v_x3_242) {
  int64_t v_depth_241 = heff_unbox_word(v_box_24depth_241);
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SLocal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    V v_x31_246 = heff_field(v_x3_242, 0);
    V v_b_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_SLocal: {
      heff_take_n(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SGlobal: {
      heff_take_n(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SCode: {
      heff_take_n(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SApp: {
      V v_x311_2411 = heff_field(v_x31_246, 0);
      V v_a_2412 = heff_field(v_x31_246, 1);
      heff_take_n(v_x31_246, 3ULL, 2);
      switch (heff_tag_of(v_x311_2411)) {
      case TAG_SLocal: {
        heff_take_n(v_x311_2411, 0ULL, 1);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SGlobal: {
        V v_k_2414 = heff_field(v_x311_2411, 0);
        heff_take_n(v_x311_2411, 1ULL, 1);
        if (heff_strEq_c(v_k_2414, ((V)&g_heff_2eelab_2erules_2eunsolvedWorldTm_str0))) {
          V v_t_2415 = (g_heff_2eelab_2erules_2eunsolvedWorldTm(v_mc_240, heff_box_word(v_depth_241), v_a_2412));
          if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
            heff_drop(v_b_247);
            heff_drop(v_t_2415);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_2415);
            V t_0 = v_mc_240;
            int64_t t_1 = v_depth_241;
            V t_2 = v_b_247;
            v_mc_240 = t_0;
            v_depth_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          }
        } else {
          heff_drop(v_b_247);
          heff_drop(v_a_2412);
          return NTAG(TAG_False);
        }
      }
      case TAG_SCode: {
        heff_take_n(v_x311_2411, 0ULL, 1);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SApp: {
        heff_take_n(v_x311_2411, 0ULL, 2);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SLam: {
        heff_take_n(v_x311_2411, 0ULL, 2);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SCons: {
        heff_take_n(v_x311_2411, 0ULL, 1);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SProj: {
        heff_take_n(v_x311_2411, 0ULL, 2);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_STag: {
        heff_take_n(v_x311_2411, 0ULL, 2);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SMatch: {
        heff_take_n(v_x311_2411, 0ULL, 2);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_x311_2411, 0ULL, 3);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SIs: {
        heff_take_n(v_x311_2411, 0ULL, 1);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SOpaque: {
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SAbandon: {
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SRec: {
        heff_take_n(v_x311_2411, 0ULL, 1);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SFix: {
        heff_take_n(v_x311_2411, 0ULL, 2);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SImplicit: {
        heff_take_n(v_x311_2411, 0ULL, 2);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SPrim: {
        heff_take_n(v_x311_2411, 0ULL, 1);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_x311_2411, 0ULL, 3);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SLitInt: {
        heff_take_n(v_x311_2411, 0ULL, 1);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SLitFloat: {
        heff_take_na(v_x311_2411, 0ULL, 1);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SLitString: {
        heff_take_n(v_x311_2411, 0ULL, 1);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SLitBytes: {
        heff_take_n(v_x311_2411, 0ULL, 1);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SLitRune: {
        heff_take_n(v_x311_2411, 0ULL, 1);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_x311_2411, 0ULL, 2);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_SLitFloat32: {
        heff_take_na(v_x311_2411, 0ULL, 1);
        heff_drop(v_b_247);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x311_2411);
      }
    }
    case TAG_SLam: {
      heff_take_n(v_x31_246, 0ULL, 2);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SCons: {
      heff_take_n(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      heff_take_n(v_x31_246, 0ULL, 2);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      heff_take_n(v_x31_246, 0ULL, 2);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SMatch: {
      heff_take_n(v_x31_246, 0ULL, 2);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_x31_246, 0ULL, 3);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SIs: {
      heff_take_n(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SOpaque: {
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      heff_take_n(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SFix: {
      heff_take_n(v_x31_246, 0ULL, 2);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SImplicit: {
      heff_take_n(v_x31_246, 0ULL, 2);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      heff_take_n(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_x31_246, 0ULL, 3);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SLitInt: {
      heff_take_n(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      heff_take_n(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SLitRune: {
      heff_take_n(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_x31_246, 0ULL, 2);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_x31_246, 0ULL, 1);
      heff_drop(v_b_247);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  case TAG_SLam: {
    V v_x32_2480 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 2ULL, 2);
    switch (heff_tag_of(v_x32_2480)) {
    case TAG_MkAbs: {
      V v_body_2482 = heff_field(v_x32_2480, 1);
      heff_take_n(v_x32_2480, 2ULL, 2);
      V t_0 = v_mc_240;
      int64_t t_1 = v_depth_241;
      V t_2 = v_body_2482;
      v_mc_240 = t_0;
      v_depth_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_AbsConst: {
      heff_take_n(v_x32_2480, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x32_2480);
    }
  }
  case TAG_SCons: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    heff_take_n(v_x3_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    heff_take_n(v_x3_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    heff_take_n(v_x3_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x3_242, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    V v_t_2494 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V t_0 = v_mc_240;
    int64_t t_1 = v_depth_241;
    V t_2 = v_t_2494;
    v_mc_240 = t_0;
    v_depth_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    heff_take_n(v_x3_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    V v_k_24101 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 3);
    HeffT2 v_t_24104 = ({ V a_0 = v_mc_240; V a_1 = v_k_24101; HeffT2 r_ = (g_std_2eordmap_2elookup_24s1088265102x456727156_24cpr(a_0, a_1)); heff_drop(v_k_24101); r_; });
    {
      V v_field_24106 = v_t_24104.f[1];
      int64_t v_tag_24105 = ((int64_t)v_t_24104.f[0]);
      if ((v_tag_24105 == ((int64_t)0ULL))) {
        V v_entry_24107 = v_field_24106;
        V v_t_24108 = heff_get_n(v_entry_24107, 2, 6);
        switch (heff_tag_of(v_t_24108)) {
        case TAG_Nothing: {
          return NTAG(TAG_True);
        }
        case TAG_Just: {
          V v_s_24109 = heff_field(v_t_24108, 0);
          heff_take_n(v_t_24108, 1ULL, 1);
          if ((((int64_t)0ULL) < v_depth_241)) {
            V t_0 = v_mc_240;
            int64_t t_1 = (v_depth_241 - ((int64_t)1ULL));
            V t_2 = v_s_24109;
            v_mc_240 = t_0;
            v_depth_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          } else {
            heff_drop(v_s_24109);
            return NTAG(TAG_False);
          }
        }
        default: return heff_nomatch(v_t_24108);
        }
      } else {
        heff_drop(v_field_24106);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_SLitInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x3_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x3_242, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x3_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eunsolvedWorldTm_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eunsolvedWorldTm(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2eeachSubgoal_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeachSubgoal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeachSubgoal_entry, 4, 0};

V g_heff_2eelab_2erules_2eeachSubgoal(V v_find_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_find_240);
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_sg_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_find_240), 1, (V[]){heff_dup(v_sg_244)}));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2eelab_2erules_2eeachSubgoal_lam0, 1, 4, (V[]){v_find_240, heff_dup(v_rest_245), v_z_242, v_z_243})});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eeachSubgoal_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eeachSubgoal(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eeachSubgoal_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_find_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_drop(v_x_247);
  heff_clo_take(self, 4);
  return ({ V a_0 = v_find_240; V a_1 = v_rest_245; V a_2 = v_z_242; V a_3 = v_z_243; V r_ = (g_heff_2eelab_2erules_2eeachSubgoal(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}
HEFF_LIT(g_heff_2eelab_2erules_2enoneNamed_str0, 2, "`(");
HEFF_LIT(g_heff_2eelab_2erules_2enoneNamed_str1, 28, " := ...)` is out of order: `");
HEFF_LIT(g_heff_2eelab_2erules_2enoneNamed_str2, 49, "` comes before an explicit argument given already");
HEFF_LIT(g_heff_2eelab_2erules_2enoneNamed_str3, 2, "`(");
HEFF_LIT(g_heff_2eelab_2erules_2enoneNamed_str4, 28, " := ...)` is out of order: `");
HEFF_LIT(g_heff_2eelab_2erules_2enoneNamed_str5, 16, "` comes before `");
HEFF_LIT(g_heff_2eelab_2erules_2enoneNamed_str6, 61, "`, and named arguments go in the order of the function's type");
HEFF_LIT(g_heff_2eelab_2erules_2enoneNamed_str7, 2, "`(");
HEFF_LIT(g_heff_2eelab_2erules_2enoneNamed_str8, 53, " := ...)` names an argument, but there is none named ");
HEFF_LIT(g_heff_2eelab_2erules_2enoneNamed_str9, 5, " here");
Clo g_heff_2eelab_2erules_2enoneNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enoneNamed_entry, 3, 0};

V g_heff_2eelab_2erules_2enoneNamed(V v_x_240, V v_after_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SApp: {
    V v_g_243 = heff_field(v_t_242, 0);
    V v_a_244 = heff_field(v_t_242, 1);
    V v_t_245 = heff_dup(v_a_244);
    V v_t_2441;
    switch (heff_tag_of(v_t_245)) {
    case TAG_SLocal: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SGlobal: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SCode: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SApp: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SCons: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SMatch: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SSpecialize: {
      heff_take_n(v_t_245, 0ULL, 3);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SIs: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SOpaque: {
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SAbandon: {
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFix: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SImplicit: {
      V v_y_2427 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 2);
      v_t_2441 = heff_tag_n(TAG_Just, 1, (V[]){v_y_2427});
      break;
    }
    case TAG_SPrim: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SMetaApp: {
      heff_take_n(v_t_245, 0ULL, 3);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitInt: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFloat: {
      heff_take_na(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitString: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitBytes: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitRune: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFixed: {
      heff_take_n(v_t_245, 0ULL, 2);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_t_245, 0ULL, 1);
      v_t_2441 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    switch (heff_tag_of(v_t_2441)) {
    case TAG_Nothing: {
      heff_drop(v_after_241);
      V v_t_2442 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2enoneNamed_str0), heff_dup(v_x_240)), ((V)&g_heff_2eelab_2erules_2enoneNamed_str1));
      V v_t_2443 = heff_strAppend(heff_strAppend(v_t_2442, heff_dup(v_x_240)), ((V)&g_heff_2eelab_2erules_2enoneNamed_str2));
      V t_0 = v_x_240;
      V t_1 = v_t_2443;
      V t_2 = v_g_243;
      v_x_240 = t_0;
      v_after_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      V v_y_2444 = heff_field(v_t_2441, 0);
      heff_take_n(v_t_2441, 1ULL, 1);
      if (heff_strEq_c_lent(v_x_240, v_y_2444, 0)) {
        heff_drop(v_y_2444);
        return v_after_241;
      } else {
        heff_drop(v_after_241);
        V v_t_2445 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2enoneNamed_str3), heff_dup(v_x_240)), ((V)&g_heff_2eelab_2erules_2enoneNamed_str4));
        V v_t_2446 = heff_strAppend(heff_strAppend(v_t_2445, heff_dup(v_x_240)), ((V)&g_heff_2eelab_2erules_2enoneNamed_str5));
        V v_t_2447 = heff_strAppend(heff_strAppend(v_t_2446, v_y_2444), ((V)&g_heff_2eelab_2erules_2enoneNamed_str6));
        V t_0 = v_x_240;
        V t_1 = v_t_2447;
        V t_2 = v_g_243;
        v_x_240 = t_0;
        v_after_241 = t_1;
        v_t_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_t_2441);
    }
  }
  default: {
    heff_drop(v_after_241);
    V v_t_2448 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2enoneNamed_str7), heff_dup(v_x_240)), ((V)&g_heff_2eelab_2erules_2enoneNamed_str8));
    return heff_strAppend(heff_strAppend(v_t_2448, heff_dup(v_x_240)), ((V)&g_heff_2eelab_2erules_2enoneNamed_str9));
  }
  }
}
V g_heff_2eelab_2erules_2enoneNamed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2enoneNamed(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2especializedGo_lam0(V self, V *args);
V g_heff_2eelab_2erules_2especializedGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2especializedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2especializedGo_entry, 12, 0};

V g_heff_2eelab_2erules_2especializedGo(V v_e_240, V v_v_241, V v_a_27_242, V v_h_243, V v_sp_244, V v_u_245, V v_described_246, V v_el_247, V v_fields_248, V v_err_249, V v_p_2410, V v_p_2411) {
top: ;
  switch (heff_tag_of(v_sp_244)) {
  case TAG_SpId: {
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    heff_drop(v_p_2410);
    return heff_tail(v_p_2411, 1, (V[]){v_err_249});
  }
  case TAG_SpApp: {
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    heff_drop(v_p_2410);
    return heff_tail(v_p_2411, 1, (V[]){v_err_249});
  }
  case TAG_SpProj: {
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_v_241);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_fields_248);
    heff_drop(v_p_2410);
    return heff_tail(v_p_2411, 1, (V[]){v_err_249});
  }
  case TAG_SpSpec: {
    V v_sq_2416 = heff_field(v_sp_244, 0);
    V v_x_2417 = heff_field(v_sp_244, 1);
    V v_f_2418 = heff_field(v_sp_244, 2);
    V v_g_2419 = heff_dup(heff_rfield(v_e_240, 1));
    V v_c_2420 = heff_dup(heff_rfield(v_e_240, 0));
    V v_len_2421 = heff_take_field(v_c_2420, 0);
    V v_names_2422 = heff_get_n(v_c_2420, 1, 5);
    return (g_heff_2eelab_2emeta_2eattempt(heff_clo_n(g_heff_2eelab_2erules_2especializedGo_lam0, 2, 9, (V[]){v_g_2419, v_len_2421, v_names_2422, heff_dup(v_h_243), heff_dup(v_sq_2416), heff_dup(v_u_245), heff_dup(v_described_246), heff_dup(v_el_247), heff_dup(v_a_27_242)}), heff_dup(v_p_2410), heff_clo_n(g_heff_2eelab_2erules_2especializedGo_lam1, 1, 14, (V[]){heff_dup(v_x_2417), heff_dup(v_f_2418), v_fields_248, v_e_240, v_v_241, v_a_27_242, v_h_243, heff_dup(v_sq_2416), v_u_245, v_described_246, v_el_247, v_err_249, v_p_2410, v_p_2411})));
  }
  default: return heff_nomatch(v_sp_244);
  }
}
V g_heff_2eelab_2erules_2especializedGo_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2especializedGo(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8], a[9], a[10], a[11]); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2especializedGo_lam0(V self, V *args) {
  V v_p_2423 = args[0];
  V v_p_2424 = args[1];
  V v_g_2419 = heff_env(self)[0];
  V v_len_2421 = heff_env(self)[1];
  V v_names_2422 = heff_env(self)[2];
  V v_h_243 = heff_env(self)[3];
  V v_sq_2416 = heff_env(self)[4];
  V v_u_245 = heff_env(self)[5];
  V v_described_246 = heff_env(self)[6];
  V v_el_247 = heff_env(self)[7];
  V v_a_27_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo), 4, (V[]){v_g_2419, heff_rec_n(2, shape_len__names, (V[]){v_len_2421, v_names_2422}), heff_tag_n(TAG_VDecode, 5, (V[]){v_h_243, v_sq_2416, v_u_245, v_described_246, v_el_247}), v_a_27_242}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2425, v_p_2423, v_p_2424));
}
V g_heff_2eelab_2erules_2especializedGo_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_f_2418 = heff_env(self)[1];
  V v_fields_248 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  V v_a_27_242 = heff_env(self)[5];
  V v_h_243 = heff_env(self)[6];
  V v_sq_2416 = heff_env(self)[7];
  V v_u_245 = heff_env(self)[8];
  V v_described_246 = heff_env(self)[9];
  V v_el_247 = heff_env(self)[10];
  V v_err_249 = heff_env(self)[11];
  V v_p_2410 = heff_env(self)[12];
  V v_p_2411 = heff_env(self)[13];
  switch (heff_tag_of(v_x_2426)) {
  case TAG_Left: {
    heff_take_n(v_x_2426, 0ULL, 1);
    heff_clo_take(self, 14);
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_f_2418}), v_fields_248});
    return ({ V a_0 = v_e_240; V a_1 = v_v_241; V a_2 = v_a_27_242; V a_3 = v_h_243; V a_4 = v_sq_2416; V a_5 = v_u_245; V a_6 = v_described_246; V a_7 = v_el_247; V a_8 = v_t_2428; V a_9 = v_err_249; V a_10 = v_p_2410; V a_11 = v_p_2411; V r_ = (g_heff_2eelab_2erules_2especializedGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_sq_2416); r_; });
  }
  case TAG_Right: {
    heff_take_n(v_x_2426, 0ULL, 1);
    heff_clo_take(self, 14);
    heff_drop(v_a_27_242);
    heff_drop(v_h_243);
    heff_drop(v_sq_2416);
    heff_drop(v_u_245);
    heff_drop(v_described_246);
    heff_drop(v_el_247);
    heff_drop(v_err_249);
    V v_t_2430 = heff_tr(heff_call(v_v_241, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_f_2418}), v_fields_248});
    return ({ V a_0 = v_e_240; V a_1 = v_t_2430; V a_2 = v_t_2431; V a_3 = v_p_2410; V a_4 = v_p_2411; V r_ = (g_heff_2eelab_2erules_2echeckFields(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2430); heff_drop_tag(v_t_2431, 2); r_; });
  }
  default: return heff_nomatch(v_x_2426);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2ecomputationWorld_24cpr_str0, 10, "co.Handler");

HeffT2 g_heff_2eelab_2erules_2ecomputationWorld_24cpr(V v_mc_240, V v_t_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, v_t_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_VU: {
    heff_take_n(v_t_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VDecode: {
    heff_take_n(v_t_242, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFunction: {
    V v_dom_2410 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 2ULL, 6);
    V v_it_2415 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, v_dom_2410));
    switch (heff_tag_of(v_it_2415)) {
    case TAG_VU: {
      heff_take_n(v_it_2415, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VDecode: {
      V v_it1_2417 = heff_field(v_it_2415, 0);
      V v_it2_2418 = heff_field(v_it_2415, 1);
      heff_take_n(v_it_2415, 3ULL, 5);
      switch (heff_tag_of(v_it1_2417)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2417, 0ULL, 1);
        heff_drop(v_it2_2418);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HGlobal: {
        V v_k_2423 = heff_field(v_it1_2417, 0);
        heff_take_n(v_it1_2417, 1ULL, 1);
        switch (heff_tag_of(v_it2_2418)) {
        case TAG_SpId: {
          heff_drop(v_k_2423);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpApp: {
          V v_it21_2424 = heff_field(v_it2_2418, 0);
          V v_h_2425 = heff_field(v_it2_2418, 1);
          heff_take_n(v_it2_2418, 3ULL, 2);
          switch (heff_tag_of(v_it21_2424)) {
          case TAG_SpId: {
            if (heff_strEq_c(v_k_2423, ((V)&g_heff_2eelab_2erules_2ecomputationWorld_24cpr_str0))) {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_h_2425}});
            } else {
              heff_drop(v_h_2425);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          case TAG_SpApp: {
            heff_take_n(v_it21_2424, 0ULL, 2);
            heff_drop(v_k_2423);
            heff_drop(v_h_2425);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SpProj: {
            heff_take_n(v_it21_2424, 0ULL, 2);
            heff_drop(v_k_2423);
            heff_drop(v_h_2425);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SpSpec: {
            heff_take_n(v_it21_2424, 0ULL, 3);
            heff_drop(v_k_2423);
            heff_drop(v_h_2425);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it21_2424)}});
          }
        }
        case TAG_SpProj: {
          heff_take_n(v_it2_2418, 0ULL, 2);
          heff_drop(v_k_2423);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SpSpec: {
          heff_take_n(v_it2_2418, 0ULL, 3);
          heff_drop(v_k_2423);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_it2_2418)}});
        }
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2417, 0ULL, 1);
        heff_drop(v_it2_2418);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HError: {
        heff_drop(v_it2_2418);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2417)}});
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_it_2415, 0ULL, 6);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VRecord: {
      heff_take_n(v_it_2415, 0ULL, 4);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VSum: {
      heff_take_n(v_it_2415, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VPrimInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VPrimFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VPrimString: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VPrimRune: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VPrimArray: {
      heff_take_n(v_it_2415, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VFixed: {
      heff_take_n(v_it_2415, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_it_2415)}});
    }
  }
  case TAG_VRecord: {
    heff_take_n(v_t_242, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VSum: {
    heff_take_n(v_t_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimArray: {
    heff_take_n(v_t_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFixed: {
    heff_take_n(v_t_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_242)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eelimWaits_str0, 11, "application");
HEFF_LIT(g_heff_2eelab_2erules_2eelimWaits_str1, 11, "application");
V g_heff_2eelab_2erules_2eelimWaits_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eelimWaits_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eelimWaits_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2eelimWaits_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimWaits_lam4, 1, 0};
V g_heff_2eelab_2erules_2eelimWaits_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2eelimWaits_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimWaits_lam5, 1, 0};
V g_heff_2eelab_2erules_2eelimWaits_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eelimWaits_lam8(V self, V *args); static Clo g_heff_2eelab_2erules_2eelimWaits_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimWaits_lam8, 1, 0};
V g_heff_2eelab_2erules_2eelimWaits_lam9(V self, V *args); static Clo g_heff_2eelab_2erules_2eelimWaits_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimWaits_lam9, 1, 0};
V g_heff_2eelab_2erules_2eelimWaits_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eelimWaits_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eelimWaits_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eelimWaits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eelimWaits_entry, 8, 0};

V g_heff_2eelab_2erules_2eelimWaits(V v_checksOnly_240, V v_lambda_241, V v_sp_242, V v_arg_243, V v_e_244, V v_pi_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_pi_245)) {
  case TAG_MkPair: {
    V v_ecallee_248 = heff_dup(heff_field(v_pi_245, 0));
    V v_a_249 = heff_dup(heff_field(v_pi_245, 1));
    V v_t_2432;
    switch (heff_tag_of(v_a_249)) {
    case TAG_VU: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2411 = heff_dup(heff_field(v_a_249, 0));
      switch (heff_tag_of(v_t1_2411)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2411, 0ULL, 1);
        v_t_2432 = NTAG(TAG_True);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2411, 0ULL, 1);
        v_t_2432 = NTAG(TAG_True);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2411, 0ULL, 1);
        v_t_2432 = NTAG(TAG_False);
        break;
      }
      case TAG_HError: {
        v_t_2432 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_t1_2411);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_VRecord: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_VSum: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimString: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_VFixed: {
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_a_249);
    }
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_ecallee_248);
      heff_drop(v_a_249);
      heff_drop(v_t_2432);
      HEFF_LAST return g_heff_2eelab_2erules_2eelimGo(v_checksOnly_240, v_lambda_241, v_sp_242, v_arg_243, v_e_244, v_pi_245, v_z_246, v_z_247);
    } else {
      heff_drop(v_t_2432);
      return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_249), heff_dup(v_z_246), heff_clo_n(g_heff_2eelab_2erules_2eelimWaits_lam0, 1, 10, (V[]){heff_dup(v_checksOnly_240), heff_dup(v_lambda_241), v_sp_242, v_arg_243, v_e_244, v_pi_245, v_z_246, v_z_247, v_a_249, v_ecallee_248})));
    }
  }
  default: return heff_nomatch(v_pi_245);
  }
}
V g_heff_2eelab_2erules_2eelimWaits_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2eelimWaits(a0, a1, a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eelimWaits_lam3(V self, V *args) {
  V v_x_2460 = args[0];
  V v_checksOnly_240 = heff_env(self)[0];
  V v_lambda_241 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_arg_243 = heff_env(self)[3];
  V v_e2_2457 = heff_env(self)[4];
  V v_hd_2458 = heff_env(self)[5];
  V v_k_2459 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_checksOnly_240; V a_1 = v_lambda_241; V a_2 = v_sp_242; V a_3 = v_arg_243; V a_4 = v_e2_2457; V a_5 = v_x_2460; V a_6 = v_hd_2458; V a_7 = v_k_2459; V r_ = (g_heff_2eelab_2erules_2eelimGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_checksOnly_240); heff_drop(v_lambda_241); r_; });
}
V g_heff_2eelab_2erules_2eelimWaits_lam2(V self, V *args) {
  V v_e2_2457 = args[0];
  V v_hd_2458 = args[1];
  V v_k_2459 = args[2];
  V v_sp_242 = heff_env(self)[0];
  V v_ecallee_248 = heff_env(self)[1];
  V v_a_249 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_lambda_241 = heff_env(self)[4];
  V v_arg_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e2_2457), heff_dup(v_sp_242), v_ecallee_248, v_a_249, heff_dup(v_hd_2458), heff_clo_n(g_heff_2eelab_2erules_2eelimWaits_lam3, 1, 7, (V[]){v_checksOnly_240, v_lambda_241, v_sp_242, v_arg_243, v_e2_2457, v_hd_2458, v_k_2459})));
}
V g_heff_2eelab_2erules_2eelimWaits_lam4(V self, V *args) {
  V v_x_2472 = args[0];
  heff_drop(v_x_2472);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2eelimWaits_lam5(V self, V *args) {
  V v_x_2473 = args[0];
  heff_drop(v_x_2473);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2eelimWaits_lam6(V self, V *args) {
  V v_chk_2475 = args[0];
  V v_hd_2476 = args[1];
  V v_k2_2477 = args[2];
  V v_a_249 = heff_env(self)[0];
  V v_t_2478 = heff_tr(heff_call(v_chk_2475, 2, (V[]){heff_dup(v_hd_2476), heff_dup(heff_rfield(v_hd_2476, 0))}));
  heff_clo_take(self, 1);
  V v_t_2479 = heff_tag_n(TAG_Delay, 3, (V[]){v_a_249, v_t_2478, NTAG(TAG_MkUnit)});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tr(heff_call(heff_take_field(v_hd_2476, 2), 1, (V[]){v_t_2480}));
  V f_ = heff_get_n(v_hd_2476, 1, 3);
  args[0] = v_t_2481;
  args[1] = v_k2_2477;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eelimWaits_lam8(V self, V *args) {
  V v_x_2493 = args[0];
  heff_drop(v_x_2493);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2eelimWaits_lam9(V self, V *args) {
  V v_x_2494 = args[0];
  heff_drop(v_x_2494);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2eelimWaits_lam7(V self, V *args) {
  V v_x_2482 = args[0];
  V v_x_2456 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2483 = heff_get_n(v_x_2456, 1, 2);
  V v_t_2495;
  switch (heff_tag_of(v_t_2483)) {
  case TAG_VNeu: {
    V v_h_2484 = heff_field(v_t_2483, 0);
    V v_sp_2485 = heff_field(v_t_2483, 1);
    V v_ty_2486 = heff_field(v_t_2483, 2);
    V v_expansion_2487 = heff_field(v_t_2483, 3);
    V v_desc_2488 = heff_field(v_t_2483, 4);
    V v_ru_24t_2483_24VNeu = heff_take_reuse_n(v_t_2483, 31ULL, 5);
    v_t_2495 = (g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(v_ru_24t_2483_24VNeu, v_h_2484, v_sp_2485, v_ty_2486, v_expansion_2487, v_desc_2488));
    break;
  }
  case TAG_VCode: {
    V v_a_2489 = heff_field(v_t_2483, 0);
    heff_take_n(v_t_2483, 1ULL, 1);
    v_t_2495 = v_a_2489;
    break;
  }
  case TAG_VLam: {
    heff_take_n(v_t_2483, 0ULL, 2);
    v_t_2495 = heff_abandon();
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_t_2483, 0ULL, 1);
    v_t_2495 = heff_abandon();
    break;
  }
  case TAG_VOpaque: {
    v_t_2495 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2eelimWaits_lam8_clo), ((V)&g_heff_2eelab_2erules_2eelimWaits_lam9_clo)});
    break;
  }
  default: heff_nomatch(v_t_2483);
  }
  V v_x_2496 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2482, v_t_2495});
  V f_ = v_z_247;
  args[0] = v_x_2496;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eelimWaits_lam1(V self, V *args) {
  V v_x_2456 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_ecallee_248 = heff_env(self)[1];
  V v_a_249 = heff_env(self)[2];
  V v_checksOnly_240 = heff_env(self)[3];
  V v_lambda_241 = heff_env(self)[4];
  V v_arg_243 = heff_env(self)[5];
  V v_e_244 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  V v_z_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2461 = ({ V a_0 = heff_dup(v_sp_242); V b_1 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eelimWaits_lam2, 3, 6, (V[]){heff_dup(v_sp_242), v_ecallee_248, heff_dup(v_a_249), v_checksOnly_240, v_lambda_241, v_arg_243})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2462 = heff_dup(heff_rfield(v_x_2456, 1));
  V v_ty_2474;
  switch (heff_tag_of(v_t_2462)) {
  case TAG_VNeu: {
    V v_h_2463 = heff_field(v_t_2462, 0);
    V v_sp_2464 = heff_field(v_t_2462, 1);
    V v_ty_2465 = heff_field(v_t_2462, 2);
    V v_expansion_2466 = heff_field(v_t_2462, 3);
    V v_desc_2467 = heff_field(v_t_2462, 4);
    V v_ru_24t_2462_24VNeu = heff_take_reuse_n(v_t_2462, 31ULL, 5);
    v_ty_2474 = (g_heff_2eelab_2evalue_2edecodeNeuOf_24tok5(v_ru_24t_2462_24VNeu, v_h_2463, v_sp_2464, v_ty_2465, v_expansion_2466, v_desc_2467));
    break;
  }
  case TAG_VCode: {
    V v_a_2468 = heff_field(v_t_2462, 0);
    heff_take_n(v_t_2462, 1ULL, 1);
    v_ty_2474 = v_a_2468;
    break;
  }
  case TAG_VLam: {
    heff_take_n(v_t_2462, 0ULL, 2);
    v_ty_2474 = heff_abandon();
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_t_2462, 0ULL, 1);
    v_ty_2474 = heff_abandon();
    break;
  }
  case TAG_VOpaque: {
    v_ty_2474 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2eelimWaits_lam4_clo), ((V)&g_heff_2eelab_2erules_2eelimWaits_lam5_clo)});
    break;
  }
  default: heff_nomatch(v_t_2462);
  }
  return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2eelimWaits_lam6, 3, 1, (V[]){v_a_249}); V a_1 = v_e_244; V a_2 = v_sp_242; V a_3 = ((V)&g_heff_2eelab_2erules_2eelimWaits_str1); V a_4 = v_c_2461; V a_5 = v_ty_2474; V a_6 = v_z_246; V a_7 = heff_clo_n(g_heff_2eelab_2erules_2eelimWaits_lam7, 1, 2, (V[]){v_x_2456, v_z_247}); V r_ = (g_heff_2eelab_2erules_2edelayChkBy(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2461); r_; });
}
V g_heff_2eelab_2erules_2eelimWaits_lam0(V self, V *args) {
  V v_x_2433 = args[0];
  V v_checksOnly_240 = heff_env(self)[0];
  V v_lambda_241 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_arg_243 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_pi_245 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  V v_z_247 = heff_env(self)[7];
  V v_a_249 = heff_env(self)[8];
  V v_ecallee_248 = heff_env(self)[9];
  if ((heff_dup(v_x_2433) == NTAG(TAG_True))) {
    heff_drop(v_x_2433);
    heff_clo_take(self, 10);
    heff_drop(v_a_249);
    heff_drop(v_ecallee_248);
    return ({ V a_0 = v_checksOnly_240; V a_1 = v_lambda_241; V a_2 = v_sp_242; V a_3 = v_arg_243; V a_4 = v_e_244; V a_5 = v_pi_245; V a_6 = v_z_246; V a_7 = v_z_247; V r_ = (g_heff_2eelab_2erules_2eelimGo(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_checksOnly_240); heff_drop(v_lambda_241); r_; });
  } else {
    heff_drop(v_x_2433);
    heff_clo_take(self, 10);
    heff_drop_tag(v_pi_245, 2);
    V v_t_2453;
    switch (heff_tag_of(v_a_249)) {
    case TAG_VU: {
      v_t_2453 = NTAG(TAG_SmallU);
      break;
    }
    case TAG_VDecode: {
      V v_u_2437 = heff_dup(heff_field(v_a_249, 2));
      v_t_2453 = v_u_2437;
      break;
    }
    case TAG_VFunction: {
      v_t_2453 = NTAG(TAG_SmallU);
      break;
    }
    case TAG_VRecord: {
      v_t_2453 = NTAG(TAG_SmallU);
      break;
    }
    case TAG_VSum: {
      v_t_2453 = NTAG(TAG_SmallU);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2453 = NTAG(TAG_SmallU);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2453 = NTAG(TAG_SmallU);
      break;
    }
    case TAG_VPrimString: {
      v_t_2453 = NTAG(TAG_SmallU);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2453 = NTAG(TAG_SmallU);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2453 = NTAG(TAG_SmallU);
      break;
    }
    case TAG_VFixed: {
      v_t_2453 = NTAG(TAG_SmallU);
      break;
    }
    default: heff_nomatch(v_a_249);
    }
    V v_t_2454 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 5);
    V v_t_2455 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 5);
    return ({ V a_0 = v_t_2454; V a_1 = v_t_2455; V a_2 = heff_tag_n(TAG_VU, 1, (V[]){v_t_2453}); V a_3 = ((V)&g_heff_2eelab_2erules_2eelimWaits_str0); V a_4 = heff_dup(v_sp_242); V a_5 = heff_dup(v_z_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2eelimWaits_lam1, 1, 9, (V[]){v_sp_242, v_ecallee_248, v_a_249, v_checksOnly_240, v_lambda_241, v_arg_243, v_e_244, v_z_246, v_z_247}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2455); r_; });
  }
}
V g_heff_2eelab_2erules_2evarGo_24cpr_lam0(V self, V *args);

HeffT3 g_heff_2eelab_2erules_2evarGo_24cpr(V v_x_240, V v_names_241, V v_x3_242, V v_locals_243, V v_n_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_CEmpty: {
    heff_drop(v_n_244);
    heff_drop(v_i_245);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_NotInScope), MK_INT(0LL)}});
  }
  case TAG_CBind: {
    V v_c_27_246 = heff_field(v_x3_242, 0);
    V v_x32_247 = heff_field(v_x3_242, 1);
    V v_a_248 = heff_field(v_x3_242, 2);
    switch (heff_tag_of(v_x32_247)) {
    case TAG_BDelayedBy: {
      V v_k_249 = heff_field(v_x32_247, 0);
      switch (heff_tag_of(v_names_241)) {
      case TAG_Nil: {
        heff_drop(v_n_244);
        heff_drop(v_i_245);
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_NotInScope), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_x_27_2410 = heff_field(v_names_241, 0);
        V v_xs_2411 = heff_field(v_names_241, 1);
        switch (heff_tag_of(v_locals_243)) {
        case TAG_LNil: {
          heff_drop(v_n_244);
          heff_drop(v_i_245);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_NotInScope), MK_INT(0LL)}});
        }
        case TAG_LSnoc: {
          V v_vs_2412 = heff_field(v_locals_243, 0);
          V v_v_2413 = heff_field(v_locals_243, 1);
          if (heff_strEq_c_lent(v_x_240, v_x_27_2410, 0)) {
            if (heff_intLe_c_lent(v_k_249, v_n_244, 2)) {
              V v_t_2416 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLocal, 1, (V[]){v_i_245}), heff_clo_n(g_heff_2eelab_2erules_2evarGo_24cpr_lam0, 1, 1, (V[]){heff_dup(v_v_2413)})});
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_t_2416, heff_dup(v_a_248)}});
            } else {
              heff_drop(v_i_245);
              return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Delayed2), MK_INT(0LL)}});
            }
          } else {
            V t_0 = v_x_240;
            V t_1 = v_xs_2411;
            V t_2 = v_c_27_246;
            V t_3 = v_vs_2412;
            V t_4 = v_n_244;
            V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
            v_x_240 = t_0;
            v_names_241 = t_1;
            v_x3_242 = t_2;
            v_locals_243 = t_3;
            v_n_244 = t_4;
            v_i_245 = t_5;
            goto top;
          }
        }
        case TAG_LChunkSnoc: {
          heff_drop(v_n_244);
          heff_drop(v_i_245);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_NotInScope), MK_INT(0LL)}});
        }
        default: return ((HeffT3){{heff_nomatch(v_locals_243)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_names_241)}});
      }
    }
    case TAG_BInserted: {
      switch (heff_tag_of(v_names_241)) {
      case TAG_Nil: {
        heff_drop(v_n_244);
        heff_drop(v_i_245);
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_NotInScope), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_xs_2420 = heff_field(v_names_241, 1);
        switch (heff_tag_of(v_locals_243)) {
        case TAG_LNil: {
          heff_drop(v_n_244);
          heff_drop(v_i_245);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_NotInScope), MK_INT(0LL)}});
        }
        case TAG_LSnoc: {
          V v_vs_2421 = heff_field(v_locals_243, 0);
          V t_0 = v_x_240;
          V t_1 = v_xs_2420;
          V t_2 = v_c_27_246;
          V t_3 = v_vs_2421;
          V t_4 = v_n_244;
          V t_5 = heff_intAdd(v_i_245, MK_INT(1LL));
          v_x_240 = t_0;
          v_names_241 = t_1;
          v_x3_242 = t_2;
          v_locals_243 = t_3;
          v_n_244 = t_4;
          v_i_245 = t_5;
          goto top;
        }
        case TAG_LChunkSnoc: {
          heff_drop(v_n_244);
          heff_drop(v_i_245);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_NotInScope), MK_INT(0LL)}});
        }
        default: return ((HeffT3){{heff_nomatch(v_locals_243)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_names_241)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x32_247)}});
    }
  }
  case TAG_CUndelay: {
    V v_c_27_2425 = heff_field(v_x3_242, 0);
    V t_0 = v_x_240;
    V t_1 = v_names_241;
    V t_2 = v_c_27_2425;
    V t_3 = v_locals_243;
    V t_4 = heff_intAdd(v_n_244, MK_INT(1LL));
    V t_5 = v_i_245;
    v_x_240 = t_0;
    v_names_241 = t_1;
    v_x3_242 = t_2;
    v_locals_243 = t_3;
    v_n_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2eelab_2erules_2evarGo_24cpr_lam0(V self, V *args) {
  V v_u_2414 = args[0];
  V v_v_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tr(heff_call(v_v_2413, 1, (V[]){v_u_2414}));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2415});
}
V g_heff_2eelab_2erules_2eprimInt_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimInt_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimInt_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimInt_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimInt_st;
static V g_heff_2eelab_2erules_2eprimInt_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimInt_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimInt_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimInt_st)) return g_heff_2eelab_2erules_2eprimInt_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimInt_val, &g_heff_2eelab_2erules_2eprimInt_st, g_heff_2eelab_2erules_2eprimInt_init);
}
V g_heff_2eelab_2erules_2eprimInt_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimInt_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2edefaultAt_str0, 87, "a field's default names the fields before it and definitions, not the type's parameters");
V g_heff_2eelab_2erules_2edefaultAt_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2edefaultAt_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultAt_lam3, 1, 0};
V g_heff_2eelab_2erules_2edefaultAt_lam4(V self, V *args);
V g_heff_2eelab_2erules_2edefaultAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edefaultAt_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edefaultAt_lam0(V self, V *args);
V g_heff_2eelab_2erules_2edefaultAt_lam5(V self, V *args);
Clo g_heff_2eelab_2erules_2edefaultAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultAt_entry, 6, 0};

V g_heff_2eelab_2erules_2edefaultAt(V v_e_240, V v_i_241, V v_ty_242, V v_x4_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_i_241);
    heff_drop_rec(v_ty_242, 2);
    heff_drop(v_z_244);
    return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_Nothing)});
  }
  case TAG_Just: {
    V v_d_246 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_span_247 = heff_take_field(v_d_246, 1);
    V v_chk_248 = heff_get_n(v_d_246, 0, 2);
    V v_x1_249 = heff_tr(heff_call(heff_get_n(v_ty_242, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_a_2413;
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nom: {
      V v_x_2410 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 1);
      v_a_2413 = v_x_2410;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_249, 0ULL, 1);
      v_a_2413 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2412 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 1);
      v_a_2413 = v_x_2412;
      break;
    }
    default: heff_nomatch(v_x1_249);
    }
    V v_sp_2414 = v_span_247;
    V v_i_2415 = v_i_241;
    V v_c_2416 = v_chk_248;
    HeffT1 v_t_2439 = ({ V b_0 = heff_tag_at_n(v_ru_24x4_243_24Just, TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2edefaultAt_lam0, 2, 3, (V[]){v_c_2416, v_i_2415, v_sp_2414})}); HeffT1 r_ = (g_heff_2eelab_2erules_2erecovering_24cpr(b_0)); heff_drop(b_0); r_; });
    {
      V v_field_2440 = v_t_2439.f[0];
      V v_f_2441 = v_field_2440;
      V v_c_2442 = heff_tr(heff_call(v_f_2441, 2, (V[]){v_e_240, v_a_2413}));
      return heff_tail(v_c_2442, 2, (V[]){v_z_244, heff_clo_n(g_heff_2eelab_2erules_2edefaultAt_lam5, 1, 1, (V[]){v_z_245})});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2edefaultAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edefaultAt(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2edefaultAt_lam3(V self, V *args) {
  V v_c0_2424 = args[0];
  return heff_get_n(v_c0_2424, 3, 9);
}
V g_heff_2eelab_2erules_2edefaultAt_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_i_2415 = heff_env(self)[1];
  V v_sp_2414 = heff_env(self)[2];
  V v_hd_2421 = heff_env(self)[3];
  V v_k_2422 = heff_env(self)[4];
  HeffT2 v_t_2429 = ({ V a_0 = v_x_2428; HeffT2 r_ = (g_heff_2eelab_2eunify_2ezonker_24cpr(a_0)); heff_drop(v_x_2428); r_; });
  {
    V v_field_2430 = v_t_2429.f[0];
    heff_drop(v_t_2429.f[1]);
    heff_clo_take(self, 5);
    V v_stx_2432 = heff_tr(heff_call(v_field_2430, 1, (V[]){heff_take_field(v_x_2423, 0)}));
    V v_t_2433 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(v_i_2415, v_stx_2432));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2423, 2);
      heff_drop(v_stx_2432);
      heff_drop(v_t_2433);
      V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(343LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2edefaultAt_str0), v_sp_2414, NTAG(TAG_Nothing)});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_2421, 2), 1, (V[]){v_t_2436}));
      V f_ = heff_get_n(v_hd_2421, 1, 3);
      heff_room[0] = v_t_2437;
      heff_room[1] = v_k_2422;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_2414);
      heff_drop_rec(v_hd_2421, 3);
      heff_drop(v_t_2433);
      V v_t_2438 = ({ V rv_0 = v_stx_2432; V rr_ = heff_rec_reuse_nf(v_x_2423, 2ULL, 2, shape_stx__val, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V f_ = v_k_2422;
      args[0] = v_t_2438;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2eelab_2erules_2edefaultAt_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_2421 = heff_env(self)[0];
  V v_i_2415 = heff_env(self)[1];
  V v_sp_2414 = heff_env(self)[2];
  V v_k_2422 = heff_env(self)[3];
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2edefaultAt_lam3_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2421, 2)), 1, (V[]){v_t_2426}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_2421, 1));
  heff_room[0] = v_t_2427;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2edefaultAt_lam4, 1, 5, (V[]){v_x_2423, v_i_2415, v_sp_2414, v_hd_2421, v_k_2422});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2edefaultAt_lam1(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_i_2415 = heff_env(self)[1];
  V v_sp_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2420;
  args[0] = heff_dup(v_hd_2421);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2edefaultAt_lam2, 1, 4, (V[]){v_hd_2421, v_i_2415, v_sp_2414, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2edefaultAt_lam0(V self, V *args) {
  V v_e_2417 = args[0];
  V v_a_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_i_2415 = heff_env(self)[1];
  V v_sp_2414 = heff_env(self)[2];
  V v_c_2420;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_c_2416)) {
  case TAG_MkChk: {
    V v_f_2419 = heff_field(v_c_2416, 0);
    heff_take_n(v_c_2416, 1ULL, 1);
    v_c_2420 = heff_tr(heff_call(v_f_2419, 2, (V[]){v_e_2417, v_a_2418}));
    break;
  }
  default: heff_nomatch(v_c_2416);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2edefaultAt_lam1, 2, 3, (V[]){v_c_2420, v_i_2415, v_sp_2414});
}
V g_heff_2eelab_2erules_2edefaultAt_lam5(V self, V *args) {
  V v_x_2443 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_t_2444 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2443, 0, 2)});
  heff_clo_take(self, 1);
  V f_ = v_z_245;
  args[0] = v_t_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2eelab_2erules_2eformRecord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eformRecord_entry, 2, 0};

V g_heff_2eelab_2erules_2eformRecord(V v_e_240, V v_fieldTyps_241) {
top: ;
  V v_globals_242 = heff_take_field(v_e_240, 1);
  V v_lams_243 = heff_take_field(v_e_240, 3);
  V v_self_244 = heff_take_field(v_e_240, 4);
  V v_insts_245 = heff_take_field(v_e_240, 5);
  V v_named_246 = heff_take_field(v_e_240, 6);
  V v_evidence_247 = heff_take_field(v_e_240, 7);
  V v_scope_248 = heff_take_field(v_e_240, 0);
  V v_t_249 = v_globals_242;
  V v_t_2410 = v_lams_243;
  V v_t_2411 = v_self_244;
  V v_t_2412 = v_insts_245;
  V v_t_2413 = v_named_246;
  V v_t_2414 = v_evidence_247;
  V v_sd_2415 = v_scope_248;
  V v_t_2416 = heff_tag_n(TAG_CUndelay, 1, (V[]){heff_take_field(v_sd_2415, 3)});
  V v_t_2417 = ({ V rv_3 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_sd_2415, 23ULL, 5, shape_len__names__locals__ctx__matched, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_t_2418 = ({ V rv_0 = v_t_2417; V rv_1 = v_t_249; V rv_2 = NTAG(TAG_ForNominative); V rv_3 = v_t_2410; V rv_4 = v_t_2411; V rv_5 = v_t_2412; V rv_6 = v_t_2413; V rv_7 = v_t_2414; V rr_ = heff_rec_reuse_nf(v_e_240, 0ULL, 8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  return (g_heff_2eelab_2erules_2eformGo(v_t_2418, MK_INT(0LL), v_fieldTyps_241));
}
V g_heff_2eelab_2erules_2eformRecord_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eformRecord(a[0], a[1]);
}
V g_heff_2eelab_2erules_2erecordName_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordName_entry, 7, 0};

V g_heff_2eelab_2erules_2erecordName(V v_e_240, V v_a_241, V v_x_242, V v_sp_243, V v_ty_244, V v_p_245, V v_p_246) {
top: ;
  V v_malg_247 = heff_take_field(v_p_245, 2);
  V v_bind_248 = heff_get_n(v_p_245, 1, 3);
  switch (heff_tag_of(v_a_241)) {
  case TAG_VU: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_malg_247);
    heff_drop(v_bind_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VDecode: {
    V v_a1_2410 = heff_field(v_a_241, 0);
    switch (heff_tag_of(v_a1_2410)) {
    case TAG_HLocal: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop_rec(v_sp_243, 2);
      heff_drop(v_ty_244);
      heff_drop(v_malg_247);
      heff_drop(v_bind_248);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_HGlobal: {
      V v_k_2416 = heff_field(v_a1_2410, 0);
      V v_t_2417 = heff_intSub(heff_dup(heff_rfield(v_sp_243, 1)), heff_dup(heff_rfield(v_sp_243, 0)));
      if ((heff_intEq_c_lent(v_t_2417, heff_strLength_lent(v_x_242, 0), 2) || heff_intEq_c(heff_intSub(heff_dup(heff_rfield(v_sp_243, 1)), heff_dup(heff_rfield(v_sp_243, 0))), heff_box_word((heff_unbox_word(heff_strLength_lent(v_x_242, 0)) + ((int64_t)1ULL)))))) {
        heff_drop(v_t_2417);
        V v_t_2419 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_243, v_x_242, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_k_2416)}), NTAG(TAG_True), heff_clo_n(g_heff_2eelab_2erules_2erecordName_lam0, 1, 2, (V[]){v_e_240, v_ty_244})});
        V v_t_2420 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
        V v_t_2421 = heff_tr(heff_call(v_malg_247, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})}));
        return heff_tail(v_bind_248, 2, (V[]){v_t_2421, v_p_246});
      } else {
        heff_drop(v_e_240);
        heff_drop(v_x_242);
        heff_drop_rec(v_sp_243, 2);
        heff_drop(v_ty_244);
        heff_drop(v_malg_247);
        heff_drop(v_bind_248);
        heff_drop(v_t_2417);
        return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
      }
    }
    case TAG_HMeta: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop_rec(v_sp_243, 2);
      heff_drop(v_ty_244);
      heff_drop(v_malg_247);
      heff_drop(v_bind_248);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_HError: {
      heff_drop(v_e_240);
      heff_drop(v_x_242);
      heff_drop_rec(v_sp_243, 2);
      heff_drop(v_ty_244);
      heff_drop(v_malg_247);
      heff_drop(v_bind_248);
      return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_a1_2410);
    }
  }
  case TAG_VFunction: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_malg_247);
    heff_drop(v_bind_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VRecord: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_malg_247);
    heff_drop(v_bind_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VSum: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_malg_247);
    heff_drop(v_bind_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimInt: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_malg_247);
    heff_drop(v_bind_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_malg_247);
    heff_drop(v_bind_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimString: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_malg_247);
    heff_drop(v_bind_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimRune: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_malg_247);
    heff_drop(v_bind_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VPrimArray: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_malg_247);
    heff_drop(v_bind_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_VFixed: {
    heff_drop(v_e_240);
    heff_drop(v_x_242);
    heff_drop_rec(v_sp_243, 2);
    heff_drop(v_ty_244);
    heff_drop(v_malg_247);
    heff_drop(v_bind_248);
    return heff_tail(v_p_246, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_a_241);
  }
}
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2erecordName(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2erecordName_lam0(V self, V *args) {
  V v_mc_2418 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_ty_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_e_240; V a_1 = v_mc_2418; V a_2 = v_ty_244; V r_ = (g_heff_2eelab_2erules_2etyStrIn(a_0, a_1, a_2)); heff_drop(v_mc_2418); r_; });
}
V g_heff_2eelab_2erules_2erebottom_lam0(V self, V *args);
V g_heff_2eelab_2erules_2erebottom_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2erebottom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erebottom_entry, 2, 0};

V g_heff_2eelab_2erules_2erebottom(V v_v_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_LNil: {
    return NTAG(TAG_LNil);
  }
  case TAG_LSnoc: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_x_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24LSnoc = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_LNil: {
      heff_drop(v_x_243);
      return heff_tag_at_n(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2erules_2erebottom_lam0, 1, 1, (V[]){heff_dup(v_v_240)})});
    }
    case TAG_LSnoc: {
      V v_t_247 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_242));
      return heff_tag_re_n(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, 2ULL, (V[]){v_t_247, v_x_243});
    }
    case TAG_LChunkSnoc: {
      V v_t_2410 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_242));
      return heff_tag_re_n(v_ru_24x2_241_24LSnoc, TAG_LSnoc, 2, 2ULL, (V[]){v_t_2410, v_x_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_LChunkSnoc: {
    V v_x21_2411 = heff_field(v_x2_241, 0);
    V v_xs_2412 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24LChunkSnoc = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_LNil: {
      if ((heff_unbox_word(heff_arrayLength_lent(v_xs_2412, 0)) == ((int64_t)1ULL))) {
        heff_drop(v_xs_2412);
        heff_drop_cell(v_ru_24x2_241_24LChunkSnoc, 2);
        return heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2erules_2erebottom_lam1, 1, 1, (V[]){heff_dup(v_v_240)})});
      } else {
        return heff_tag_re_n(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, 2ULL, (V[]){NTAG(TAG_LNil), v_xs_2412});
      }
    }
    case TAG_LSnoc: {
      V v_t_2416 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_2411));
      return heff_tag_re_n(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, 2ULL, (V[]){v_t_2416, v_xs_2412});
    }
    case TAG_LChunkSnoc: {
      V v_t_2419 = (g_heff_2eelab_2erules_2erebottom(v_v_240, v_x21_2411));
      return heff_tag_re_n(v_ru_24x2_241_24LChunkSnoc, TAG_LChunkSnoc, 2, 2ULL, (V[]){v_t_2419, v_xs_2412});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2erebottom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2erebottom(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2erebottom_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_v_240 = heff_env(self)[0];
  heff_drop(v_u_244);
  heff_clo_take(self, 1);
  return v_v_240;
}
V g_heff_2eelab_2erules_2erebottom_lam1(V self, V *args) {
  V v_u_2413 = args[0];
  V v_v_240 = heff_env(self)[0];
  heff_drop(v_u_2413);
  heff_clo_take(self, 1);
  return v_v_240;
}
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str0, 13, "record field ");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str1, 15, " is given twice");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str2, 13, "record field ");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str3, 16, " is out of order");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str4, 14, "no such field ");
HEFF_LIT(g_heff_2eelab_2erules_2eleftOver_str5, 9, " in type ");
Clo g_heff_2eelab_2erules_2eleftOver_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eleftOver_entry, 5, 0};

V g_heff_2eelab_2erules_2eleftOver(V v_e_240, V v_it_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  V v_malg_245 = heff_take_field(v_z_243, 2);
  V v_bind_246 = heff_get_n(v_z_243, 1, 3);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop_rec(v_it_241, 5);
    heff_drop(v_malg_245);
    heff_drop(v_bind_246);
    return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_fs_247 = heff_field(v_x3_242, 0);
    V v_x_249 = (g_list_2efoldl_24f603879485x1484249893(MK_INT(1LL), MK_INT(0LL), v_fs_247, heff_rfield(v_it_241, 4)));
    if (heff_intLt_c(MK_INT(1LL), v_x_249)) {
      heff_drop(v_e_240);
      V v_t_2410 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str0), heff_dup(heff_rfield(v_fs_247, 0)));
      V v_msg_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2eelab_2erules_2eleftOver_str1));
      V v_note_2412 = (g_heff_2eelab_2erules_2efieldsNote(v_it_241));
      V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), v_msg_2411, heff_dup(heff_rfield(v_fs_247, 2)), heff_tag_n(TAG_Just, 1, (V[]){v_note_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_2415}));
      return heff_tail(v_bind_246, 2, (V[]){v_t_2416, v_z_244});
    } else {
      V v_t_2417 = (g_list_2eany_24s1946659387x922023683(v_fs_247, heff_rfield(v_it_241, 2)));
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_e_240);
        heff_drop(v_t_2417);
        V v_t_2418 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str2), heff_dup(heff_rfield(v_fs_247, 0)));
        V v_msg_2419 = heff_strAppend(v_t_2418, ((V)&g_heff_2eelab_2erules_2eleftOver_str3));
        V v_note_2420 = (g_heff_2eelab_2erules_2efieldsNote(v_it_241));
        V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(304LL), NTAG(TAG_SError), v_msg_2419, heff_dup(heff_rfield(v_fs_247, 2)), heff_tag_n(TAG_Just, 1, (V[]){v_note_2420})});
        V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
        V v_t_2424 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_2423}));
        return heff_tail(v_bind_246, 2, (V[]){v_t_2424, v_z_244});
      } else {
        heff_drop(v_t_2417);
        V v_t_2425 = (g_heff_2eelab_2erules_2etyStr(v_e_240, heff_dup(heff_rfield(v_it_241, 1))));
        V v_t_2426 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eleftOver_str4), heff_dup(heff_rfield(v_fs_247, 0)));
        V v_msg_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2eelab_2erules_2eleftOver_str5)), v_t_2425);
        V v_note_2428 = (g_heff_2eelab_2erules_2efieldsNote(v_it_241));
        V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2427, heff_dup(heff_rfield(v_fs_247, 2)), heff_tag_n(TAG_Just, 1, (V[]){v_note_2428})});
        V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2429})});
        V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
        V v_t_2432 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_2431}));
        return heff_tail(v_bind_246, 2, (V[]){v_t_2432, v_z_244});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eleftOver_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eleftOver(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2erules_2enamedFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamedFrom_entry, 3, 0};

V g_heff_2eelab_2erules_2enamedFrom(V v_x1_240, V v_i_241, V v_j_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_dflt_245 = heff_dup(heff_rfield(v_m_243, 3));
    V v_el_246 = heff_dup(heff_rfield(v_m_243, 2));
    V v_t_247 = v_dflt_245;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_t_248 = heff_intSub_lent(heff_intSub_lent(v_i_241, MK_INT(1LL), 2), v_j_242, 1);
      HeffT3 v_t_249 = (g_heff_2eelab_2erules_2ementionsLocal_24cpr(v_t_248));
      {
        V v_field_2410 = v_t_249.f[0];
        heff_drop(v_t_249.f[1]);
        heff_drop(v_t_249.f[2]);
        V v_t_2413 = heff_tr(heff_call(v_field_2410, 2, (V[]){MK_INT(0LL), heff_get_n(v_el_246, 0, 2)}));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_i_241);
          heff_drop(v_t_2413);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2413);
          V t_0 = v_rest_244;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_j_242;
          v_x1_240 = t_0;
          v_i_241 = t_1;
          v_j_242 = t_2;
          goto top;
        }
      }
    } else {
      heff_drop_rec(v_el_246, 2);
      heff_drop(v_t_247);
      V t_0 = v_rest_244;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_j_242;
      v_x1_240 = t_0;
      v_i_241 = t_1;
      v_j_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2enamedFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2enamedFrom(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2erules_2eboundGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eboundGo_24dps_entry, 4, 0};

V g_heff_2eelab_2erules_2eboundGo_24dps(V v_all_240, V v_x2_241, V v_j_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_j_242);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_246 = (g_list_2edrop(heff_intAdd_lent(v_j_242, MK_INT(1LL), 2), v_all_240));
    V v_t_247 = ({ V a_0 = v_t_246; V a_1 = heff_intAdd_lent(v_j_242, MK_INT(1LL), 2); V a_2 = v_j_242; V r_ = (g_heff_2eelab_2erules_2enamedFrom(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_248);
    V t_0 = v_all_240;
    V t_1 = v_rest_245;
    V t_2 = heff_intAdd(v_j_242, MK_INT(1LL));
    V t_3 = v_u_249;
    v_all_240 = t_0;
    v_x2_241 = t_1;
    v_j_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eboundGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2eboundGo_24dps(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
Clo g_heff_2eelab_2erules_2eletted_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletted_24generate0_entry, 3, 0};

V g_heff_2eelab_2erules_2eletted_24generate0(V v_xs_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if (((((int64_t)0ULL) <= v_i_241) && (heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_m_243 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), heff_get_n(v_m_243, 0, 2));
      V t_0 = v_xs_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = v_t_244;
      v_xs_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_m_243 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), heff_get_n(v_m_243, 0, 2));
    V t_0 = v_xs_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = v_t_244;
    v_xs_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erules_2eletted_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eletted_24generate0(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erules_2eletted_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletted_24map0_entry, 2, 0};

V g_heff_2eelab_2erules_2eletted_24map0(V v_box_24i_240, V v_a_241) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
  v_a_241 = heff_arrayOwn(v_a_241);
  if ((((int64_t)0ULL) <= v_i_240)) {
    top_TAG_InRange: ;
    if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
      V v_m_242 = heff_arrayIndexIn_lent(v_a_241, heff_box_word(v_i_240), 2);
      V v_t_243 = heff_arraySetOwnedIn(v_a_241, heff_box_word(v_i_240), heff_get_n(v_m_242, 0, 2));
      int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
      V t_1 = v_t_243;
      v_i_240 = t_0;
      v_a_241 = t_1;
      goto top_TAG_InRange;
    } else {
      return v_a_241;
    }
  } else {
  }
top: ;
  if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
    V v_m_242 = heff_arrayIndex_lent(v_a_241, heff_box_word(v_i_240), 2);
    V v_t_243 = heff_arraySetOwned(v_a_241, heff_box_word(v_i_240), heff_get_n(v_m_242, 0, 2));
    int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
    V t_1 = v_t_243;
    v_i_240 = t_0;
    v_a_241 = t_1;
    goto top;
  } else {
    return v_a_241;
  }
}
V g_heff_2eelab_2erules_2eletted_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eletted_24map0(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str0, 14, "the type of `.");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str1, 79, "` depends on the fields before it, and what this record's are is not known here");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str2, 14, "no such field ");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str3, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str4, 45, "the record's shape is not in hand here for `.");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str5, 84, "`: annotate the binder, `\\(x : T) -> ...`, or give the implicit argument, `(a := T)`");
HEFF_LIT(g_heff_2eelab_2erules_2erecordElim_str6, 59, "tried to project from a value that was not of a record type");
V g_heff_2eelab_2erules_2erecordElim_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam6(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam7(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam9(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam9, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam10(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam10, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam8(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam12(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam12, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam13(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordElim_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_lam13, 1, 0};
V g_heff_2eelab_2erules_2erecordElim_lam11(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam5(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordElim_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordElim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordElim_entry, 3, 0};

V g_heff_2eelab_2erules_2erecordElim(V v_sp_240, V v_projectee_241, V v_x_242) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam0, 1, 3, (V[]){heff_dup(v_projectee_241), v_sp_240, v_x_242})});
}
V g_heff_2eelab_2erules_2erecordElim_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2erecordElim(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2erecordElim_lam4(V self, V *args) {
  V v_c_2418 = args[0];
  V v_a0_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2418, 3, 9); V a_1 = v_a0_2417; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2erecordElim_lam6(V self, V *args) {
  V v_x_2441 = args[0];
  V v_eprojectee_2416 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_fieldTy_2440 = heff_env(self)[3];
  heff_drop(v_x_2441);
  heff_clo_take(self, 4);
  V v_t_2442 = (g_heff_2eelab_2ememoed_2eproj(v_eprojectee_2416, v_x_242));
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2442, v_fieldTy_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordElim_lam7(V self, V *args) {
  V v_x_2453 = args[0];
  V v_eprojectee_2416 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_fieldTy_2452 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_drop(v_x_2453);
  heff_clo_take(self, 4);
  V v_t_2454 = (g_heff_2eelab_2ememoed_2eprojAt(v_eprojectee_2416, v_x_242, heff_dup(v_fieldTy_2452)));
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2454, v_fieldTy_2452});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordElim_lam9(V self, V *args) {
  V v_x_2468 = args[0];
  heff_drop(v_x_2468);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2erecordElim_lam10(V self, V *args) {
  V v_x_2469 = args[0];
  heff_drop(v_x_2469);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2erecordElim_lam8(V self, V *args) {
  V v_x_2467 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  if ((heff_dup(v_x_2467) == NTAG(TAG_True))) {
    heff_drop(v_x_2467);
    heff_clo_take(self, 4);
    heff_drop(v_x_242);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2470 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2erecordElim_lam9_clo), ((V)&g_heff_2eelab_2erules_2erecordElim_lam10_clo)});
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2eelab_2erules_2eerrorOf_24rec0_get()), v_t_2470});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2467);
    heff_clo_take(self, 4);
    V v_t_2471 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str4), v_x_242), ((V)&g_heff_2eelab_2erules_2erecordElim_str5));
    V v_t_2472 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_2471, v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2474}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2475;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam12(V self, V *args) {
  V v_x_2477 = args[0];
  heff_drop(v_x_2477);
  return NTAG(TAG_Nothing);
}
V g_heff_2eelab_2erules_2erecordElim_lam13(V self, V *args) {
  V v_x_2478 = args[0];
  heff_drop(v_x_2478);
  return (g_heff_2eelab_2evalue_2emkNeu_24s1303314342x969225470(NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2erecordElim_lam11(V self, V *args) {
  V v_x_2476 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  if ((heff_dup(v_x_2476) == NTAG(TAG_True))) {
    heff_drop(v_x_2476);
    heff_clo_take(self, 3);
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_246, 3);
    V v_t_2479 = heff_tag_n(TAG_VDecode, 5, (V[]){NTAG(TAG_HError), NTAG(TAG_SpId), NTAG(TAG_LargeU), ((V)&g_heff_2eelab_2erules_2erecordElim_lam12_clo), ((V)&g_heff_2eelab_2erules_2erecordElim_lam13_clo)});
    V f_ = v_k_247;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2eelab_2erules_2eerrorOf_24rec0_get()), v_t_2479});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_x_2476);
    heff_clo_take(self, 3);
    V v_t_2480 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordElim_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2482}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2483;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_eprojectee_2416 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_t_2423 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2422)));
  switch (heff_tag_of(v_t_2423)) {
  case TAG_LikeRecord: {
    V v_fieldTypes_2426 = heff_field(v_t_2423, 2);
    heff_take_n(v_t_2423, 4ULL, 3);
    HeffT2 v_t_2427 = ({ V b_0 = heff_get_n(v_fieldTypes_2426, 1, 3); V a_1 = v_x_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2429 = v_t_2427.f[1];
      int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
      if ((v_tag_2428 == ((int64_t)0ULL))) {
        V v_x_2430 = v_field_2429;
        heff_drop(v_x_2430);
        V v_x1_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_eprojectee_2416, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_v_2435;
        switch (heff_tag_of(v_x1_2431)) {
        case TAG_Nom: {
          V v_x_2432 = heff_field(v_x1_2431, 0);
          heff_take_n(v_x1_2431, 1ULL, 1);
          v_v_2435 = v_x_2432;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2431, 0ULL, 1);
          v_v_2435 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2434 = heff_field(v_x1_2431, 0);
          heff_take_n(v_x1_2431, 1ULL, 1);
          v_v_2435 = v_x_2434;
          break;
        }
        default: heff_nomatch(v_x1_2431);
        }
        V v_t_2436 = ({ V a_0 = v_v_2435; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop(v_v_2435); r_; });
        HeffT2 v_t_2437 = ({ V a_0 = heff_dup(v_x_2422); V a_1 = v_t_2436; V a_2 = v_x_242; HeffT2 r_ = (g_heff_2eelab_2evalue_2eprojTyWith_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2436); r_; });
        {
          V v_field_2439 = v_t_2437.f[1];
          int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
          if ((v_tag_2438 == ((int64_t)0ULL))) {
            V v_fieldTy_2440 = v_field_2439;
            heff_clo_take(self, 6);
            return ({ V a_0 = v_e_243; V a_1 = v_x_2422; V a_2 = heff_dup(v_x_242); V a_3 = v_sp_240; V a_4 = heff_dup(v_fieldTy_2440); V a_5 = v_hd_246; V a_6 = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam6, 1, 4, (V[]){v_eprojectee_2416, v_x_242, v_k_247, v_fieldTy_2440}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2422); r_; });
          } else {
            heff_drop(v_field_2439);
            V v_x1_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_eprojectee_2416, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
            V v_t_2447;
            switch (heff_tag_of(v_x1_2443)) {
            case TAG_Nom: {
              V v_x_2444 = heff_field(v_x1_2443, 0);
              heff_take_n(v_x1_2443, 1ULL, 1);
              v_t_2447 = v_x_2444;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2443, 0ULL, 1);
              v_t_2447 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2446 = heff_field(v_x1_2443, 0);
              heff_take_n(v_x1_2443, 1ULL, 1);
              v_t_2447 = v_x_2446;
              break;
            }
            default: heff_nomatch(v_x1_2443);
            }
            V v_t_2448 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 5);
            HeffT2 v_t_2449 = ({ V a_0 = v_t_2448; V a_1 = heff_dup(v_x_2422); V a_2 = v_t_2447; V a_3 = v_x_242; HeffT2 r_ = (g_heff_2eelab_2erules_2efieldTyLate_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2448); r_; });
            {
              V v_field_2451 = v_t_2449.f[1];
              int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
              if ((v_tag_2450 == ((int64_t)0ULL))) {
                V v_fieldTy_2452 = v_field_2451;
                heff_clo_take(self, 6);
                return ({ V a_0 = v_e_243; V a_1 = v_x_2422; V a_2 = heff_dup(v_x_242); V a_3 = v_sp_240; V a_4 = heff_dup(v_fieldTy_2452); V a_5 = v_hd_246; V a_6 = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam7, 1, 4, (V[]){v_eprojectee_2416, v_x_242, v_fieldTy_2452, v_k_247}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2422); r_; });
              } else {
                heff_drop(v_x_2422);
                heff_clo_take(self, 6);
                heff_drop_rec(v_eprojectee_2416, 2);
                heff_drop_rec(v_e_243, 8);
                heff_drop(v_field_2451);
                V v_t_2455 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str0), v_x_242), ((V)&g_heff_2eelab_2erules_2erecordElim_str1));
                V v_t_2456 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_2455, v_sp_240, NTAG(TAG_Nothing)});
                V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2456})});
                V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
                V v_t_2459 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2458}));
                V f_ = heff_get_n(v_hd_246, 1, 3);
                heff_room[0] = v_t_2459;
                heff_room[1] = v_k_247;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
            }
          }
        }
      } else {
        heff_clo_take(self, 6);
        heff_drop_rec(v_eprojectee_2416, 2);
        heff_drop(v_field_2429);
        V v_t_2460 = (g_heff_2eelab_2erules_2etyStr(v_e_243, v_x_2422));
        V v_t_2461 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordElim_str2), v_x_242), ((V)&g_heff_2eelab_2erules_2erecordElim_str3));
        V v_msg_2462 = heff_strAppend(v_t_2461, v_t_2460);
        V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(307LL), NTAG(TAG_SError), v_msg_2462, v_sp_240, NTAG(TAG_Nothing)});
        V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2463})});
        V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
        V v_t_2466 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2465}));
        V f_ = heff_get_n(v_hd_246, 1, 3);
        heff_room[0] = v_t_2466;
        heff_room[1] = v_k_247;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
  case TAG_NoRules: {
    heff_clo_take(self, 6);
    heff_drop_rec(v_eprojectee_2416, 2);
    heff_drop_rec(v_e_243, 8);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam8, 1, 4, (V[]){v_k_247, v_x_242, v_sp_240, v_hd_246})));
  }
  default: {
    heff_clo_take(self, 6);
    heff_drop(v_x_242);
    heff_drop_rec(v_eprojectee_2416, 2);
    heff_drop_rec(v_e_243, 8);
    heff_drop(v_t_2423);
    return (g_heff_2eelab_2emeta_2eblockedTy(v_x_2422, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam11, 1, 3, (V[]){v_k_247, v_sp_240, v_hd_246})));
  }
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_eprojectee_2416 = heff_field(v_x_2415, 0);
    V v_a0_2417 = heff_field(v_x_2415, 1);
    heff_take_n(v_x_2415, 3ULL, 2);
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam4, 1, 1, (V[]){v_a0_2417})})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2420}));
    heff_clo_take(self, 5);
    V f_ = heff_dup(heff_rfield(v_hd_246, 1));
    heff_room[0] = v_t_2421;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam5, 1, 6, (V[]){v_x_242, v_eprojectee_2416, v_e_243, v_sp_240, v_hd_246, v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2eelab_2erules_2erecordElim_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_t_2411;
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_dup(heff_field(v_x_248, 0));
    v_t_2411 = v_x_249;
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  V v_t_2414;
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_y_2413 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 2ULL, 2);
    v_t_2414 = v_y_2413;
    break;
  }
  default: heff_nomatch(v_x_248);
  }
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_243), heff_dup(v_sp_240), v_t_2411, v_t_2414, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam3, 1, 5, (V[]){v_hd_246, v_x_242, v_e_243, v_sp_240, v_k_247})));
}
V g_heff_2eelab_2erules_2erecordElim_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam2, 1, 5, (V[]){v_e_243, v_sp_240, v_hd_246, v_x_242, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordElim_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_projectee_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_c_245;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_projectee_241)) {
  case TAG_MkSyn: {
    V v_f_244 = heff_field(v_projectee_241, 0);
    heff_take_n(v_projectee_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_projectee_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2erecordElim_lam1, 2, 4, (V[]){v_c_245, v_e_243, v_sp_240, v_x_242});
}
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str0, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str1, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str2, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str3, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str4, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str5, 14, "no such field ");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str6, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str7, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str8, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str9, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str10, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str11, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str12, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str13, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str14, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str15, 45, "can only specialize type with record behavior");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str16, 27, "can only specialize neutral");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str17, 27, "can only specialize neutral");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str18, 27, "can only specialize neutral");
HEFF_LIT(g_heff_2eelab_2erules_2erecordSpec_str19, 27, "can only specialize neutral");
V g_heff_2eelab_2erules_2erecordSpec_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordSpec_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordSpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordSpec_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordSpec(V v_sp_240, V v_s_241, V v_x_242, V v_c_243) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam0, 1, 4, (V[]){heff_dup(v_s_241), v_sp_240, v_x_242, heff_dup(v_c_243)})});
}
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2erecordSpec(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2erecordSpec_lam4(V self, V *args) {
  V v_u_2490 = args[0];
  V v_val_2485 = heff_env(self)[0];
  V v_val_2489 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  heff_drop(v_u_2490);
  heff_clo_take(self, 3);
  V v_x1_2491 = heff_tr(heff_call(v_val_2485, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2495;
  switch (heff_tag_of(v_x1_2491)) {
  case TAG_Nom: {
    V v_x_2492 = heff_field(v_x1_2491, 0);
    heff_take_n(v_x1_2491, 1ULL, 1);
    v_t_2495 = v_x_2492;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2491, 0ULL, 1);
    v_t_2495 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2494 = heff_field(v_x1_2491, 0);
    heff_take_n(v_x1_2491, 1ULL, 1);
    v_t_2495 = v_x_2494;
    break;
  }
  default: heff_nomatch(v_x1_2491);
  }
  V v_x1_2496 = heff_tr(heff_call(v_val_2489, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_24100;
  switch (heff_tag_of(v_x1_2496)) {
  case TAG_Nom: {
    V v_x_2497 = heff_field(v_x1_2496, 0);
    heff_take_n(v_x1_2496, 1ULL, 1);
    v_t_24100 = v_x_2497;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2496, 0ULL, 1);
    v_t_24100 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2499 = heff_field(v_x1_2496, 0);
    heff_take_n(v_x1_2496, 1ULL, 1);
    v_t_24100 = v_x_2499;
    break;
  }
  default: heff_nomatch(v_x1_2496);
  }
  V v_t_24101 = (g_heff_2eelab_2evalue_2especialize(v_t_2495, v_x_2486, v_t_24100));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_24101});
}
V g_heff_2eelab_2erules_2erecordSpec_lam3(V self, V *args) {
  V v_x_2482 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_a_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_g_2483 = v_g_2410;
  V v_stx_2484 = heff_take_field(v_g_2483, 0);
  V v_val_2485 = heff_get_n(v_g_2483, 1, 2);
  V v_x_2486 = v_x_242;
  V v_g_27_2487 = v_x_2482;
  V v_stx_2488 = heff_take_field(v_g_27_2487, 0);
  V v_val_2489 = heff_take_field(v_g_27_2487, 1);
  V v_t_24102 = ({ V rv_0 = heff_tag_n(TAG_SSpecialize, 3, (V[]){v_stx_2484, heff_dup(v_x_2486), v_stx_2488}); V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam4, 1, 3, (V[]){v_val_2485, v_val_2489, v_x_2486}); V rr_ = heff_rec_reuse_nf(v_g_27_2487, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24102, v_a_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordSpec_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_c_243 = heff_env(self)[5];
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_g_2410 = heff_field(v_x_249, 0);
    V v_a_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_x1_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_2410, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2416;
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nom: {
      V v_x_2413 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = v_x_2413;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2412, 0ULL, 1);
      v_t_2416 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2415 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 1);
      v_t_2416 = v_x_2415;
      break;
    }
    default: heff_nomatch(v_x1_2412);
    }
    switch (heff_tag_of(v_t_2416)) {
    case TAG_VNeu: {
      V v_desc_2421 = heff_field(v_t_2416, 4);
      heff_take_n(v_t_2416, 16ULL, 5);
      V v_it_2422 = heff_tr(heff_call(v_desc_2421, 1, (V[]){NTAG(TAG_MkUnit)}));
      switch (heff_tag_of(v_it_2422)) {
      case TAG_Nothing: {
        heff_clo_take(self, 6);
        heff_drop(v_x_242);
        heff_drop_rec(v_e_244, 8);
        heff_drop(v_c_243);
        heff_drop_rec(v_g_2410, 2);
        heff_drop(v_a_2411);
        V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str0), v_sp_240, NTAG(TAG_Nothing)});
        V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2425}));
        V f_ = heff_get_n(v_hd_247, 1, 3);
        heff_room[0] = v_t_2426;
        heff_room[1] = v_k_248;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      case TAG_Just: {
        V v_it1_2427 = heff_field(v_it_2422, 0);
        V v_ru_24it_2422_24Just = heff_take_reuse_n(v_it_2422, 1ULL, 1);
        switch (heff_tag_of(v_it1_2427)) {
        case TAG_VNeu: {
          heff_take_n(v_it1_2427, 0ULL, 5);
          heff_clo_take(self, 6);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 8);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_2433 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str1), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_2434 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2433})});
          V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
          V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2435}));
          V f_ = heff_get_n(v_hd_247, 1, 3);
          heff_room[0] = v_t_2436;
          heff_room[1] = v_k_248;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_VCode: {
          V v_it11_2437 = heff_field(v_it1_2427, 0);
          V v_ru_24it1_2427_24VCode = heff_take_reuse_n(v_it1_2427, 1ULL, 1);
          switch (heff_tag_of(v_it11_2437)) {
          case TAG_VU: {
            V v_ru_24it11_2437_24VU = heff_take_reuse_n(v_it11_2437, 0ULL, 1);
            heff_clo_take(self, 6);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 8);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str2), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2440 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_Throw, 1, (V[]){v_t_2439})});
            V v_t_2441 = heff_tag_at_n(v_ru_24it11_2437_24VU, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
            V v_t_2442 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2441}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2442;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VDecode: {
            heff_take_n(v_it11_2437, 0ULL, 5);
            heff_clo_take(self, 6);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 8);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str3), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2449 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_Throw, 1, (V[]){v_t_2448})});
            V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
            V v_t_2451 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2450}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2451;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VFunction: {
            heff_take_n(v_it11_2437, 0ULL, 6);
            heff_clo_take(self, 6);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 8);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str4), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_2459 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_Throw, 1, (V[]){v_t_2458})});
            V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
            V v_t_2461 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2460}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_2461;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VRecord: {
            V v_capture_2463 = heff_field(v_it11_2437, 1);
            V v_fieldTypes_2464 = heff_field(v_it11_2437, 2);
            heff_take_n(v_it11_2437, 6ULL, 4);
            HeffT2 v_t_2466 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_fieldTypes_2464, 1), v_x_242));
            {
              V v_field_2468 = v_t_2466.f[1];
              int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
              if ((v_tag_2467 == ((int64_t)0ULL))) {
                heff_clo_take(self, 6);
                heff_drop(v_sp_240);
                heff_drop_cell(v_ru_24it1_2427_24VCode, 1);
                V v_x_2469 = v_field_2468;
                heff_drop(v_x_2469);
                V v_t_2470 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2464, 0)));
                V v_t_2471 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2464, 2)));
                V v_t_2472 = (g_heff_2eutil_2edict_2ezipKV(v_t_2470, v_t_2471));
                V v_t_2473 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 5);
                V v_xs_2474 = ({ V a_0 = heff_dup(v_capture_2463); V b_1 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_HLocal, 1, (V[]){v_t_2473}); V a_2 = NTAG(TAG_SpId); V a_3 = NTAG(TAG_Nothing); V a_4 = v_t_2472; V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2eelab_2evalue_2egoER_24s1078260733x1707764195(a_0, b_1, a_2, a_3, a_4, a_5)); heff_drop(b_1); r_; });
                V v_t_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2474));
                V v_t_2476 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_fieldTypes_2464, 0)), heff_dup(heff_rfield(v_fieldTypes_2464, 1)), heff_arrayFromList(v_t_2475)});
                V v_t_2477 = heff_tr(g_heff_2eelab_2evalue_2etypeForProjection(v_capture_2463, v_fieldTypes_2464, v_x_242, v_t_2476));
                switch (heff_tag_of(v_t_2477)) {
                case TAG_MkField: {
                  V v_fty_2478 = heff_field(v_t_2477, 0);
                  heff_take_n(v_t_2477, 1ULL, 2);
                  V v_c_2481;
                  switch (heff_tag_of(v_c_243)) {
                  case TAG_MkChk: {
                    V v_f_2480 = heff_field(v_c_243, 0);
                    heff_take_n(v_c_243, 1ULL, 1);
                    v_c_2481 = heff_tr(heff_call(v_f_2480, 2, (V[]){v_e_244, v_fty_2478}));
                    break;
                  }
                  default: heff_nomatch(v_c_243);
                  }
                  V f_ = v_c_2481;
                  heff_room[0] = v_hd_247;
                  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam3, 1, 4, (V[]){v_g_2410, v_x_242, v_k_248, v_a_2411});
                  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                }
                default: return heff_nomatch(v_t_2477);
                }
              } else {
                heff_clo_take(self, 6);
                heff_drop_rec(v_e_244, 8);
                heff_drop(v_c_243);
                heff_drop_rec(v_g_2410, 2);
                heff_drop(v_a_2411);
                heff_drop(v_capture_2463);
                heff_drop_rec(v_fieldTypes_2464, 3);
                heff_drop(v_field_2468);
                V v_t_24103 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordSpec_str5), v_x_242), v_sp_240, NTAG(TAG_Nothing)});
                V v_t_24104 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_Throw, 1, (V[]){v_t_24103})});
                V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
                V v_t_24106 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24105}));
                V f_ = heff_get_n(v_hd_247, 1, 3);
                heff_room[0] = v_t_24106;
                heff_room[1] = v_k_248;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
            }
          }
          case TAG_VSum: {
            V v_ru_24it11_2437_24VSum = heff_take_reuse_n(v_it11_2437, 0ULL, 1);
            heff_clo_take(self, 6);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 8);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str6), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24109 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_Throw, 1, (V[]){v_t_24108})});
            V v_t_24110 = heff_tag_at_n(v_ru_24it11_2437_24VSum, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
            V v_t_24111 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24110}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24111;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimInt: {
            heff_clo_take(self, 6);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 8);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24112 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str7), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24113 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_Throw, 1, (V[]){v_t_24112})});
            V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
            V v_t_24115 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24114}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24115;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimFloat: {
            heff_clo_take(self, 6);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 8);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24116 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str8), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24117 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_Throw, 1, (V[]){v_t_24116})});
            V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
            V v_t_24119 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24118}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24119;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimString: {
            heff_clo_take(self, 6);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 8);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24120 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str9), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24121 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_Throw, 1, (V[]){v_t_24120})});
            V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
            V v_t_24123 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24122}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24123;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimRune: {
            heff_clo_take(self, 6);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 8);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24124 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str10), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24125 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_Throw, 1, (V[]){v_t_24124})});
            V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
            V v_t_24127 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24126}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24127;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VPrimArray: {
            V v_ru_24it11_2437_24VPrimArray = heff_take_reuse_n(v_it11_2437, 0ULL, 1);
            heff_clo_take(self, 6);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 8);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24129 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str11), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24130 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_Throw, 1, (V[]){v_t_24129})});
            V v_t_24131 = heff_tag_at_n(v_ru_24it11_2437_24VPrimArray, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
            V v_t_24132 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24131}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24132;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          case TAG_VFixed: {
            V v_ru_24it11_2437_24VFixed = heff_take_reuse_n(v_it11_2437, 0ULL, 1);
            heff_clo_take(self, 6);
            heff_drop(v_x_242);
            heff_drop_rec(v_e_244, 8);
            heff_drop(v_c_243);
            heff_drop_rec(v_g_2410, 2);
            heff_drop(v_a_2411);
            V v_t_24134 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str12), v_sp_240, NTAG(TAG_Nothing)});
            V v_t_24135 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24it1_2427_24VCode, TAG_Throw, 1, (V[]){v_t_24134})});
            V v_t_24136 = heff_tag_at_n(v_ru_24it11_2437_24VFixed, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
            V v_t_24137 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24136}));
            V f_ = heff_get_n(v_hd_247, 1, 3);
            heff_room[0] = v_t_24137;
            heff_room[1] = v_k_248;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
          default: return heff_nomatch(v_it11_2437);
          }
        }
        case TAG_VLam: {
          heff_take_n(v_it1_2427, 0ULL, 2);
          heff_clo_take(self, 6);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 8);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_24140 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str13), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24141 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24140})});
          V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
          V v_t_24143 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24142}));
          V f_ = heff_get_n(v_hd_247, 1, 3);
          heff_room[0] = v_t_24143;
          heff_room[1] = v_k_248;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_VCons: {
          V v_ru_24it1_2427_24VCons = heff_take_reuse_n(v_it1_2427, 0ULL, 1);
          heff_clo_take(self, 6);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 8);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_24145 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str14), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24146 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_at_n(v_ru_24it1_2427_24VCons, TAG_Throw, 1, (V[]){v_t_24145})});
          V v_t_24147 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24146})});
          V v_t_24148 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24147}));
          V f_ = heff_get_n(v_hd_247, 1, 3);
          heff_room[0] = v_t_24148;
          heff_room[1] = v_k_248;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_VOpaque: {
          heff_clo_take(self, 6);
          heff_drop(v_x_242);
          heff_drop_rec(v_e_244, 8);
          heff_drop(v_c_243);
          heff_drop_rec(v_g_2410, 2);
          heff_drop(v_a_2411);
          V v_t_24149 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str15), v_sp_240, NTAG(TAG_Nothing)});
          V v_t_24150 = heff_tag_at_n(v_ru_24it_2422_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24149})});
          V v_t_24151 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24150})});
          V v_t_24152 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24151}));
          V f_ = heff_get_n(v_hd_247, 1, 3);
          heff_room[0] = v_t_24152;
          heff_room[1] = v_k_248;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_it1_2427);
        }
      }
      default: return heff_nomatch(v_it_2422);
      }
    }
    case TAG_VCode: {
      V v_ru_24t_2416_24VCode = heff_take_reuse_n(v_t_2416, 0ULL, 1);
      heff_clo_take(self, 6);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 8);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24154 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str16), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24155 = heff_tag_at_n(v_ru_24t_2416_24VCode, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24154})});
      V v_t_24156 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24155})});
      V v_t_24157 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24156}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24157;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VLam: {
      heff_take_n(v_t_2416, 0ULL, 2);
      heff_clo_take(self, 6);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 8);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24160 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str17), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24161 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24160})});
      V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
      V v_t_24163 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24162}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24163;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VCons: {
      V v_ru_24t_2416_24VCons = heff_take_reuse_n(v_t_2416, 0ULL, 1);
      heff_clo_take(self, 6);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 8);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24165 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str18), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24166 = heff_tag_at_n(v_ru_24t_2416_24VCons, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24165})});
      V v_t_24167 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24166})});
      V v_t_24168 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24167}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24168;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VOpaque: {
      heff_clo_take(self, 6);
      heff_drop(v_x_242);
      heff_drop_rec(v_e_244, 8);
      heff_drop(v_c_243);
      heff_drop_rec(v_g_2410, 2);
      heff_drop(v_a_2411);
      V v_t_24169 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(322LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordSpec_str19), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24170 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24169})});
      V v_t_24171 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24170})});
      V v_t_24172 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_24171}));
      V f_ = heff_get_n(v_hd_247, 1, 3);
      heff_room[0] = v_t_24172;
      heff_room[1] = v_k_248;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2erules_2erecordSpec_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_e_244 = heff_env(self)[3];
  V v_c_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam2, 1, 6, (V[]){v_sp_240, v_hd_247, v_k_248, v_x_242, v_e_244, v_c_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordSpec_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_c_243 = heff_env(self)[3];
  V v_c_246;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_244)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2erecordSpec_lam1, 2, 5, (V[]){v_c_246, v_sp_240, v_x_242, v_e_244, v_c_243});
}
Clo g_heff_2eelab_2erules_2esumFormation_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24generate0_entry, 3, 0};

V g_heff_2eelab_2erules_2esumFormation_24generate0(V v_xs_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if (((((int64_t)0ULL) <= v_i_241) && (heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_m_243 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), heff_get_n(v_m_243, 0, 2));
      V t_0 = v_xs_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = v_t_244;
      v_xs_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_m_243 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), heff_get_n(v_m_243, 0, 2));
    V t_0 = v_xs_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = v_t_244;
    v_xs_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erules_2esumFormation_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2esumFormation_24generate0(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2esumFormation_24map3_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esumFormation_24map3_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24map3_lam0, 1, 0};
V g_heff_2eelab_2erules_2esumFormation_24map3_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumFormation_24map3_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2esumFormation_24map3_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24map3_lam2, 1, 0};
V g_heff_2eelab_2erules_2esumFormation_24map3_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2esumFormation_24map3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24map3_entry, 2, 0};

V g_heff_2eelab_2erules_2esumFormation_24map3(V v_box_24i_240, V v_a_241) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
  v_a_241 = heff_arrayOwn(v_a_241);
  if ((((int64_t)0ULL) <= v_i_240)) {
    top_TAG_InRange: ;
    if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
      V v_xs_242 = heff_arrayIndexIn_lent(v_a_241, heff_box_word(v_i_240), 2);
      V v_m_243 = heff_arrayLength_lent(v_xs_242, 0);
      V v_t_2413;
      if ((heff_peek_word(v_m_243) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_242);
        v_t_2413 = heff_arrayGenerate(v_m_243, ((V)&g_heff_2eelab_2erules_2esumFormation_24map3_lam0_clo));
      } else {
        V v_m_245 = heff_arrayIndex_lent(v_xs_242, MK_INT(0LL), 2);
        V v_y_2411 = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_24map3_lam1, 1, 1, (V[]){v_m_245});
        V v_t_2412 = heff_arrayKeepsAs_lent(v_xs_242, v_y_2411, 0);
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_m_243);
          heff_drop(v_t_2412);
          v_t_2413 = (g_heff_2eelab_2erules_2esumFormation_24map2(MK_INT(1LL), heff_arraySet(v_xs_242, MK_INT(0LL), v_y_2411)));
        } else {
          heff_drop(v_t_2412);
          v_t_2413 = ({ V a_0 = v_xs_242; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_243, v_y_2411); V r_ = (g_heff_2eelab_2erules_2esumFormation_24generate2(a_0, a_1, a_2)); heff_drop(v_xs_242); r_; });
        }
      }
      int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
      V t_1 = heff_arraySetOwnedIn(v_a_241, heff_box_word(v_i_240), v_t_2413);
      v_i_240 = t_0;
      v_a_241 = t_1;
      goto top_TAG_InRange;
    } else {
      return v_a_241;
    }
  } else {
  }
top: ;
  if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
    V v_xs_242 = heff_arrayIndex_lent(v_a_241, heff_box_word(v_i_240), 2);
    V v_m_243 = heff_arrayLength_lent(v_xs_242, 0);
    V v_t_2413;
    if ((heff_peek_word(v_m_243) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_242);
      v_t_2413 = heff_arrayGenerate(v_m_243, ((V)&g_heff_2eelab_2erules_2esumFormation_24map3_lam2_clo));
    } else {
      V v_m_245 = heff_arrayIndex_lent(v_xs_242, MK_INT(0LL), 2);
      V v_y_2411 = heff_clo_n(g_heff_2eelab_2erules_2esumFormation_24map3_lam3, 1, 1, (V[]){v_m_245});
      V v_t_2412 = heff_arrayKeepsAs_lent(v_xs_242, v_y_2411, 0);
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        heff_drop(v_t_2412);
        v_t_2413 = (g_heff_2eelab_2erules_2esumFormation_24map2(MK_INT(1LL), heff_arraySet(v_xs_242, MK_INT(0LL), v_y_2411)));
      } else {
        heff_drop(v_t_2412);
        v_t_2413 = ({ V a_0 = v_xs_242; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_243, v_y_2411); V r_ = (g_heff_2eelab_2erules_2esumFormation_24generate2(a_0, a_1, a_2)); heff_drop(v_xs_242); r_; });
      }
    }
    int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
    V t_1 = heff_arraySetOwned(v_a_241, heff_box_word(v_i_240), v_t_2413);
    v_i_240 = t_0;
    v_a_241 = t_1;
    goto top;
  } else {
    return v_a_241;
  }
}
V g_heff_2eelab_2erules_2esumFormation_24map3_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumFormation_24map3(a[0], a[1]);
}
V g_heff_2eelab_2erules_2esumFormation_24map3_lam0(V self, V *args) {
  V v_u_244 = args[0];
  heff_drop(v_u_244);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2esumFormation_24map3_lam1(V self, V *args) {
  V v_u2_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  heff_drop(v_u2_246);
  heff_clo_take(self, 1);
  V v_x1_247 = heff_tr(heff_call(heff_get_n(v_m_245, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nom: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 1);
    return v_x_248;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_247, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2410 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 1);
    return v_x_2410;
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2eelab_2erules_2esumFormation_24map3_lam2(V self, V *args) {
  V v_u_244 = args[0];
  heff_drop(v_u_244);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2esumFormation_24map3_lam3(V self, V *args) {
  V v_u2_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  heff_drop(v_u2_246);
  heff_clo_take(self, 1);
  V v_x1_247 = heff_tr(heff_call(heff_get_n(v_m_245, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nom: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 1);
    return v_x_248;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_247, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2410 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 1);
    return v_x_2410;
  }
  default: return heff_nomatch(v_x1_247);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2esealedOf_24cpr_str0, 4, "(..)");

HeffT2 g_heff_2eelab_2erules_2esealedOf_24cpr(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VU: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VDecode: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_described_246 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 9ULL, 5);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_HLocal: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop(v_described_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_HGlobal: {
      V v_k_249 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      HeffT2 v_t_2410 = ({ V a_0 = heff_rfield(v_g_240, 6); V b_1 = heff_strAppend(v_k_249, ((V)&g_heff_2eelab_2erules_2esealedOf_24cpr_str0)); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop(v_described_246);
          V v_m_2413 = v_field_2412;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_m_2413}});
        } else {
          heff_drop(v_field_2412);
          V v_t_2414 = heff_tr(heff_call(v_described_246, 1, (V[]){NTAG(TAG_MkUnit)}));
          switch (heff_tag_of(v_t_2414)) {
          case TAG_Nothing: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_t_2415 = heff_field(v_t_2414, 0);
            heff_take_n(v_t_2414, 1ULL, 1);
            V t_0 = v_g_240;
            V t_1 = v_t_2415;
            v_g_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2414)}});
          }
        }
      }
    }
    case TAG_HMeta: {
      heff_take_n(v_x21_243, 0ULL, 1);
      heff_drop(v_described_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_HError: {
      heff_drop(v_described_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_243)}});
    }
  }
  case TAG_VFunction: {
    heff_take_n(v_x2_241, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VRecord: {
    heff_take_n(v_x2_241, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VSum: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VPrimArray: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VFixed: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2eelab_2erules_2elocalDef_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam4(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam6(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam8(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam9(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam7(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam5(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elocalDef_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elocalDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elocalDef_entry, 4, 0};

V g_heff_2eelab_2erules_2elocalDef(V v_x_240, V v_typ_241, V v_body_242, V v_rest_243) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam0, 2, 4, (V[]){heff_dup(v_typ_241), v_x_240, heff_dup(v_body_242), heff_dup(v_rest_243)})});
}
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2elocalDef(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2elocalDef_lam3(V self, V *args) {
  V v_u_2420 = args[0];
  V v_a_2418 = heff_env(self)[0];
  heff_drop(v_u_2420);
  heff_clo_take(self, 1);
  return v_a_2418;
}
V g_heff_2eelab_2erules_2elocalDef_lam4(V self, V *args) {
  V v_u_2425 = args[0];
  V v_v_2421 = heff_env(self)[0];
  heff_drop(v_u_2425);
  heff_clo_take(self, 1);
  return v_v_2421;
}
V g_heff_2eelab_2erules_2elocalDef_lam6(V self, V *args) {
  V v_v_2443 = args[0];
  V v_scope_27_2444 = args[1];
  V v_z_2445 = args[2];
  V v_z_2446 = args[3];
  V v_rest_243 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_b_245 = heff_env(self)[2];
  heff_drop(v_v_2443);
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_rest_243)) {
  case TAG_MkChk: {
    V v_f_2447 = heff_field(v_rest_243, 0);
    heff_take_n(v_rest_243, 1ULL, 1);
    V v_t_2448 = ({ V rv_0 = v_scope_27_2444; V rr_ = heff_rec_reuse_nf(v_e_244, 254ULL, 8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, 65532u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_f_2447;
    args[0] = v_t_2448;
    args[1] = v_b_245;
    args[2] = v_z_2445;
    args[3] = v_z_2446;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  default: return heff_nomatch(v_rest_243);
  }
}
V g_heff_2eelab_2erules_2elocalDef_lam8(V self, V *args) {
  V v_u_2456 = args[0];
  V v_b_245 = heff_env(self)[0];
  heff_drop(v_u_2456);
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_b_245});
}
V g_heff_2eelab_2erules_2elocalDef_lam9(V self, V *args) {
  V v_u_2466 = args[0];
  V v_field_2463 = heff_env(self)[0];
  heff_drop(v_u_2466);
  heff_clo_take(self, 1);
  V v_x2_2467 = heff_tr(heff_call(v_field_2463, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_Nom: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    heff_take_n(v_x2_2467, 1ULL, 1);
    return (g_heff_2eelab_2evalue_2eapp_24s848338757x263511075(v_x_2468));
  }
  case TAG_Describe: {
    V v_x_2469 = heff_field(v_x2_2467, 0);
    heff_take_n(v_x2_2467, 1ULL, 1);
    return (g_heff_2eelab_2evalue_2eapp_24s848338757x263511075(v_x_2469));
  }
  case TAG_Become: {
    V v_x_2470 = heff_field(v_x2_2467, 0);
    V v_ru_24x2_2467_24Become = heff_take_reuse_n(v_x2_2467, 1ULL, 1);
    V v_x1_2471 = heff_tr(g_heff_2eelab_2evalue_2eapp_24s848338757x263511075(v_x_2470));
    V v_t_2475;
    switch (heff_tag_of(v_x1_2471)) {
    case TAG_Nom: {
      V v_x_2472 = heff_field(v_x1_2471, 0);
      heff_take_n(v_x1_2471, 1ULL, 1);
      v_t_2475 = v_x_2472;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2471, 0ULL, 1);
      v_t_2475 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2474 = heff_field(v_x1_2471, 0);
      heff_take_n(v_x1_2471, 1ULL, 1);
      v_t_2475 = v_x_2474;
      break;
    }
    default: heff_nomatch(v_x1_2471);
    }
    return heff_tag_at_n(v_ru_24x2_2467_24Become, TAG_Become, 1, (V[]){v_t_2475});
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2eelab_2erules_2elocalDef_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_b_245 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_x_2437 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2450 = heff_take_field(v_e_244, 2);
  V v_t_2453;
  switch (heff_tag_of(v_t_2450)) {
  case TAG_ForNominative: {
    v_t_2453 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2450, 0ULL, 2);
    v_t_2453 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2450);
  }
  V v_t_2454 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 5);
  V v_t_2455 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2454, MK_INT(1LL)), heff_dup(v_b_245)));
  V v_cod_2457 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec_n(2, shape_stx__val, (V[]){v_t_2455, heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam8, 1, 1, (V[]){v_b_245})})});
  V v_t_2458 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 5);
  V v_t_2459 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_rfield(v_e_244, 1), v_t_2458, heff_dup(v_x_2411), v_cod_2457));
  V v_t_2460 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 5);
  HeffT2 v_t_2461 = ({ V a_0 = heff_dup(v_x_240); V a_1 = v_x_2449; V a_2 = v_t_2453; V b_3 = heff_get_n(v_e_244, 1, 8); V a_4 = v_t_2460; V a_5 = v_t_2459; HeffT2 r_ = (g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_24cpr(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(v_t_2453); heff_drop(b_3); r_; });
  {
    V v_field_2462 = v_t_2461.f[0];
    V v_field_2463 = v_t_2461.f[1];
    V v_t_2464 = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_240, heff_get_n(v_x_2437, 0, 2)});
    V v_t_2465 = heff_tag_n(TAG_SFix, 2, (V[]){heff_take_field(v_x_2411, 0), v_t_2464});
    V v_t_2476 = ({ V rv_0 = heff_tag_n(TAG_SApp, 2, (V[]){v_field_2462, v_t_2465}); V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam9, 1, 1, (V[]){v_field_2463}); V rr_ = heff_rec_reuse_nf(v_x_2411, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    V f_ = v_k_2410;
    args[0] = v_t_2476;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2eelab_2erules_2elocalDef_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_rest_243 = heff_env(self)[3];
  V v_b_245 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  V v_x1_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2442;
  switch (heff_tag_of(v_x1_2438)) {
  case TAG_Nom: {
    V v_x_2439 = heff_field(v_x1_2438, 0);
    heff_take_n(v_x1_2438, 1ULL, 1);
    v_t_2442 = v_x_2439;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2438, 0ULL, 1);
    v_t_2442 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2441 = heff_field(v_x1_2438, 0);
    heff_take_n(v_x1_2438, 1ULL, 1);
    v_t_2442 = v_x_2441;
    break;
  }
  default: heff_nomatch(v_x1_2438);
  }
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_240), v_t_2442, heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam6, 4, 3, (V[]){v_rest_243, heff_dup(v_e_244), heff_dup(v_b_245)}), v_hd_249, heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam7, 1, 6, (V[]){v_e_244, v_b_245, v_x_240, v_x_2411, v_x_2437, v_k_2410})));
}
V g_heff_2eelab_2erules_2elocalDef_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_rest_243 = heff_env(self)[4];
  V v_b_245 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  V v_e_2412 = heff_dup(v_e_244);
  V v_x_2413 = heff_dup(v_x_240);
  V v_x1_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2418;
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_Nom: {
    V v_x_2415 = heff_field(v_x1_2414, 0);
    heff_take_n(v_x1_2414, 1ULL, 1);
    v_a_2418 = v_x_2415;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2414, 0ULL, 1);
    v_a_2418 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2417 = heff_field(v_x1_2414, 0);
    heff_take_n(v_x1_2414, 1ULL, 1);
    v_a_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x1_2414);
  }
  V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_e_2412, 0)), 0, 5);
  V v_v_2421 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_t_2419}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam3, 1, 1, (V[]){heff_dup(v_a_2418)}), NTAG(TAG_Nothing)));
  V v_c_2422 = heff_take_field(v_e_2412, 0);
  V v_t_2423 = heff_intAdd(heff_take_field(v_c_2422, 0), MK_INT(1LL));
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, heff_take_field(v_c_2422, 1)});
  V v_t_2426 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_2422, 2), heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam4, 1, 1, (V[]){v_v_2421})});
  V v_t_2427 = heff_tag_n(TAG_CBind, 3, (V[]){heff_take_field(v_c_2422, 3), heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(1LL)}), v_a_2418});
  V v_t_2428 = ({ V rv_0 = v_t_2423; V rv_1 = v_t_2424; V rv_2 = v_t_2426; V rv_3 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_c_2422, 16ULL, 5, shape_len__names__locals__ctx__matched, 768u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
  V v_e_2429 = ({ V rv_0 = v_t_2428; V rv_2 = NTAG(TAG_ForNominative); V rv_3 = MK_INT(0LL); V rv_6 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_e_2412, 178ULL, 8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, 53004u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 6) = rv_6; rr_; });
  V v_x1_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2411, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2434;
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_Nom: {
    V v_x_2431 = heff_field(v_x1_2430, 0);
    heff_take_n(v_x1_2430, 1ULL, 1);
    v_a_2434 = v_x_2431;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2430, 0ULL, 1);
    v_a_2434 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2433 = heff_field(v_x1_2430, 0);
    heff_take_n(v_x1_2430, 1ULL, 1);
    v_a_2434 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x1_2430);
  }
  V v_c_2436;
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2435 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    v_c_2436 = heff_tr(heff_call(v_f_2435, 2, (V[]){v_e_2429, v_a_2434}));
    break;
  }
  default: heff_nomatch(v_body_242);
  }
  V f_ = v_c_2436;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam5, 1, 7, (V[]){v_x_2411, v_x_240, v_e_244, v_rest_243, v_b_245, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2elocalDef_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_240 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_rest_243 = heff_env(self)[4];
  V v_b_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam2, 1, 7, (V[]){v_e_244, v_x_240, v_body_242, v_hd_249, v_rest_243, v_b_245, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elocalDef_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_b_245 = args[1];
  V v_typ_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_rest_243 = heff_env(self)[3];
  V v_c_248;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_246 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    V v_t_247 = heff_rec_n(8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, (V[]){heff_dup(heff_rfield(v_e_244, 0)), heff_dup(heff_rfield(v_e_244, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_244, 3)), heff_dup(heff_rfield(v_e_244, 4)), heff_dup(heff_rfield(v_e_244, 5)), heff_dup(heff_rfield(v_e_244, 6)), heff_dup(heff_rfield(v_e_244, 7))});
    v_c_248 = heff_tr(heff_call(v_f_246, 1, (V[]){v_t_247}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2elocalDef_lam1, 2, 6, (V[]){v_c_248, v_e_244, v_x_240, v_body_242, v_rest_243, v_b_245});
}

static V g_heff_2eelab_2erules_2eevidenceSearch_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eevidenceSearch_st;
static V g_heff_2eelab_2erules_2eevidenceSearch_init(void) {
  return heff_tag_n(TAG_MkEvidenceSearch, 1, (V[]){((V)&g_heff_2eelab_2erules_2eevidenceSearchF_clo)});
}
V g_heff_2eelab_2erules_2eevidenceSearch_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eevidenceSearch_st)) return g_heff_2eelab_2erules_2eevidenceSearch_val;
  return heff_global(&g_heff_2eelab_2erules_2eevidenceSearch_val, &g_heff_2eelab_2erules_2eevidenceSearch_st, g_heff_2eelab_2erules_2eevidenceSearch_init);
}