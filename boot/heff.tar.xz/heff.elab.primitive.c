// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayAppend 23933
#define TAG_ArrayFromList 11455
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_ArrayIndexIn 58029
#define TAG_ArrayIndexInAny 674
#define TAG_ArrayInsertAt 1609
#define TAG_ArrayKeeps 39370
#define TAG_ArrayKeepsAs 18630
#define TAG_ArrayLength 32493
#define TAG_ArrayOwn 58870
#define TAG_ArrayPeek 2264
#define TAG_ArrayPeekIn 6151
#define TAG_ArrayPush 18071
#define TAG_ArrayRemoveAt 38526
#define TAG_ArrayReplicate 47039
#define TAG_ArrayReserve 45606
#define TAG_ArraySet 62162
#define TAG_ArraySetOwned 53556
#define TAG_ArraySetOwnedIn 22211
#define TAG_ArraySlice 38486
#define TAG_ArrayToList 20274
#define TAG_BitsBytes 6377
#define TAG_BitsConcat 14523
#define TAG_BitsEq 8995
#define TAG_BitsIntAt 48290
#define TAG_BitsLength 37027
#define TAG_BitsOfBytes 24218
#define TAG_BitsOfInt 3554
#define TAG_BitsSlice 40746
#define TAG_BocGiven 26228
#define TAG_BocNew 29139
#define TAG_BocTaken 53948
#define TAG_BocWhen 59622
#define TAG_BytesAppend 445
#define TAG_BytesAsString 10306
#define TAG_BytesAt 9508
#define TAG_BytesConcat 52027
#define TAG_BytesEq 9629
#define TAG_BytesFind 30348
#define TAG_BytesFromList 45957
#define TAG_BytesFromString 47012
#define TAG_BytesHasAt 63051
#define TAG_BytesIntAt 64296
#define TAG_BytesLength 9005
#define TAG_BytesOfInt 19560
#define TAG_BytesSlice 56752
#define TAG_BytesToList 62312
#define TAG_BytesToString 37927
#define TAG_CustodianDue 8759
#define TAG_CustodyIn 58670
#define TAG_FloatAcos 708
#define TAG_FloatAdd 6390
#define TAG_FloatAsin 15893
#define TAG_FloatAtan 16606
#define TAG_FloatAtan2 55855
#define TAG_FloatBits 36420
#define TAG_FloatCos 8668
#define TAG_FloatDiv 9446
#define TAG_FloatEq 13032
#define TAG_FloatExp 10866
#define TAG_FloatFloor 58439
#define TAG_FloatFromInt 61384
#define TAG_FloatLe 13237
#define TAG_FloatLog 17305
#define TAG_FloatLt 13252
#define TAG_FloatMul 18457
#define TAG_FloatOfBits 49155
#define TAG_FloatOfDecimal 61587
#define TAG_FloatPow 21165
#define TAG_FloatShow 17547
#define TAG_FloatSin 23853
#define TAG_FloatSqrt 26286
#define TAG_FloatSub 24213
#define TAG_FloatTan 24566
#define TAG_FuelTick 47424
#define TAG_FuelTicks 28388
#define TAG_Hole 35555
#define TAG_IntAdd 18227
#define TAG_IntAnd 18537
#define TAG_IntDiv 21283
#define TAG_IntEq 36665
#define TAG_IntHash 50175
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_IntMod 30100
#define TAG_IntMul 30294
#define TAG_IntOr 36976
#define TAG_IntShl 35657
#define TAG_IntShow 56864
#define TAG_IntShr 35663
#define TAG_IntSub 36050
#define TAG_IntXor 40685
#define TAG_Keep 49586
#define TAG_OfFixed 17267
#define TAG_OnWindows 60758
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_Panic 15447
#define TAG_Perform 19235
#define TAG_PerformAt 64592
#define TAG_Reuse 22912
#define TAG_RuneEq 61407
#define TAG_RuneFromInt 49375
#define TAG_RuneLe 61612
#define TAG_RuneLt 61627
#define TAG_RuneToInt 27192
#define TAG_SetField 47531
#define TAG_SetFieldPeek 37592
#define TAG_StrAppend 34515
#define TAG_StrByteAt 5424
#define TAG_StrCompare 35677
#define TAG_StrEq 12955
#define TAG_StrEqRange 52111
#define TAG_StrFind 15860
#define TAG_StrFromByte 3813
#define TAG_StrFromJS 60564
#define TAG_StrHash 2387
#define TAG_StrHashRange 56513
#define TAG_StrLength 43075
#define TAG_StrLt 13175
#define TAG_StrOfRunes 54236
#define TAG_StrRuneAt 38304
#define TAG_StrRuneCount 54745
#define TAG_StrRuneDecode 45427
#define TAG_StrRuneWidth 48503
#define TAG_StrRunes 5519
#define TAG_StrSlice 780
#define TAG_StrToJS 44411
#define TAG_Tip 31527
#define TAG_TrieSlot 53599
#define TAG_WordAdd 60179
#define TAG_WordDiv 63235
#define TAG_WordEq 48587
#define TAG_WordLe 48792
#define TAG_WordLt 48807
#define TAG_WordMod 6526
#define TAG_WordMul 6720
#define TAG_WordQuot 65290
#define TAG_WordRem 11030
#define TAG_WordSub 12476
#define TAG_WordToFloat 50865
#define LBL_fixed 298804110
#define LBL_op 10312
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
V g_heff_2eelab_2efixed_2efixedPrimName(V);
V g_heff_2eelab_2efixed_2efixedPrimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimName_clo;
V g_heff_2eelab_2efixed_2efixedPrims_get(void);
V g_heff_2eelab_2eprimitive_2ebasicPrims_get(void);
V g_heff_2eelab_2eprimitive_2ecompilerPrims_get(void);
V g_heff_2eelab_2eprimitive_2ecompilerTable_get(void);
V g_heff_2eelab_2eprimitive_2elibraryPrims_get(void);
V g_heff_2eelab_2eprimitive_2elibraryTable_get(void);
V g_heff_2eelab_2eprimitive_2eprimArity(V);
V g_heff_2eelab_2eprimitive_2eprimArity_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimArity_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2eelab_2eprimitive_2eprimOfName(V);
V g_heff_2eelab_2eprimitive_2eprimOfName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimOfName_clo;
V g_heff_2eelab_2eprimitive_2etextPrims_get(void);
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2emap_24s1289827711x943898099(V);
V g_list_2emap_24s1289827711x943898099_entry(V self, V *a);
extern Clo g_list_2emap_24s1289827711x943898099_clo;
V g_list_2emap_24s94933736x72301022(V);
V g_list_2emap_24s94933736x72301022_entry(V self, V *a);
extern Clo g_list_2emap_24s94933736x72301022_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str0, 6, "intAdd");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str1, 6, "intSub");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str2, 6, "intMul");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str3, 6, "intDiv");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str4, 6, "intMod");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str5, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str6, 5, "intLt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str7, 5, "intLe");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str8, 7, "intShow");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str9, 6, "intAnd");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str10, 5, "intOr");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str11, 6, "intXor");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str12, 6, "intShl");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str13, 6, "intShr");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str14, 8, "floatAdd");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str15, 8, "floatSub");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str16, 8, "floatMul");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str17, 8, "floatDiv");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str18, 7, "floatEq");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str19, 7, "floatLt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str20, 7, "floatLe");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str21, 9, "floatShow");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str22, 12, "floatFromInt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str23, 9, "floatSqrt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str24, 9, "onWindows");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str25, 10, "floatFloor");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str26, 8, "floatSin");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str27, 8, "floatCos");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str28, 8, "floatTan");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str29, 9, "floatAsin");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str30, 9, "floatAcos");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str31, 9, "floatAtan");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str32, 10, "floatAtan2");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str33, 8, "floatExp");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str34, 8, "floatLog");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str35, 8, "floatPow");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str36, 11, "arrayLength");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str37, 10, "arrayIndex");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str38, 8, "arraySet");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str39, 13, "arrayGenerate");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str40, 13, "arrayFromList");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str41, 11, "arrayToList");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str42, 14, "arrayReplicate");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str43, 10, "arraySlice");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str44, 11, "arrayAppend");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str45, 13, "arrayInsertAt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str46, 13, "arrayRemoveAt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str47, 9, "arrayPush");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str48, 12, "arrayReserve");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str49, 4, "hole");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str50, 8, "setField");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str51, 9, "strAppend");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str52, 9, "strLength");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str53, 8, "strSlice");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str54, 5, "strEq");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str55, 5, "strLt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str56, 10, "strCompare");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str57, 7, "strFind");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str58, 6, "runeEq");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str59, 6, "runeLt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str60, 6, "runeLe");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str61, 9, "runeToInt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str62, 11, "runeFromInt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str63, 4, "keep");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str64, 5, "panic");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str65, 9, "strByteAt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str66, 11, "strFromByte");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str67, 9, "strRuneAt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str68, 12, "strRuneWidth");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str69, 12, "strRuneCount");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str70, 8, "strRunes");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str71, 10, "strOfRunes");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str72, 7, "strToJS");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str73, 9, "strFromJS");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str74, 11, "bytesLength");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str75, 7, "bytesAt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str76, 10, "bytesSlice");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str77, 11, "bytesAppend");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str78, 11, "bytesConcat");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str79, 7, "bytesEq");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str80, 13, "bytesFromList");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str81, 11, "bytesToList");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str82, 15, "bytesFromString");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str83, 13, "bytesAsString");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str84, 13, "bytesToString");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str85, 10, "bytesIntAt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str86, 10, "bytesOfInt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str87, 10, "bytesHasAt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str88, 9, "bytesFind");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str89, 10, "bitsLength");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str90, 9, "bitsIntAt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str91, 9, "bitsOfInt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str92, 10, "bitsConcat");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str93, 9, "bitsSlice");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str94, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str95, 9, "bitsBytes");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str96, 6, "bitsEq");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str97, 9, "floatBits");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str98, 11, "floatOfBits");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str99, 14, "floatOfDecimal");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str100, 7, "strHash");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str101, 12, "strHashRange");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str102, 10, "strEqRange");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str103, 7, "intHash");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str104, 8, "trieSlot");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str105, 7, "perform");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str106, 9, "performAt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str107, 7, "bocWhen");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str108, 6, "bocNew");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str109, 8, "bocTaken");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str110, 8, "bocGiven");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str111, 7, "wordAdd");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str112, 7, "wordSub");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str113, 7, "wordMul");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str114, 7, "wordDiv");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str115, 7, "wordMod");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str116, 8, "wordQuot");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str117, 7, "wordRem");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str118, 6, "wordEq");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str119, 6, "wordLt");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str120, 6, "wordLe");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str121, 11, "wordToFloat");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str122, 12, "arrayIndexIn");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str123, 15, "arrayIndexInAny");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str124, 9, "arrayPeek");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str125, 11, "arrayPeekIn");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str126, 13, "arraySetOwned");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str127, 15, "arraySetOwnedIn");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str128, 8, "arrayOwn");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str129, 10, "arrayKeeps");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str130, 12, "arrayKeepsAs");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str131, 6, "$reuse");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str132, 12, "setFieldPeek");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str133, 13, "strRuneDecode");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str134, 8, "fuelTick");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str135, 9, "fuelTicks");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str136, 12, "custodianDue");
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimName_str137, 9, "custodyIn");
Clo g_heff_2eelab_2eprimitive_2eprimName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprimitive_2eprimName_entry, 1, 0};

V g_heff_2eelab_2eprimitive_2eprimName(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IntAdd: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str0);
  }
  case TAG_IntSub: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str1);
  }
  case TAG_IntMul: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str2);
  }
  case TAG_IntDiv: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str3);
  }
  case TAG_IntMod: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str4);
  }
  case TAG_IntEq: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str5);
  }
  case TAG_IntLt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str6);
  }
  case TAG_IntLe: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str7);
  }
  case TAG_IntShow: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str8);
  }
  case TAG_IntAnd: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str9);
  }
  case TAG_IntOr: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str10);
  }
  case TAG_IntXor: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str11);
  }
  case TAG_IntShl: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str12);
  }
  case TAG_IntShr: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str13);
  }
  case TAG_FloatAdd: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str14);
  }
  case TAG_FloatSub: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str15);
  }
  case TAG_FloatMul: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str16);
  }
  case TAG_FloatDiv: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str17);
  }
  case TAG_FloatEq: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str18);
  }
  case TAG_FloatLt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str19);
  }
  case TAG_FloatLe: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str20);
  }
  case TAG_FloatShow: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str21);
  }
  case TAG_FloatFromInt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str22);
  }
  case TAG_FloatSqrt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str23);
  }
  case TAG_OnWindows: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str24);
  }
  case TAG_FloatFloor: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str25);
  }
  case TAG_FloatSin: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str26);
  }
  case TAG_FloatCos: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str27);
  }
  case TAG_FloatTan: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str28);
  }
  case TAG_FloatAsin: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str29);
  }
  case TAG_FloatAcos: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str30);
  }
  case TAG_FloatAtan: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str31);
  }
  case TAG_FloatAtan2: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str32);
  }
  case TAG_FloatExp: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str33);
  }
  case TAG_FloatLog: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str34);
  }
  case TAG_FloatPow: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str35);
  }
  case TAG_ArrayLength: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str36);
  }
  case TAG_ArrayIndex: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str37);
  }
  case TAG_ArraySet: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str38);
  }
  case TAG_ArrayGenerate: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str39);
  }
  case TAG_ArrayFromList: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str40);
  }
  case TAG_ArrayToList: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str41);
  }
  case TAG_ArrayReplicate: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str42);
  }
  case TAG_ArraySlice: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str43);
  }
  case TAG_ArrayAppend: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str44);
  }
  case TAG_ArrayInsertAt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str45);
  }
  case TAG_ArrayRemoveAt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str46);
  }
  case TAG_ArrayPush: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str47);
  }
  case TAG_ArrayReserve: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str48);
  }
  case TAG_Hole: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str49);
  }
  case TAG_SetField: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str50);
  }
  case TAG_StrAppend: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str51);
  }
  case TAG_StrLength: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str52);
  }
  case TAG_StrSlice: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str53);
  }
  case TAG_StrEq: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str54);
  }
  case TAG_StrLt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str55);
  }
  case TAG_StrCompare: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str56);
  }
  case TAG_StrFind: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str57);
  }
  case TAG_RuneEq: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str58);
  }
  case TAG_RuneLt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str59);
  }
  case TAG_RuneLe: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str60);
  }
  case TAG_RuneToInt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str61);
  }
  case TAG_RuneFromInt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str62);
  }
  case TAG_Keep: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str63);
  }
  case TAG_Panic: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str64);
  }
  case TAG_StrByteAt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str65);
  }
  case TAG_StrFromByte: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str66);
  }
  case TAG_StrRuneAt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str67);
  }
  case TAG_StrRuneWidth: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str68);
  }
  case TAG_StrRuneCount: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str69);
  }
  case TAG_StrRunes: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str70);
  }
  case TAG_StrOfRunes: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str71);
  }
  case TAG_StrToJS: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str72);
  }
  case TAG_StrFromJS: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str73);
  }
  case TAG_BytesLength: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str74);
  }
  case TAG_BytesAt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str75);
  }
  case TAG_BytesSlice: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str76);
  }
  case TAG_BytesAppend: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str77);
  }
  case TAG_BytesConcat: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str78);
  }
  case TAG_BytesEq: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str79);
  }
  case TAG_BytesFromList: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str80);
  }
  case TAG_BytesToList: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str81);
  }
  case TAG_BytesFromString: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str82);
  }
  case TAG_BytesAsString: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str83);
  }
  case TAG_BytesToString: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str84);
  }
  case TAG_BytesIntAt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str85);
  }
  case TAG_BytesOfInt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str86);
  }
  case TAG_BytesHasAt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str87);
  }
  case TAG_BytesFind: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str88);
  }
  case TAG_BitsLength: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str89);
  }
  case TAG_BitsIntAt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str90);
  }
  case TAG_BitsOfInt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str91);
  }
  case TAG_BitsConcat: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str92);
  }
  case TAG_BitsSlice: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str93);
  }
  case TAG_BitsOfBytes: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str94);
  }
  case TAG_BitsBytes: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str95);
  }
  case TAG_BitsEq: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str96);
  }
  case TAG_FloatBits: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str97);
  }
  case TAG_FloatOfBits: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str98);
  }
  case TAG_FloatOfDecimal: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str99);
  }
  case TAG_StrHash: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str100);
  }
  case TAG_StrHashRange: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str101);
  }
  case TAG_StrEqRange: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str102);
  }
  case TAG_IntHash: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str103);
  }
  case TAG_TrieSlot: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str104);
  }
  case TAG_OfFixed: {
    V v_w_241 = heff_field(v_x1_240, 0);
    V v_op_242 = heff_field(v_x1_240, 1);
    HEFF_LAST return g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){heff_dup(v_w_241), heff_dup(v_op_242)}));
  }
  case TAG_Perform: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str105);
  }
  case TAG_PerformAt: {
    V v_i_243 = heff_field(v_x1_240, 0);
    return heff_strAppend(((V)&g_heff_2eelab_2eprimitive_2eprimName_str106), heff_intShow(heff_dup(v_i_243)));
  }
  case TAG_BocWhen: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str107);
  }
  case TAG_BocNew: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str108);
  }
  case TAG_BocTaken: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str109);
  }
  case TAG_BocGiven: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str110);
  }
  case TAG_WordAdd: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str111);
  }
  case TAG_WordSub: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str112);
  }
  case TAG_WordMul: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str113);
  }
  case TAG_WordDiv: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str114);
  }
  case TAG_WordMod: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str115);
  }
  case TAG_WordQuot: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str116);
  }
  case TAG_WordRem: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str117);
  }
  case TAG_WordEq: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str118);
  }
  case TAG_WordLt: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str119);
  }
  case TAG_WordLe: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str120);
  }
  case TAG_WordToFloat: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str121);
  }
  case TAG_ArrayIndexIn: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str122);
  }
  case TAG_ArrayIndexInAny: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str123);
  }
  case TAG_ArrayPeek: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str124);
  }
  case TAG_ArrayPeekIn: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str125);
  }
  case TAG_ArraySetOwned: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str126);
  }
  case TAG_ArraySetOwnedIn: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str127);
  }
  case TAG_ArrayOwn: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str128);
  }
  case TAG_ArrayKeeps: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str129);
  }
  case TAG_ArrayKeepsAs: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str130);
  }
  case TAG_Reuse: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str131);
  }
  case TAG_SetFieldPeek: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str132);
  }
  case TAG_StrRuneDecode: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str133);
  }
  case TAG_FuelTick: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str134);
  }
  case TAG_FuelTicks: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str135);
  }
  case TAG_CustodianDue: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str136);
  }
  case TAG_CustodyIn: {
    return ((V)&g_heff_2eelab_2eprimitive_2eprimName_str137);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprimitive_2eprimName(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eprimitive_2eprimArity_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprimitive_2eprimArity_entry, 1, 0};

V g_heff_2eelab_2eprimitive_2eprimArity(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IntAdd: {
    return MK_INT(2LL);
  }
  case TAG_IntSub: {
    return MK_INT(2LL);
  }
  case TAG_IntMul: {
    return MK_INT(2LL);
  }
  case TAG_IntDiv: {
    return MK_INT(2LL);
  }
  case TAG_IntMod: {
    return MK_INT(2LL);
  }
  case TAG_IntEq: {
    return MK_INT(2LL);
  }
  case TAG_IntLt: {
    return MK_INT(2LL);
  }
  case TAG_IntLe: {
    return MK_INT(2LL);
  }
  case TAG_IntShow: {
    return MK_INT(1LL);
  }
  case TAG_IntAnd: {
    return MK_INT(2LL);
  }
  case TAG_IntOr: {
    return MK_INT(2LL);
  }
  case TAG_IntXor: {
    return MK_INT(2LL);
  }
  case TAG_IntShl: {
    return MK_INT(2LL);
  }
  case TAG_IntShr: {
    return MK_INT(2LL);
  }
  case TAG_FloatAdd: {
    return MK_INT(2LL);
  }
  case TAG_FloatSub: {
    return MK_INT(2LL);
  }
  case TAG_FloatMul: {
    return MK_INT(2LL);
  }
  case TAG_FloatDiv: {
    return MK_INT(2LL);
  }
  case TAG_FloatEq: {
    return MK_INT(2LL);
  }
  case TAG_FloatLt: {
    return MK_INT(2LL);
  }
  case TAG_FloatLe: {
    return MK_INT(2LL);
  }
  case TAG_FloatShow: {
    return MK_INT(1LL);
  }
  case TAG_FloatFromInt: {
    return MK_INT(1LL);
  }
  case TAG_FloatSqrt: {
    return MK_INT(1LL);
  }
  case TAG_OnWindows: {
    return MK_INT(1LL);
  }
  case TAG_FloatFloor: {
    return MK_INT(1LL);
  }
  case TAG_FloatSin: {
    return MK_INT(1LL);
  }
  case TAG_FloatCos: {
    return MK_INT(1LL);
  }
  case TAG_FloatTan: {
    return MK_INT(1LL);
  }
  case TAG_FloatAsin: {
    return MK_INT(1LL);
  }
  case TAG_FloatAcos: {
    return MK_INT(1LL);
  }
  case TAG_FloatAtan: {
    return MK_INT(1LL);
  }
  case TAG_FloatAtan2: {
    return MK_INT(2LL);
  }
  case TAG_FloatExp: {
    return MK_INT(1LL);
  }
  case TAG_FloatLog: {
    return MK_INT(1LL);
  }
  case TAG_FloatPow: {
    return MK_INT(2LL);
  }
  case TAG_ArrayLength: {
    return MK_INT(1LL);
  }
  case TAG_ArrayIndex: {
    return MK_INT(2LL);
  }
  case TAG_ArraySet: {
    return MK_INT(3LL);
  }
  case TAG_ArrayGenerate: {
    return MK_INT(2LL);
  }
  case TAG_ArrayFromList: {
    return MK_INT(1LL);
  }
  case TAG_ArrayToList: {
    return MK_INT(1LL);
  }
  case TAG_ArrayReplicate: {
    return MK_INT(2LL);
  }
  case TAG_ArraySlice: {
    return MK_INT(3LL);
  }
  case TAG_ArrayAppend: {
    return MK_INT(2LL);
  }
  case TAG_ArrayInsertAt: {
    return MK_INT(3LL);
  }
  case TAG_ArrayRemoveAt: {
    return MK_INT(2LL);
  }
  case TAG_ArrayPush: {
    return MK_INT(2LL);
  }
  case TAG_ArrayReserve: {
    return MK_INT(2LL);
  }
  case TAG_Hole: {
    return MK_INT(0LL);
  }
  case TAG_SetField: {
    return MK_INT(3LL);
  }
  case TAG_StrAppend: {
    return MK_INT(2LL);
  }
  case TAG_StrLength: {
    return MK_INT(1LL);
  }
  case TAG_StrSlice: {
    return MK_INT(3LL);
  }
  case TAG_StrEq: {
    return MK_INT(2LL);
  }
  case TAG_StrLt: {
    return MK_INT(2LL);
  }
  case TAG_StrCompare: {
    return MK_INT(2LL);
  }
  case TAG_StrFind: {
    return MK_INT(3LL);
  }
  case TAG_RuneEq: {
    return MK_INT(2LL);
  }
  case TAG_RuneLt: {
    return MK_INT(2LL);
  }
  case TAG_RuneLe: {
    return MK_INT(2LL);
  }
  case TAG_RuneToInt: {
    return MK_INT(1LL);
  }
  case TAG_RuneFromInt: {
    return MK_INT(1LL);
  }
  case TAG_Keep: {
    return MK_INT(1LL);
  }
  case TAG_Panic: {
    return MK_INT(1LL);
  }
  case TAG_StrByteAt: {
    return MK_INT(2LL);
  }
  case TAG_StrFromByte: {
    return MK_INT(1LL);
  }
  case TAG_StrRuneAt: {
    return MK_INT(2LL);
  }
  case TAG_StrRuneWidth: {
    return MK_INT(2LL);
  }
  case TAG_StrRuneCount: {
    return MK_INT(1LL);
  }
  case TAG_StrRunes: {
    return MK_INT(1LL);
  }
  case TAG_StrOfRunes: {
    return MK_INT(1LL);
  }
  case TAG_StrToJS: {
    return MK_INT(1LL);
  }
  case TAG_StrFromJS: {
    return MK_INT(1LL);
  }
  case TAG_BytesLength: {
    return MK_INT(1LL);
  }
  case TAG_BytesAt: {
    return MK_INT(2LL);
  }
  case TAG_BytesSlice: {
    return MK_INT(3LL);
  }
  case TAG_BytesAppend: {
    return MK_INT(2LL);
  }
  case TAG_BytesConcat: {
    return MK_INT(1LL);
  }
  case TAG_BytesEq: {
    return MK_INT(2LL);
  }
  case TAG_BytesFromList: {
    return MK_INT(1LL);
  }
  case TAG_BytesToList: {
    return MK_INT(1LL);
  }
  case TAG_BytesFromString: {
    return MK_INT(1LL);
  }
  case TAG_BytesAsString: {
    return MK_INT(1LL);
  }
  case TAG_BytesToString: {
    return MK_INT(1LL);
  }
  case TAG_BytesIntAt: {
    return MK_INT(4LL);
  }
  case TAG_BytesOfInt: {
    return MK_INT(3LL);
  }
  case TAG_BytesHasAt: {
    return MK_INT(3LL);
  }
  case TAG_BytesFind: {
    return MK_INT(3LL);
  }
  case TAG_BitsLength: {
    return MK_INT(1LL);
  }
  case TAG_BitsIntAt: {
    return MK_INT(4LL);
  }
  case TAG_BitsOfInt: {
    return MK_INT(3LL);
  }
  case TAG_BitsConcat: {
    return MK_INT(1LL);
  }
  case TAG_BitsSlice: {
    return MK_INT(3LL);
  }
  case TAG_BitsOfBytes: {
    return MK_INT(1LL);
  }
  case TAG_BitsBytes: {
    return MK_INT(1LL);
  }
  case TAG_BitsEq: {
    return MK_INT(2LL);
  }
  case TAG_FloatBits: {
    return MK_INT(2LL);
  }
  case TAG_FloatOfBits: {
    return MK_INT(2LL);
  }
  case TAG_FloatOfDecimal: {
    return MK_INT(4LL);
  }
  case TAG_StrHash: {
    return MK_INT(1LL);
  }
  case TAG_StrHashRange: {
    return MK_INT(3LL);
  }
  case TAG_StrEqRange: {
    return MK_INT(4LL);
  }
  case TAG_IntHash: {
    return MK_INT(1LL);
  }
  case TAG_TrieSlot: {
    return MK_INT(3LL);
  }
  case TAG_OfFixed: {
    V v_op_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_op_242)) {
    case TAG_OpAdd: {
      return MK_INT(2LL);
    }
    case TAG_OpSub: {
      return MK_INT(2LL);
    }
    case TAG_OpMul: {
      return MK_INT(2LL);
    }
    case TAG_OpDiv: {
      return MK_INT(2LL);
    }
    case TAG_OpRem: {
      return MK_INT(2LL);
    }
    case TAG_OpEq: {
      return MK_INT(2LL);
    }
    case TAG_OpLt: {
      return MK_INT(2LL);
    }
    case TAG_OpLe: {
      return MK_INT(2LL);
    }
    case TAG_OpAnd: {
      return MK_INT(2LL);
    }
    case TAG_OpOr: {
      return MK_INT(2LL);
    }
    case TAG_OpXor: {
      return MK_INT(2LL);
    }
    case TAG_OpShl: {
      return MK_INT(2LL);
    }
    case TAG_OpShr: {
      return MK_INT(2LL);
    }
    case TAG_OpShow: {
      return MK_INT(1LL);
    }
    case TAG_OpFromInt: {
      return MK_INT(1LL);
    }
    case TAG_OpToInt: {
      return MK_INT(1LL);
    }
    case TAG_OpSqrt: {
      return MK_INT(1LL);
    }
    case TAG_OpFromFloat: {
      return MK_INT(1LL);
    }
    case TAG_OpToFloat: {
      return MK_INT(1LL);
    }
    case TAG_OpFloor: {
      return MK_INT(1LL);
    }
    default: return heff_nomatch(v_op_242);
    }
  }
  case TAG_Perform: {
    return MK_INT(2LL);
  }
  case TAG_PerformAt: {
    return MK_INT(2LL);
  }
  case TAG_BocWhen: {
    return MK_INT(5LL);
  }
  case TAG_BocNew: {
    return MK_INT(1LL);
  }
  case TAG_BocTaken: {
    return MK_INT(1LL);
  }
  case TAG_BocGiven: {
    return MK_INT(2LL);
  }
  case TAG_WordAdd: {
    return MK_INT(2LL);
  }
  case TAG_WordSub: {
    return MK_INT(2LL);
  }
  case TAG_WordMul: {
    return MK_INT(2LL);
  }
  case TAG_WordDiv: {
    return MK_INT(2LL);
  }
  case TAG_WordMod: {
    return MK_INT(2LL);
  }
  case TAG_WordQuot: {
    return MK_INT(2LL);
  }
  case TAG_WordRem: {
    return MK_INT(2LL);
  }
  case TAG_WordEq: {
    return MK_INT(2LL);
  }
  case TAG_WordLt: {
    return MK_INT(2LL);
  }
  case TAG_WordLe: {
    return MK_INT(2LL);
  }
  case TAG_WordToFloat: {
    return MK_INT(1LL);
  }
  case TAG_ArrayIndexIn: {
    return MK_INT(2LL);
  }
  case TAG_ArrayIndexInAny: {
    return MK_INT(2LL);
  }
  case TAG_ArrayPeek: {
    return MK_INT(2LL);
  }
  case TAG_ArrayPeekIn: {
    return MK_INT(2LL);
  }
  case TAG_ArraySetOwned: {
    return MK_INT(3LL);
  }
  case TAG_ArraySetOwnedIn: {
    return MK_INT(3LL);
  }
  case TAG_ArrayOwn: {
    return MK_INT(1LL);
  }
  case TAG_ArrayKeeps: {
    return MK_INT(1LL);
  }
  case TAG_ArrayKeepsAs: {
    return MK_INT(2LL);
  }
  case TAG_Reuse: {
    return MK_INT(2LL);
  }
  case TAG_SetFieldPeek: {
    return MK_INT(3LL);
  }
  case TAG_StrRuneDecode: {
    return MK_INT(2LL);
  }
  case TAG_FuelTick: {
    return MK_INT(0LL);
  }
  case TAG_FuelTicks: {
    return MK_INT(1LL);
  }
  case TAG_CustodianDue: {
    return MK_INT(0LL);
  }
  case TAG_CustodyIn: {
    return MK_INT(1LL);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eprimitive_2eprimArity_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprimitive_2eprimArity(a0); heff_drop(a0); return r;
}
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit0, TAG_Cons, 2, NTAG(TAG_Panic), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit1, TAG_Cons, 2, NTAG(TAG_Keep), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit0));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit2, TAG_Cons, 2, NTAG(TAG_RuneFromInt), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit1));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit3, TAG_Cons, 2, NTAG(TAG_RuneToInt), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit2));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit4, TAG_Cons, 2, NTAG(TAG_RuneLe), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit3));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit5, TAG_Cons, 2, NTAG(TAG_RuneLt), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit4));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit6, TAG_Cons, 2, NTAG(TAG_RuneEq), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit5));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit7, TAG_Cons, 2, NTAG(TAG_StrFind), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit6));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit8, TAG_Cons, 2, NTAG(TAG_StrCompare), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit7));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit9, TAG_Cons, 2, NTAG(TAG_StrLt), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit8));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit10, TAG_Cons, 2, NTAG(TAG_StrEq), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit9));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit11, TAG_Cons, 2, NTAG(TAG_StrSlice), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit10));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit12, TAG_Cons, 2, NTAG(TAG_StrLength), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit11));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit13, TAG_Cons, 2, NTAG(TAG_StrAppend), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit12));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit14, TAG_Cons, 2, NTAG(TAG_SetField), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit13));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit15, TAG_Cons, 2, NTAG(TAG_Hole), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit14));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit16, TAG_Cons, 2, NTAG(TAG_ArrayReserve), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit15));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit17, TAG_Cons, 2, NTAG(TAG_ArrayPush), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit16));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit18, TAG_Cons, 2, NTAG(TAG_ArrayRemoveAt), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit17));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit19, TAG_Cons, 2, NTAG(TAG_ArrayInsertAt), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit18));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit20, TAG_Cons, 2, NTAG(TAG_ArrayAppend), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit19));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit21, TAG_Cons, 2, NTAG(TAG_ArraySlice), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit20));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit22, TAG_Cons, 2, NTAG(TAG_ArrayReplicate), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit21));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit23, TAG_Cons, 2, NTAG(TAG_ArrayToList), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit22));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit24, TAG_Cons, 2, NTAG(TAG_ArrayFromList), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit23));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit25, TAG_Cons, 2, NTAG(TAG_ArrayGenerate), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit24));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit26, TAG_Cons, 2, NTAG(TAG_ArraySet), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit25));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit27, TAG_Cons, 2, NTAG(TAG_ArrayIndex), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit26));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit28, TAG_Cons, 2, NTAG(TAG_ArrayLength), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit27));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit29, TAG_Cons, 2, NTAG(TAG_FloatPow), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit28));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit30, TAG_Cons, 2, NTAG(TAG_FloatLog), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit29));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit31, TAG_Cons, 2, NTAG(TAG_FloatExp), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit30));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit32, TAG_Cons, 2, NTAG(TAG_FloatAtan2), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit31));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit33, TAG_Cons, 2, NTAG(TAG_FloatAtan), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit32));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit34, TAG_Cons, 2, NTAG(TAG_FloatAcos), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit33));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit35, TAG_Cons, 2, NTAG(TAG_FloatAsin), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit34));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit36, TAG_Cons, 2, NTAG(TAG_FloatTan), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit35));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit37, TAG_Cons, 2, NTAG(TAG_FloatCos), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit36));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit38, TAG_Cons, 2, NTAG(TAG_FloatSin), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit37));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit39, TAG_Cons, 2, NTAG(TAG_FloatFloor), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit38));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit40, TAG_Cons, 2, NTAG(TAG_OnWindows), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit39));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit41, TAG_Cons, 2, NTAG(TAG_FloatSqrt), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit40));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit42, TAG_Cons, 2, NTAG(TAG_FloatFromInt), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit41));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit43, TAG_Cons, 2, NTAG(TAG_FloatShow), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit42));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit44, TAG_Cons, 2, NTAG(TAG_FloatLe), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit43));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit45, TAG_Cons, 2, NTAG(TAG_FloatLt), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit44));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit46, TAG_Cons, 2, NTAG(TAG_FloatEq), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit45));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit47, TAG_Cons, 2, NTAG(TAG_FloatDiv), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit46));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit48, TAG_Cons, 2, NTAG(TAG_FloatMul), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit47));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit49, TAG_Cons, 2, NTAG(TAG_FloatSub), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit48));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit50, TAG_Cons, 2, NTAG(TAG_FloatAdd), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit49));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit51, TAG_Cons, 2, NTAG(TAG_IntShr), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit50));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit52, TAG_Cons, 2, NTAG(TAG_IntShl), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit51));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit53, TAG_Cons, 2, NTAG(TAG_IntXor), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit52));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit54, TAG_Cons, 2, NTAG(TAG_IntOr), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit53));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit55, TAG_Cons, 2, NTAG(TAG_IntAnd), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit54));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit56, TAG_Cons, 2, NTAG(TAG_IntShow), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit55));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit57, TAG_Cons, 2, NTAG(TAG_IntLe), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit56));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit58, TAG_Cons, 2, NTAG(TAG_IntLt), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit57));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit59, TAG_Cons, 2, NTAG(TAG_IntEq), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit58));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit60, TAG_Cons, 2, NTAG(TAG_IntMod), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit59));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit61, TAG_Cons, 2, NTAG(TAG_IntDiv), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit60));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit62, TAG_Cons, 2, NTAG(TAG_IntMul), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit61));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit63, TAG_Cons, 2, NTAG(TAG_IntSub), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit62));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ebasicPrims_lit64, TAG_Cons, 2, NTAG(TAG_IntAdd), ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit63));

static V g_heff_2eelab_2eprimitive_2ebasicPrims_val;
static HEFF_ONCE g_heff_2eelab_2eprimitive_2ebasicPrims_st;
static V g_heff_2eelab_2eprimitive_2ebasicPrims_init(void) {
  return ((V)&g_heff_2eelab_2eprimitive_2ebasicPrims_lit64);
}
V g_heff_2eelab_2eprimitive_2ebasicPrims_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eprimitive_2ebasicPrims_st)) return g_heff_2eelab_2eprimitive_2ebasicPrims_val;
  return heff_global(&g_heff_2eelab_2eprimitive_2ebasicPrims_val, &g_heff_2eelab_2eprimitive_2ebasicPrims_st, g_heff_2eelab_2eprimitive_2ebasicPrims_init);
}
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit0, TAG_Cons, 2, NTAG(TAG_TrieSlot), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit1, TAG_Cons, 2, NTAG(TAG_IntHash), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit0));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit2, TAG_Cons, 2, NTAG(TAG_StrEqRange), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit1));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit3, TAG_Cons, 2, NTAG(TAG_StrHashRange), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit2));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit4, TAG_Cons, 2, NTAG(TAG_StrHash), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit3));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit5, TAG_Cons, 2, NTAG(TAG_FloatOfDecimal), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit4));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit6, TAG_Cons, 2, NTAG(TAG_FloatOfBits), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit5));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit7, TAG_Cons, 2, NTAG(TAG_FloatBits), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit6));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit8, TAG_Cons, 2, NTAG(TAG_BitsEq), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit7));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit9, TAG_Cons, 2, NTAG(TAG_BitsBytes), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit8));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit10, TAG_Cons, 2, NTAG(TAG_BitsOfBytes), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit9));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit11, TAG_Cons, 2, NTAG(TAG_BitsSlice), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit10));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit12, TAG_Cons, 2, NTAG(TAG_BitsConcat), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit11));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit13, TAG_Cons, 2, NTAG(TAG_BitsOfInt), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit12));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit14, TAG_Cons, 2, NTAG(TAG_BitsIntAt), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit13));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit15, TAG_Cons, 2, NTAG(TAG_BitsLength), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit14));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit16, TAG_Cons, 2, NTAG(TAG_BytesFind), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit15));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit17, TAG_Cons, 2, NTAG(TAG_BytesHasAt), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit16));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit18, TAG_Cons, 2, NTAG(TAG_BytesOfInt), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit17));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit19, TAG_Cons, 2, NTAG(TAG_BytesIntAt), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit18));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit20, TAG_Cons, 2, NTAG(TAG_BytesToString), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit19));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit21, TAG_Cons, 2, NTAG(TAG_BytesAsString), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit20));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit22, TAG_Cons, 2, NTAG(TAG_BytesFromString), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit21));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit23, TAG_Cons, 2, NTAG(TAG_BytesToList), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit22));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit24, TAG_Cons, 2, NTAG(TAG_BytesFromList), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit23));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit25, TAG_Cons, 2, NTAG(TAG_BytesEq), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit24));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit26, TAG_Cons, 2, NTAG(TAG_BytesConcat), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit25));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit27, TAG_Cons, 2, NTAG(TAG_BytesAppend), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit26));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit28, TAG_Cons, 2, NTAG(TAG_BytesSlice), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit27));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit29, TAG_Cons, 2, NTAG(TAG_BytesAt), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit28));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit30, TAG_Cons, 2, NTAG(TAG_BytesLength), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit29));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit31, TAG_Cons, 2, NTAG(TAG_StrFromJS), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit30));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit32, TAG_Cons, 2, NTAG(TAG_StrToJS), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit31));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit33, TAG_Cons, 2, NTAG(TAG_StrOfRunes), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit32));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit34, TAG_Cons, 2, NTAG(TAG_StrRunes), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit33));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit35, TAG_Cons, 2, NTAG(TAG_StrRuneCount), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit34));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit36, TAG_Cons, 2, NTAG(TAG_StrRuneWidth), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit35));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit37, TAG_Cons, 2, NTAG(TAG_StrRuneAt), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit36));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit38, TAG_Cons, 2, NTAG(TAG_StrFromByte), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit37));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2etextPrims_lit39, TAG_Cons, 2, NTAG(TAG_StrByteAt), ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit38));

static V g_heff_2eelab_2eprimitive_2etextPrims_val;
static HEFF_ONCE g_heff_2eelab_2eprimitive_2etextPrims_st;
static V g_heff_2eelab_2eprimitive_2etextPrims_init(void) {
  return ((V)&g_heff_2eelab_2eprimitive_2etextPrims_lit39);
}
V g_heff_2eelab_2eprimitive_2etextPrims_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eprimitive_2etextPrims_st)) return g_heff_2eelab_2eprimitive_2etextPrims_val;
  return heff_global(&g_heff_2eelab_2eprimitive_2etextPrims_val, &g_heff_2eelab_2eprimitive_2etextPrims_st, g_heff_2eelab_2eprimitive_2etextPrims_init);
}

static V g_heff_2eelab_2eprimitive_2elibraryPrims_val;
static HEFF_ONCE g_heff_2eelab_2eprimitive_2elibraryPrims_st;
static V g_heff_2eelab_2eprimitive_2elibraryPrims_init(void) {
  V v_t_240 = (g_list_2emap_24s94933736x72301022(heff_dup(g_heff_2eelab_2efixed_2efixedPrims_get())));
  V v_t_241 = (g_prelude_2e_2b_2b(heff_dup(g_heff_2eelab_2eprimitive_2etextPrims_get()), v_t_240));
  return (g_prelude_2e_2b_2b(heff_dup(g_heff_2eelab_2eprimitive_2ebasicPrims_get()), v_t_241));
}
V g_heff_2eelab_2eprimitive_2elibraryPrims_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eprimitive_2elibraryPrims_st)) return g_heff_2eelab_2eprimitive_2elibraryPrims_val;
  return heff_global(&g_heff_2eelab_2eprimitive_2elibraryPrims_val, &g_heff_2eelab_2eprimitive_2elibraryPrims_st, g_heff_2eelab_2eprimitive_2elibraryPrims_init);
}
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit0, TAG_Cons, 2, NTAG(TAG_BocGiven), NTAG(TAG_Nil));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit1, TAG_Cons, 2, NTAG(TAG_BocTaken), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit0));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit2, TAG_Cons, 2, NTAG(TAG_BocNew), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit1));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit3, TAG_Cons, 2, NTAG(TAG_BocWhen), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit2));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit4, TAG_Cons, 2, NTAG(TAG_CustodyIn), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit3));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit5, TAG_Cons, 2, NTAG(TAG_CustodianDue), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit4));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit6, TAG_Cons, 2, NTAG(TAG_FuelTicks), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit5));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit7, TAG_Cons, 2, NTAG(TAG_FuelTick), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit6));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit8, TAG_Cons, 2, NTAG(TAG_StrRuneDecode), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit7));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit9, TAG_Cons, 2, NTAG(TAG_SetFieldPeek), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit8));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit10, TAG_Cons, 2, NTAG(TAG_Reuse), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit9));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit11, TAG_Cons, 2, NTAG(TAG_ArrayKeepsAs), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit10));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit12, TAG_Cons, 2, NTAG(TAG_ArrayKeeps), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit11));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit13, TAG_Cons, 2, NTAG(TAG_ArrayOwn), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit12));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit14, TAG_Cons, 2, NTAG(TAG_ArraySetOwnedIn), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit13));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit15, TAG_Cons, 2, NTAG(TAG_ArraySetOwned), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit14));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit16, TAG_Cons, 2, NTAG(TAG_ArrayPeekIn), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit15));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit17, TAG_Cons, 2, NTAG(TAG_ArrayPeek), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit16));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit18, TAG_Cons, 2, NTAG(TAG_ArrayIndexInAny), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit17));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit19, TAG_Cons, 2, NTAG(TAG_ArrayIndexIn), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit18));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit20, TAG_Cons, 2, NTAG(TAG_WordToFloat), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit19));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit21, TAG_Cons, 2, NTAG(TAG_WordLe), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit20));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit22, TAG_Cons, 2, NTAG(TAG_WordLt), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit21));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit23, TAG_Cons, 2, NTAG(TAG_WordEq), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit22));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit24, TAG_Cons, 2, NTAG(TAG_WordRem), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit23));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit25, TAG_Cons, 2, NTAG(TAG_WordQuot), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit24));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit26, TAG_Cons, 2, NTAG(TAG_WordMod), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit25));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit27, TAG_Cons, 2, NTAG(TAG_WordDiv), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit26));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit28, TAG_Cons, 2, NTAG(TAG_WordMul), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit27));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit29, TAG_Cons, 2, NTAG(TAG_WordSub), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit28));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit30, TAG_Cons, 2, NTAG(TAG_WordAdd), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit29));
HEFF_TAG_LIT(g_heff_2eelab_2eprimitive_2ecompilerPrims_lit31, TAG_Cons, 2, NTAG(TAG_Perform), ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit30));

static V g_heff_2eelab_2eprimitive_2ecompilerPrims_val;
static HEFF_ONCE g_heff_2eelab_2eprimitive_2ecompilerPrims_st;
static V g_heff_2eelab_2eprimitive_2ecompilerPrims_init(void) {
  return ((V)&g_heff_2eelab_2eprimitive_2ecompilerPrims_lit31);
}
V g_heff_2eelab_2eprimitive_2ecompilerPrims_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eprimitive_2ecompilerPrims_st)) return g_heff_2eelab_2eprimitive_2ecompilerPrims_val;
  return heff_global(&g_heff_2eelab_2eprimitive_2ecompilerPrims_val, &g_heff_2eelab_2eprimitive_2ecompilerPrims_st, g_heff_2eelab_2eprimitive_2ecompilerPrims_init);
}

static V g_heff_2eelab_2eprimitive_2elibraryTable_val;
static HEFF_ONCE g_heff_2eelab_2eprimitive_2elibraryTable_st;
static V g_heff_2eelab_2eprimitive_2elibraryTable_init(void) {
  V v_ps_240 = heff_dup(g_heff_2eelab_2eprimitive_2elibraryPrims_get());
  V v_ps_241 = (g_list_2emap_24s1289827711x943898099(v_ps_240));
  return ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_241; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_241); r_; });
}
V g_heff_2eelab_2eprimitive_2elibraryTable_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eprimitive_2elibraryTable_st)) return g_heff_2eelab_2eprimitive_2elibraryTable_val;
  return heff_global(&g_heff_2eelab_2eprimitive_2elibraryTable_val, &g_heff_2eelab_2eprimitive_2elibraryTable_st, g_heff_2eelab_2eprimitive_2elibraryTable_init);
}

static V g_heff_2eelab_2eprimitive_2ecompilerTable_val;
static HEFF_ONCE g_heff_2eelab_2eprimitive_2ecompilerTable_st;
static V g_heff_2eelab_2eprimitive_2ecompilerTable_init(void) {
  V v_ps_240 = (g_list_2emap_24s1289827711x943898099(heff_dup(g_heff_2eelab_2eprimitive_2ecompilerPrims_get())));
  return ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_240; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_240); r_; });
}
V g_heff_2eelab_2eprimitive_2ecompilerTable_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eprimitive_2ecompilerTable_st)) return g_heff_2eelab_2eprimitive_2ecompilerTable_val;
  return heff_global(&g_heff_2eelab_2eprimitive_2ecompilerTable_val, &g_heff_2eelab_2eprimitive_2ecompilerTable_st, g_heff_2eelab_2eprimitive_2ecompilerTable_init);
}
HEFF_LIT(g_heff_2eelab_2eprimitive_2eprimOfName_str0, 9, "performAt");
Clo g_heff_2eelab_2eprimitive_2eprimOfName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eprimitive_2eprimOfName_entry, 1, 0};

V g_heff_2eelab_2eprimitive_2eprimOfName(V v_x_240) {
top: ;
  V v_d_241 = ({ V b_0 = heff_dup(g_heff_2eelab_2eprimitive_2ecompilerTable_get()); V a_1 = v_x_240; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(b_0, a_1)); heff_drop(b_0); r_; });
  V v_d_247;
  if (heff_strEq_c(heff_strSlice_lent(v_x_240, MK_INT(0LL), MK_INT(9LL), 6), ((V)&g_heff_2eelab_2eprimitive_2eprimOfName_str0))) {
    V v_t_242 = heff_strSlice_lent(v_x_240, MK_INT(9LL), heff_strLength_lent(v_x_240, 0), 6);
    HeffT2 v_t_243 = ({ V a_0 = v_t_242; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_t_242); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_d_241);
        V v_x_246 = v_field_245;
        v_d_247 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_PerformAt, 1, (V[]){v_x_246})});
      } else {
        heff_drop(v_field_245);
        v_d_247 = v_d_241;
      }
    }
  } else {
    v_d_247 = v_d_241;
  }
  HeffT2 v_t_248 = ({ V b_0 = heff_dup(g_heff_2eelab_2eprimitive_2elibraryTable_get()); V a_1 = v_x_240; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_d_247);
      V v_x_2411 = v_field_2410;
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2411});
    } else {
      heff_drop(v_field_2410);
      return v_d_247;
    }
  }
}
V g_heff_2eelab_2eprimitive_2eprimOfName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eprimitive_2eprimOfName(a0); heff_drop(a0); return r;
}